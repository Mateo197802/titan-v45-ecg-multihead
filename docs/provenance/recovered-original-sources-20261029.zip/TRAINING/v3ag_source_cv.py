from __future__ import annotations

from collections.abc import Mapping, Sequence

import numpy as np


def summarize_source_cv(
    fold_reports: Sequence[Mapping[str, object]],
    *,
    class_names: Sequence[str],
    min_folds: int = 3,
    min_accuracy: float = 0.95,
    min_macro_f1_exclusive: float = 0.75,
    min_class_mean_f1: float = 0.60,
) -> dict[str, object]:
    if len(fold_reports) < int(min_folds):
        raise ValueError(f"source CV requires at least {min_folds} complete folds")
    names = tuple(str(name) for name in class_names)
    if not names or len(set(names)) != len(names):
        raise ValueError("class_names must be non-empty and unique")

    seen_folds: set[str] = set()
    macro_f1_values: list[float] = []
    accuracy_values: list[float] = []
    class_values = {name: [] for name in names}
    normalized_folds: list[dict[str, object]] = []

    for raw in fold_reports:
        fold = str(raw.get("fold", "")).strip()
        if not fold or fold in seen_folds:
            raise ValueError(f"source CV fold names must be unique and non-empty: {fold!r}")
        seen_folds.add(fold)
        per_class = raw.get("per_class")
        if not isinstance(per_class, Mapping):
            raise ValueError(f"fold {fold} is missing per_class metrics")
        missing = [name for name in names if name not in per_class]
        if missing:
            raise ValueError(f"fold {fold} is missing primary classes: {missing}")

        macro_f1 = float(raw["macro_f1"])
        accuracy = float(raw["accuracy"])
        macro_f1_values.append(macro_f1)
        accuracy_values.append(accuracy)
        for name in names:
            row = per_class[name]
            if not isinstance(row, Mapping) or "f1" not in row:
                raise ValueError(f"fold {fold} class {name} is missing f1")
            class_values[name].append(float(row["f1"]))
        normalized_folds.append(
            {
                "fold": fold,
                "macro_f1": macro_f1,
                "accuracy": accuracy,
            }
        )

    class_mean_f1 = {name: float(np.mean(values)) for name, values in class_values.items()}
    collapsed = sorted(name for name, value in class_mean_f1.items() if value < float(min_class_mean_f1))
    mean_macro_f1 = float(np.mean(macro_f1_values))
    mean_accuracy = float(np.mean(accuracy_values))
    all_folds_pass = all(
        macro_f1 > float(min_macro_f1_exclusive) and accuracy >= float(min_accuracy)
        for macro_f1, accuracy in zip(macro_f1_values, accuracy_values)
    )
    return {
        "protocol": "TITAN_V45_V3AG_SOURCE_GROUPED_CV",
        "fold_count": len(normalized_folds),
        "folds": normalized_folds,
        "class_mean_f1": class_mean_f1,
        "collapsed_classes": collapsed,
        "mean_macro_f1": mean_macro_f1,
        "mean_accuracy": mean_accuracy,
        "min_class_mean_f1": min(class_mean_f1.values()),
        "criteria": {
            "min_folds": int(min_folds),
            "accuracy": f">={float(min_accuracy):.6f}",
            "macro_f1": f">{float(min_macro_f1_exclusive):.6f}",
            "class_mean_f1": f">={float(min_class_mean_f1):.6f}",
        },
        "passed": bool(all_folds_pass and not collapsed),
    }
