"""Evaluate TITAN V4.5 V3C on the adapted external manifests.

This runner intentionally reads record paths from the external manifest itself.
That allows derived external packages such as CODE-test to live outside DATA
without modifying raw DATA or V4.
"""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Mapping, Sequence

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from torch.utils.data import DataLoader

from DATA_PIPELINE.data_loader_ultra import ClinicalECGDataset, TARGET_LENGTH
from REGISTRIES.label_registry import normalize_record_path
from TRAINING.titan_v45_internal_runner import json_ready
from TRAINING.titan_v45_multihead_contract import (
    ACTIVE14_RHYTHMS,
    ACTIVE_PATHOLOGIES,
    CLINICAL_AXIS_LABELS,
    CLINICAL_AXIS_MANIFEST_COLUMNS,
    NUM_PATHOLOGY_CLASSES,
    NUM_RHYTHM_CLASSES,
    PRIMARY_PATHOLOGIES,
    PRIMARY_RHYTHMS,
)
from TRAINING.titan_v45_multihead_runtime import build_titan_v45_multihead, evaluate_multihead_epoch
from TRAINING.train_v4_lite import FocalLoss
from TRAINING.training_utils import (
    _resolve_manifest_record_base,
    load_manifest_pathology_labels,
    load_manifest_record_labels,
)


def _read_rows(path: str | Path) -> list[dict[str, str]]:
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _record_dirs_from_manifest(manifest_csv: str | Path, data_root: str | Path) -> tuple[list[str], dict[str, dict[str, str]]]:
    rows = _read_rows(manifest_csv)
    by_record: dict[str, dict[str, str]] = {}
    dirs: set[str] = set()
    for row in rows:
        record = _resolve_manifest_record_base(row, data_root=str(data_root))
        by_record[record] = row
        dirs.add(str(Path(record).parent))
    return sorted(dirs), by_record


def _split_labels(raw: object) -> list[str]:
    labels: list[str] = []
    for chunk in str(raw or "").replace(",", "|").split("|"):
        label = chunk.strip()
        if label and label not in labels:
            labels.append(label)
    return labels


def _accepted_labels(row: Mapping[str, object]) -> set[int]:
    names = _split_labels(row.get("accepted_primary_labels"))
    if not names:
        names = _split_labels(row.get("separator_primary_labels"))
    if not names and str(row.get("rhythm_label_name", "")).strip():
        names = [str(row.get("rhythm_label_name", "")).strip()]
    return {
        PRIMARY_RHYTHMS.index(name)
        for name in names
        if name in PRIMARY_RHYTHMS
    }


def _clinical_axis_labels(row: Mapping[str, object]) -> dict[str, np.ndarray]:
    labels: dict[str, np.ndarray] = {}
    for axis, members in CLINICAL_AXIS_LABELS.items():
        raw = _split_labels(row.get(CLINICAL_AXIS_MANIFEST_COLUMNS[axis]))
        values = np.asarray([1.0 if name in raw else 0.0 for name in members], dtype=np.float32)
        labels[axis] = values
    return labels


def _clinical_axis_map(rows_by_record: Mapping[str, Mapping[str, str]]) -> dict[str, dict[str, np.ndarray]]:
    return {
        record: _clinical_axis_labels(row)
        for record, row in rows_by_record.items()
    }


def _safe_f1(y_true: np.ndarray, y_pred: np.ndarray, labels: Sequence[int]) -> float:
    if not len(y_true):
        return 0.0
    return float(f1_score(y_true, y_pred, labels=list(labels), average="macro", zero_division=0))


def _binary_metrics(true: np.ndarray, pred: np.ndarray) -> dict[str, float | int]:
    true = true.astype(bool)
    pred = pred.astype(bool)
    tp = int(np.sum(true & pred))
    tn = int(np.sum(~true & ~pred))
    fp = int(np.sum(~true & pred))
    fn = int(np.sum(true & ~pred))
    precision = float(tp / max(tp + fp, 1))
    recall = float(tp / max(tp + fn, 1))
    specificity = float(tn / max(tn + fp, 1))
    f1 = float((2.0 * precision * recall) / max(precision + recall, 1e-12))
    return {
        "tp": tp,
        "tn": tn,
        "fp": fp,
        "fn": fn,
        "positive_support": int(true.sum()),
        "negative_support": int((~true).sum()),
        "accuracy": float((tp + tn) / max(len(true), 1)),
        "balanced_accuracy": float((recall + specificity) / 2.0),
        "precision": precision,
        "recall": recall,
        "f1": f1,
    }


def _aggregate_records(result: Mapping[str, object], rows_by_record: Mapping[str, Mapping[str, str]]) -> tuple[list[dict[str, object]], np.ndarray, np.ndarray, np.ndarray]:
    probabilities = np.asarray(result["rhythm_probability"], dtype=np.float64)
    targets = np.asarray(result["rhythm_y_true"], dtype=np.int64)
    predictions = np.asarray(result["rhythm_y_pred"], dtype=np.int64)
    confidences = np.asarray(result["rhythm_confidence"], dtype=np.float64)
    paths = [normalize_record_path(path) for path in result["record_paths"]]
    window_keys = [str(key) for key in result.get("window_keys", [""] * len(paths))]

    grouped: dict[str, list[int]] = defaultdict(list)
    for index, path in enumerate(paths):
        grouped[path].append(index)

    record_rows: list[dict[str, object]] = []
    record_true: list[int] = []
    record_pred: list[int] = []
    record_conf: list[float] = []
    for record, indices in sorted(grouped.items()):
        probs = probabilities[indices].mean(axis=0)
        pred = int(np.argmax(probs))
        conf = float(np.max(probs))
        target = int(Counter(targets[indices].tolist()).most_common(1)[0][0])
        row = dict(rows_by_record.get(record, {}))
        accepted = _accepted_labels(row)
        record_rows.append(
            {
                "record_base": record,
                "record_id": row.get("record_id", Path(record).name),
                "source": row.get("source", ""),
                "dx_codes": row.get("dx_codes", ""),
                "target_index": target,
                "target_label": ACTIVE14_RHYTHMS[target] if 0 <= target < len(ACTIVE14_RHYTHMS) else f"class_{target}",
                "predicted_index": pred,
                "predicted_label": ACTIVE14_RHYTHMS[pred] if 0 <= pred < len(ACTIVE14_RHYTHMS) else f"class_{pred}",
                "confidence": conf,
                "single_label_correct": bool(pred == target),
                "accepted_labels": "|".join(PRIMARY_RHYTHMS[index] for index in sorted(accepted)),
                "accepted_correct": bool(pred in accepted),
                "window_count": len(indices),
                "window_keys": "|".join(window_keys[index] for index in indices[:8]),
                **{f"prob_{name}": float(probs[i]) for i, name in enumerate(ACTIVE14_RHYTHMS)},
            }
        )
        record_true.append(target)
        record_pred.append(pred)
        record_conf.append(conf)
    return record_rows, np.asarray(record_true, dtype=np.int64), np.asarray(record_pred, dtype=np.int64), np.asarray(record_conf, dtype=np.float64)


def _membership_gate(record_rows: list[dict[str, object]], y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, object]:
    accepted_sets: list[set[int]] = []
    for row in record_rows:
        accepted = {
            PRIMARY_RHYTHMS.index(label)
            for label in _split_labels(row.get("accepted_labels"))
            if label in PRIMARY_RHYTHMS
        }
        if not accepted and 0 <= int(row["target_index"]) < len(PRIMARY_RHYTHMS):
            accepted = {int(row["target_index"])}
        accepted_sets.append(accepted)

    accepted_correct = np.asarray([int(pred) in labels for pred, labels in zip(y_pred, accepted_sets, strict=True)], dtype=bool)
    primary_indices = list(range(len(PRIMARY_RHYTHMS)))
    panels: dict[str, dict[str, float | int]] = {}
    for index, name in enumerate(PRIMARY_RHYTHMS):
        true_binary = np.asarray([index in labels for labels in accepted_sets], dtype=bool)
        pred_binary = y_pred == index
        panels[name] = _binary_metrics(true_binary, pred_binary)

    single_mask = np.asarray([len(labels) == 1 for labels in accepted_sets], dtype=bool)
    single_true = np.asarray([next(iter(labels)) if labels else -1 for labels in accepted_sets], dtype=np.int64)
    valid_single = single_mask & (single_true >= 0)
    support = {
        name: int(sum(index in labels for labels in accepted_sets))
        for index, name in enumerate(PRIMARY_RHYTHMS)
    }
    single_support = {
        name: int(sum(labels == {index} for labels in accepted_sets))
        for index, name in enumerate(PRIMARY_RHYTHMS)
    }
    return {
        "records": int(len(record_rows)),
        "top1_accepted_accuracy": float(np.mean(accepted_correct)) if len(accepted_correct) else 0.0,
        "membership_support_by_class": support,
        "single_label_support_by_class": single_support,
        "multi_label_records": int(sum(len(labels) > 1 for labels in accepted_sets)),
        "single_label_records": int(sum(len(labels) == 1 for labels in accepted_sets)),
        "binary_panels": panels,
        "binary_panel_macro_f1": float(np.mean([float(panel["f1"]) for panel in panels.values()])),
        "binary_panel_balanced_accuracy": float(np.mean([float(panel["balanced_accuracy"]) for panel in panels.values()])),
        "diagnostic_single_target_accuracy": float(accuracy_score(y_true, y_pred)) if len(y_true) else 0.0,
        "diagnostic_single_target_macro_f1": _safe_f1(y_true, y_pred, primary_indices),
        "single_label_subset_accuracy": (
            float(accuracy_score(single_true[valid_single], y_pred[valid_single]))
            if np.any(valid_single)
            else 0.0
        ),
        "single_label_subset_macro_f1": (
            _safe_f1(single_true[valid_single], y_pred[valid_single], sorted(set(single_true[valid_single].tolist())))
            if np.any(valid_single)
            else 0.0
        ),
        "not_too_strict_gate": {
            "primary_decision_view": "top1_accepted_accuracy + binary_panel_macro_f1",
            "passed_soft": bool(
                (float(np.mean(accepted_correct)) if len(accepted_correct) else 0.0) >= 0.80
                and float(np.mean([float(panel["f1"]) for panel in panels.values()])) >= 0.60
            ),
            "criteria": {
                "top1_accepted_accuracy": ">=0.80",
                "binary_panel_macro_f1": ">=0.60",
            },
        },
    }


def _evaluate_rhythm_view(
    *,
    name: str,
    manifest_csv: str | Path,
    data_root: str | Path,
    model: torch.nn.Module,
    device: torch.device,
    output_dir: Path,
    num_workers: int,
    morphology_dim: int,
) -> dict[str, object]:
    record_labels = load_manifest_record_labels(str(manifest_csv), data_root=str(data_root))
    data_dirs, rows_by_record = _record_dirs_from_manifest(manifest_csv, data_root)
    clinical_axes = _clinical_axis_map(rows_by_record)
    dataset = ClinicalECGDataset(
        data_dirs,
        target_length=TARGET_LENGTH,
        augment=False,
        record_label_map=record_labels,
        skip_unlabeled=True,
        return_morphology=morphology_dim > 0,
        return_window_key=True,
    )
    loader = DataLoader(
        dataset,
        batch_size=32,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=device.type == "cuda",
    )
    criterion_rhythm = FocalLoss(alpha=torch.ones(NUM_RHYTHM_CLASSES, device=device), gamma=2.0, label_smoothing=0.0)
    result = evaluate_multihead_epoch(
        model,
        loader,
        device,
        criterion_rhythm=criterion_rhythm,
        criterion_quality=nn.BCELoss(),
        criterion_pathology=nn.BCEWithLogitsLoss(),
        pathology_record_to_multihot={},
        clinical_axis_record_to_multihot=clinical_axes,
        lambda_pathology=1.0,
        lambda_clinical_axes=0.0,
    )
    record_rows, y_true, y_pred, _confidence = _aggregate_records(result, rows_by_record)
    gate = _membership_gate(record_rows, y_true, y_pred)
    view_dir = output_dir / name
    view_dir.mkdir(parents=True, exist_ok=True)
    _write_rows(view_dir / "record_predictions.csv", record_rows)
    cm = confusion_matrix(y_true, y_pred, labels=list(range(NUM_RHYTHM_CLASSES)))
    np.savetxt(view_dir / "single_target_confusion_matrix.csv", cm, delimiter=",", fmt="%d")
    report = {
        "view": name,
        "manifest_csv": str(manifest_csv),
        "record_labels": len(record_labels),
        "records_evaluated": int(len(record_rows)),
        "windows_evaluated": int(len(dataset)),
        "data_dirs_scanned": len(data_dirs),
        "target_fs_hz": 125,
        "input_shape": "12x1250",
        "loss": float(result.get("loss", 0.0)),
        "window_single_target_accuracy": float(result.get("rhythm_accuracy", 0.0)),
        "window_single_target_macro_f1": float(result.get("rhythm_macro_f1", 0.0)),
        "record_single_target_accuracy": float(accuracy_score(y_true, y_pred)) if len(y_true) else 0.0,
        "record_single_target_macro_f1": _safe_f1(y_true, y_pred, list(range(len(PRIMARY_RHYTHMS)))),
        "clinical_axis_macro_f1": float(result.get("clinical_axis_macro_f1", 0.0)),
        "clinical_axis_by_axis": result.get("clinical_axis_by_axis", {}),
        "membership_gate": gate,
    }
    (view_dir / "metrics.json").write_text(json.dumps(json_ready(report), indent=2), encoding="utf-8")
    return report


def _evaluate_pathology_panels(
    *,
    panel_index_json: str | Path,
    data_root: str | Path,
    model: torch.nn.Module,
    device: torch.device,
    output_dir: Path,
    num_workers: int,
    morphology_dim: int,
    pathology_thresholds: Mapping[str, float] | None = None,
) -> dict[str, object]:
    index = json.loads(Path(panel_index_json).read_text(encoding="utf-8"))
    panels = index.get("panels") or {}
    if set(panels) != set(PRIMARY_PATHOLOGIES):
        raise ValueError("pathology panel index must contain exactly primary4 panels")

    criterion_rhythm = FocalLoss(alpha=torch.ones(NUM_RHYTHM_CLASSES, device=device), gamma=2.0, label_smoothing=0.0)
    out: dict[str, dict[str, float | int | str]] = {}
    for pathology_name in PRIMARY_PATHOLOGIES:
        panel_csv = panels[pathology_name]
        labels = load_manifest_pathology_labels(panel_csv, data_root=str(data_root))
        data_dirs, _rows_by_record = _record_dirs_from_manifest(panel_csv, data_root)
        pseudo_rhythm = {record: 0 for record in labels}
        dataset = ClinicalECGDataset(
            data_dirs,
            target_length=TARGET_LENGTH,
            augment=False,
            record_label_map=pseudo_rhythm,
            skip_unlabeled=True,
            return_morphology=morphology_dim > 0,
        )
        loader = DataLoader(
            dataset,
            batch_size=32,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=device.type == "cuda",
        )
        result = evaluate_multihead_epoch(
            model,
            loader,
            device,
            criterion_rhythm=criterion_rhythm,
            criterion_quality=nn.BCELoss(),
            criterion_pathology=nn.BCEWithLogitsLoss(),
            pathology_record_to_multihot=labels,
            lambda_pathology=1.0,
        )
        index_in_head = ACTIVE_PATHOLOGIES.index(pathology_name)
        truth = np.asarray(result["pathology_y_true"], dtype=np.float64)[:, index_in_head].astype(bool)
        threshold = float((pathology_thresholds or {}).get(pathology_name, 0.5))
        pred = np.asarray(result["pathology_probability"], dtype=np.float64)[:, index_in_head] >= threshold
        metrics = _binary_metrics(truth, pred)
        metrics["threshold"] = threshold
        metrics["records"] = int(len(labels))
        metrics["windows"] = int(len(dataset))
        metrics["manifest_csv"] = str(panel_csv)
        out[pathology_name] = metrics
    report = {
        "protocol": "TITAN_V45_V3C_EXTERNAL_PATHOLOGY4_BALANCED_PANELS",
        "panels": out,
        "pathology4_macro_f1": float(np.mean([float(panel["f1"]) for panel in out.values()])),
        "pathology4_balanced_accuracy": float(np.mean([float(panel["balanced_accuracy"]) for panel in out.values()])),
        "pathology4_accuracy": float(np.mean([float(panel["accuracy"]) for panel in out.values()])),
        "threshold_mode": "internal_checkpoint" if pathology_thresholds else "fixed_0_5",
    }
    (output_dir / "pathology4_balanced_panels.json").write_text(json.dumps(json_ready(report), indent=2), encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data_root", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--manifest_index_json", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--num_workers", type=int, default=2)
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest_index = json.loads(Path(args.manifest_index_json).read_text(encoding="utf-8"))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    saved = torch.load(args.checkpoint, map_location=device)
    if int(saved.get("num_rhythm", 0)) != NUM_RHYTHM_CLASSES:
        raise ValueError("checkpoint rhythm head is incompatible with V3C")
    if int(saved.get("num_pathology", 0)) != NUM_PATHOLOGY_CLASSES:
        raise ValueError("checkpoint pathology head is incompatible with V3C")
    morphology_dim = int(saved.get("morphology_dim", 0) or 0)
    model = build_titan_v45_multihead(morphology_dim=morphology_dim).to(device)
    model.load_state_dict(saved["state_dict"])
    model.eval()
    pathology_thresholds = {
        str(key): float(value)
        for key, value in (saved.get("metrics", {}).get("optimal_thresholds", {}) or {}).items()
    }

    rhythm_views = {
        "primary8_multilabel_accepted_balanced": manifest_index["primary8_multilabel_accepted_balanced"],
        "primary8_model_ready_balanced": manifest_index["primary8_model_ready_balanced"],
        "primary8_strict_balanced": manifest_index["primary8_strict_balanced"],
    }
    rhythm_reports = {
        name: _evaluate_rhythm_view(
            name=name,
            manifest_csv=manifest,
            data_root=args.data_root,
            model=model,
            device=device,
            output_dir=output_dir,
            num_workers=args.num_workers,
            morphology_dim=morphology_dim,
        )
        for name, manifest in rhythm_views.items()
    }
    pathology = _evaluate_pathology_panels(
        panel_index_json=manifest_index["pathology4_panel_index"],
        data_root=args.data_root,
        model=model,
        device=device,
        output_dir=output_dir,
        num_workers=args.num_workers,
        morphology_dim=morphology_dim,
        pathology_thresholds=pathology_thresholds,
    )
    main_view = rhythm_reports["primary8_multilabel_accepted_balanced"]["membership_gate"]
    report = {
        "protocol": "TITAN_V45_V3C_ADAPTED_EXTERNAL_EVALUATION",
        "checkpoint": str(args.checkpoint),
        "manifest_index_json": str(args.manifest_index_json),
        "device": str(device),
        "morphology_dim": morphology_dim,
        "primary_gate_view": "primary8_multilabel_accepted_balanced",
        "primary_gate_not_too_strict": main_view["not_too_strict_gate"],
        "rhythm": rhythm_reports,
        "pathology4": pathology,
        "recommended_interpretation": {
            "main_p8_metric": "rhythm.primary8_multilabel_accepted_balanced.membership_gate.top1_accepted_accuracy",
            "main_p8_macro_metric": "rhythm.primary8_multilabel_accepted_balanced.membership_gate.binary_panel_macro_f1",
            "strict_single_label": "secondary audit only",
            "pathology4": "separate balanced binary panels",
        },
    }
    (output_dir / "external_v3c_adapted_report.json").write_text(json.dumps(json_ready(report), indent=2), encoding="utf-8")
    print(json.dumps(json_ready({
        "output_dir": str(output_dir),
        "primary_gate_view": report["primary_gate_view"],
        "top1_accepted_accuracy": main_view["top1_accepted_accuracy"],
        "binary_panel_macro_f1": main_view["binary_panel_macro_f1"],
        "pathology4_macro_f1": pathology["pathology4_macro_f1"],
    }), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
