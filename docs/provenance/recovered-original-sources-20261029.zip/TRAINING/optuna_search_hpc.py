"""TITAN V4.5 41M multi-head Optuna search for CEDIA HPC."""

from __future__ import annotations

import argparse
import gc
import json
import os
import random
import shutil
import sys
from pathlib import Path
from statistics import mean, pstdev
from typing import Mapping, Sequence

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import f1_score
from torch.utils.data import DataLoader, Subset, WeightedRandomSampler

SOURCE_ROOT = Path(__file__).resolve().parents[1]
if str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

from DATA_PIPELINE.data_loader_ultra import ClinicalECGDataset, SNOMED_MAPPING, TARGET_LENGTH
from REGISTRIES.label_registry import RHYTHM_CLASS_NAMES, normalize_record_path
from UTILS_MANAGER.morphology_features import MORPHOLOGY_FEATURE_DIM
from TRAINING.titan_v45_multihead_contract import (
    ACTIVE_PATHOLOGIES,
    NUM_PATHOLOGY_CLASSES,
    NUM_RHYTHM_CLASSES,
    PRIMARY4_OBJECTIVE_WEIGHT,
    PRIMARY8_OBJECTIVE_WEIGHT,
    PRIMARY_MISSING_PENALTY,
    PRIMARY_PATHOLOGIES,
    PRIMARY_RHYTHMS,
    load_active_pathology_label_map,
    load_manifest_clinical_axis_label_map,
    pathology_targets_for_paths,
    resolve_data_contract,
    validate_data_contract,
)
from TRAINING.titan_v45_multihead_runtime import (
    build_titan_v45_multihead,
    evaluate_multihead_epoch,
    model_parameter_count,
    train_multihead_epoch,
)
from TRAINING.titan_v45_multistage import SEARCH_PROFILES, search_profile_payload
from TRAINING.train_v4_lite import FocalLoss, load_offline_teacher_tables
from TRAINING.optuna_trial_resume import (
    checkpoint_path_for_params,
    load_training_checkpoint,
    save_training_checkpoint,
)
from TRAINING.training_utils import (
    RecordSplit,
    build_record_splits,
    compute_class_weights,
    compute_primary8_primary4_sample_weights,
    compute_sample_weights,
    labels_for_indices,
    load_manifest_record_labels,
    load_manifest_sampler_weights,
    load_record_split_from_manifests,
    split_window_indices_by_record,
)

try:
    import optuna
except ModuleNotFoundError:
    optuna = None

BASE_LR_RANGE = (5e-6, 5e-5)
MAX_LR_RANGE = (5e-5, 4e-4)
BATCH_SIZE_CHOICES = (16, 32)


def _parse_int_choices(raw: str) -> tuple[int, ...]:
    values = tuple(int(part.strip()) for part in str(raw).split(",") if part.strip())
    if not values:
        raise ValueError("batch_size_choices must contain at least one integer")
    return values


def _parse_float_weights(raw: str | None, *, expected_len: int, default: float = 1.0) -> list[float]:
    if expected_len <= 0:
        return []
    if raw is None or str(raw).strip() == "":
        return [float(default)] * int(expected_len)
    values = [float(part.strip()) for part in str(raw).split(",") if part.strip()]
    if len(values) != int(expected_len):
        raise ValueError(f"teacher_logits_weight expected {expected_len} values, got {len(values)}")
    return values


def _parse_active_rhythm_labels(raw: str | None) -> tuple[list[str], list[int]]:
    names = [part.strip() for part in str(raw or "").split(",") if part.strip()]
    indices: list[int] = []
    for name in names:
        if name not in RHYTHM_CLASS_NAMES:
            raise ValueError(f"Unknown active rhythm class for Optuna objective: {name}")
        indices.append(int(RHYTHM_CLASS_NAMES.index(name)))
    return names, indices


def _filter_split_excluded_rhythm_classes(split: RecordSplit, excluded_classes: str | None) -> RecordSplit:
    _names, excluded_indices = _parse_active_rhythm_labels(excluded_classes)
    excluded = set(excluded_indices)
    if not excluded:
        return split
    kept_labels = {record: label for record, label in split.record_labels.items() if int(label) not in excluded}
    removed = {record: label for record, label in split.record_labels.items() if int(label) in excluded}
    excluded_records = dict(split.excluded_records)
    for record, label in removed.items():
        excluded_records[record] = f"excluded_rhythm_class:{RHYTHM_CLASS_NAMES[int(label)]}"
    train_records = [record for record in split.train_records if record in kept_labels]
    val_records = [record for record in split.val_records if record in kept_labels]
    train_counts = {label: 0 for label in range(len(RHYTHM_CLASS_NAMES))}
    val_counts = {label: 0 for label in range(len(RHYTHM_CLASS_NAMES))}
    for record in train_records:
        train_counts[int(kept_labels[record])] = int(train_counts.get(int(kept_labels[record]), 0)) + 1
    for record in val_records:
        val_counts[int(kept_labels[record])] = int(val_counts.get(int(kept_labels[record]), 0)) + 1
    return RecordSplit(
        train_records=train_records,
        val_records=val_records,
        record_labels=kept_labels,
        excluded_records=excluded_records,
        train_label_counts={key: value for key, value in train_counts.items() if value},
        val_label_counts={key: value for key, value in val_counts.items() if value},
        val_fraction=split.val_fraction,
        seed=split.seed,
    )


def _augment_active_rhythm_metrics(metrics: dict[str, object], args: argparse.Namespace) -> None:
    names, indices = _parse_active_rhythm_labels(args.active_rhythm_classes)
    if not indices:
        metrics["active_rhythm_macro_f1"] = 0.0
        metrics["active_rhythm_missing_classes"] = 0
        return
    y_true = np.asarray(metrics.get("rhythm_y_true", []), dtype=np.int64)
    y_pred = np.asarray(metrics.get("rhythm_y_pred", []), dtype=np.int64)
    if y_true.size == 0:
        support = [0 for _ in indices]
        active_f1 = 0.0
    else:
        mask = np.isin(y_true, indices)
        filtered_true = y_true[mask]
        filtered_pred = y_pred[mask]
        support = [int(np.sum(filtered_true == index)) for index in indices]
        active_f1 = (
            float(f1_score(filtered_true, filtered_pred, labels=indices, average="macro", zero_division=0))
            if filtered_true.size
            else 0.0
        )
    metrics["active_rhythm_classes"] = names
    metrics["active_rhythm_macro_f1"] = float(active_f1)
    metrics["active_rhythm_support"] = support
    metrics["active_rhythm_missing_classes"] = int(sum(value == 0 for value in support))


def _suggest_float_range(trial, name: str, low: float, high: float, *, log: bool = False) -> float:
    low = float(low)
    high = float(high)
    if low > high:
        raise ValueError(f"{name} low bound cannot exceed high bound")
    if low == high:
        trial.set_user_attr(f"fixed_{name}", low)
        return low
    return float(trial.suggest_float(name, low, high, log=log))


def stage_defaults(stage: str) -> dict[str, object]:
    profile = search_profile_payload(stage)
    return {
        "epochs": profile["epochs"],
        "n_trials": profile["trials"],
        "min_complete_trials": profile["min_complete_trials"],
        "min_promotion_score": profile["min_promotion_score"],
        "top_k": profile["top_k"],
    }


def candidate_seed_params(payload: dict[str, object]) -> list[dict[str, object]]:
    ranked = payload.get("top_candidates") or []
    params = [dict(candidate.get("params") or {}) for candidate in ranked if candidate.get("params")]
    if params:
        return params
    best = dict(payload.get("best_params") or {})
    return [best] if best else []


def _load_candidate_seed_params(path: str | None) -> list[dict[str, object]]:
    if not path:
        return []
    with Path(path).open("r", encoding="utf-8") as handle:
        return candidate_seed_params(json.load(handle))


def _top_complete_trials(study, limit: int) -> list[dict[str, object]]:
    complete = [
        trial
        for trial in study.trials
        if getattr(trial.state, "name", str(trial.state)) == "COMPLETE" and trial.value is not None
    ]
    ranked = sorted(complete, key=lambda trial: float(trial.value), reverse=True)[:limit]
    return [
        {
            "trial_number": int(trial.number),
            "value": float(trial.value),
            "params": dict(trial.params),
            "peak_composite_score": trial.user_attrs.get("peak_composite_score"),
            "tail_composite_scores": list(trial.user_attrs.get("tail_composite_scores") or []),
            "ranking_score": trial.user_attrs.get("ranking_score", float(trial.value)),
            "completed_checkpoint": trial.user_attrs.get("completed_checkpoint", ""),
        }
        for trial in ranked
    ]


def should_prune_collapsed_rhythm(
    primary8_history: list[float],
    *,
    min_epochs: int = 6,
    collapse_window: int = 3,
    learned_floor: float = 0.10,
    collapse_floor: float = 0.01,
) -> bool:
    if len(primary8_history) < min_epochs:
        return False
    earlier = primary8_history[:-collapse_window]
    recent = primary8_history[-collapse_window:]
    return bool(earlier and max(earlier) >= learned_floor and max(recent) < collapse_floor)


def release_trial_resources() -> None:
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def _load_approved_preflight(path: str) -> dict[str, object]:
    with open(path, "r", encoding="utf-8") as handle:
        report = json.load(handle)
    if report.get("protocol") != "TITAN_V45_41M_MULTIHEAD_PREFLIGHT":
        raise ValueError("preflight JSON does not implement the TITAN V4.5 multi-head protocol")
    if not report.get("passed"):
        raise ValueError("preflight JSON is not approved: " + " | ".join(report.get("errors") or []))
    return report


def _structure_from_approved_preflight(contract, preflight: dict[str, object] | None) -> dict[str, object] | None:
    """Reuse the already-approved HPC preflight contract instead of rescanning NFS.

    The fallback remains the full structural validator. This cache is accepted
    only when the resolved discovery/external dataset names match the approved
    preflight artifact.
    """

    if not preflight or preflight.get("passed") is not True:
        return None
    discovery = preflight.get("discovery")
    external = preflight.get("external_gate")
    external_pathology = preflight.get("external_pathology_gate")
    if not isinstance(discovery, dict) or not isinstance(external, dict) or not isinstance(external_pathology, dict):
        return None
    discovery_names = [path.name for path in contract.discovery_paths]
    external_names = [path.name for path in contract.external_paths]
    external_pathology_names = [path.name for path in contract.external_pathology_paths]
    if discovery.get("datasets") != discovery_names:
        return None
    if external.get("datasets") != external_names:
        return None
    if external_pathology.get("datasets") != external_pathology_names:
        return None
    return {
        "data_root": str(contract.data_root),
        "discovery_datasets": discovery_names,
        "external_gate_datasets": external_names,
        "external_pathology_gate_datasets": external_pathology_names,
        "discovery_headers": int(discovery.get("headers") or 0),
        "external_headers": int(external.get("headers") or 0),
        "external_pathology_headers": int(external_pathology.get("headers") or 0),
        "overlap_records": 0,
    }


def _capped_indices(indices, cap: int, seed: int) -> list[int]:
    if cap <= 0 or len(indices) <= cap:
        return list(indices)
    rng = np.random.default_rng(seed)
    return sorted(rng.choice(indices, size=cap, replace=False).tolist())


def _is_virtual_window_index(dataset, index: int) -> bool:
    if hasattr(dataset, "split_key_for_index"):
        return str(dataset.split_key_for_index(index)).startswith("virtual::")
    if hasattr(dataset, "window_key_for_index"):
        return str(dataset.window_key_for_index(index)).startswith("virtual::")
    return False


def _indices_for_manifest_panel(dataset, candidate_indices, manifest_csv: str, *, data_root: str) -> list[int]:
    panel_records = set(load_manifest_record_labels(manifest_csv, data_root=data_root))
    if not panel_records:
        raise ValueError(f"balanced validation panel is empty: {manifest_csv}")
    selected = []
    for index in candidate_indices:
        if hasattr(dataset, "split_key_for_index"):
            record_key = str(dataset.split_key_for_index(index))
        else:
            record_key = normalize_record_path(dataset.windows[index][0])
        if record_key in panel_records:
            selected.append(index)
    if not selected:
        raise ValueError(f"balanced validation panel has no dataset windows: {manifest_csv}")
    discovered_records = {
        str(dataset.split_key_for_index(index)) if hasattr(dataset, "split_key_for_index") else normalize_record_path(dataset.windows[index][0])
        for index in selected
    }
    missing = panel_records.difference(discovered_records)
    if missing:
        preview = ", ".join(sorted(missing)[:3])
        raise ValueError(f"balanced validation panel records are absent from the frozen validation split: {preview}")
    return selected


def _pathology_panel_indices(dataset, candidate_indices, panel_index_json: str, *, data_root: str) -> dict[str, list[int]]:
    with Path(panel_index_json).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    panels = dict(payload.get("panels") or {})
    missing = [label for label in PRIMARY_PATHOLOGIES if not panels.get(label)]
    if missing:
        raise ValueError(f"pathology panel index is missing primary labels: {missing}")
    return {
        label: _indices_for_manifest_panel(dataset, candidate_indices, panels[label], data_root=data_root)
        for label in PRIMARY_PATHOLOGIES
    }


def cap_virtual_window_fraction(
    *,
    dataset,
    indices,
    max_virtual_fraction: float,
    seed: int,
) -> list[int]:
    """Cap virtual-window dominance inside a frozen Optuna subset.

    The external gate remains untouched. This only limits how many derived
    virtual windows can dominate the internal discovery search subset.
    """

    max_virtual_fraction = float(max_virtual_fraction)
    if max_virtual_fraction < 0.0 or max_virtual_fraction > 1.0:
        raise ValueError("max_virtual_fraction must be within [0.0, 1.0]")
    if max_virtual_fraction >= 1.0:
        return sorted(int(index) for index in indices)
    virtual = [int(index) for index in indices if _is_virtual_window_index(dataset, int(index))]
    physical = [int(index) for index in indices if not _is_virtual_window_index(dataset, int(index))]
    if not virtual:
        return sorted(int(index) for index in indices)
    if max_virtual_fraction == 0.0:
        return sorted(physical)
    if not physical:
        return []
    max_virtual = int((max_virtual_fraction * len(physical)) / max(1e-9, 1.0 - max_virtual_fraction))
    max_virtual = max(0, min(len(virtual), max_virtual))
    if len(virtual) <= max_virtual:
        return sorted(int(index) for index in indices)
    rng = np.random.default_rng(seed)
    kept_virtual = rng.choice(virtual, size=max_virtual, replace=False).astype(int).tolist() if max_virtual else []
    return sorted(physical + kept_virtual)


def freeze_search_indices(
    *,
    train_dataset=None,
    val_dataset=None,
    train_indices,
    val_indices,
    max_train_windows: int,
    max_val_windows: int,
    max_train_virtual_fraction: float = 1.0,
    max_val_virtual_fraction: float = 1.0,
    seed: int,
) -> dict[str, list[int]]:
    train = _capped_indices(train_indices, max_train_windows, seed)
    val = _capped_indices(val_indices, max_val_windows, seed + 1000)
    if train_dataset is not None:
        train = cap_virtual_window_fraction(
            dataset=train_dataset,
            indices=train,
            max_virtual_fraction=max_train_virtual_fraction,
            seed=seed + 2000,
        )
    if val_dataset is not None:
        val = cap_virtual_window_fraction(
            dataset=val_dataset,
            indices=val,
            max_virtual_fraction=max_val_virtual_fraction,
            seed=seed + 3000,
        )
    return {
        "train_indices": train,
        "val_indices": val,
    }


def stable_tail_score(scores: list[float], *, tail_epochs: int = 3, std_penalty: float = 0.25) -> float:
    tail = [float(value) for value in scores[-tail_epochs:]]
    if not tail:
        raise ValueError("stable tail score requires at least one epoch")
    return float(mean(tail) - std_penalty * pstdev(tail))


def objective_score(
    metrics: dict[str, object],
    *,
    active_rhythm_weight: float = 0.0,
    active_rhythm_floor: float = 0.0,
    active_rhythm_floor_penalty: float = 0.0,
    clinical_axis_weight: float = 0.0,
) -> float:
    """Rank candidates only by the reportable primary endpoints."""

    base_score = (
        PRIMARY8_OBJECTIVE_WEIGHT * float(metrics.get("primary8_macro_f1", 0.0))
        + PRIMARY4_OBJECTIVE_WEIGHT * float(metrics.get("pathology4_macro_f1", 0.0))
    )
    active_weight = float(active_rhythm_weight)
    active_score = float(metrics.get("active_rhythm_macro_f1", 0.0))
    if active_weight > 0.0:
        score = (1.0 - active_weight) * base_score + active_weight * active_score
        if active_score < float(active_rhythm_floor):
            score -= float(active_rhythm_floor_penalty) * (float(active_rhythm_floor) - active_score)
    else:
        score = base_score
    axis_weight = float(clinical_axis_weight)
    if axis_weight > 0.0:
        axis_score = float(metrics.get("clinical_axis_macro_f1", 0.0))
        score = (1.0 - axis_weight) * score + axis_weight * axis_score
    score -= PRIMARY_MISSING_PENALTY * int(metrics.get("missing_primary_rhythm_classes", 0))
    score -= PRIMARY_MISSING_PENALTY * int(metrics.get("missing_primary_pathology_labels", 0))
    return float(score)


def merge_primary_panel_metrics(rhythm_panel: dict[str, object], pathology_panel: dict[str, object]) -> dict[str, object]:
    """Compose Optuna's objective strictly from its dedicated P8 and P4 panels."""
    merged = dict(rhythm_panel)
    pathology_keys = {
        "primary_pathology_macro_f1",
        "pathology4_macro_f1",
        "pathology4_labelwise_accuracy",
        "pathology_macro_f1",
        "pathology7_macro_f1",
        "pathology4_by_label",
        "pathology_y_true",
        "pathology_probability",
        "missing_primary_pathology_labels",
    }
    for key in pathology_keys:
        if key in pathology_panel:
            merged[key] = pathology_panel[key]
    merged["loss"] = 0.5 * (float(rhythm_panel.get("loss", 0.0)) + float(pathology_panel.get("loss", 0.0)))
    rhythm_support = dict(rhythm_panel.get("full_support") or {})
    pathology_support = dict(pathology_panel.get("full_support") or {})
    if rhythm_support or pathology_support:
        merged["full_support"] = {
            "rhythm_primary8": rhythm_support.get("rhythm_primary8"),
            "rhythm_all": rhythm_support.get("rhythm_all"),
            "pathology_primary4": pathology_support.get("pathology_primary4"),
            "pathology_all": pathology_support.get("pathology_all"),
        }
    return merged


def aggregate_primary4_panel_metrics(panel_results: dict[str, dict[str, object]]) -> dict[str, object]:
    """Average binary P4 metrics from four independently balanced pathology panels."""
    by_label: dict[str, dict[str, float | int]] = {}
    for label in PRIMARY_PATHOLOGIES:
        result = panel_results.get(label)
        if result is None:
            raise ValueError(f"missing pathology panel result for {label}")
        index = ACTIVE_PATHOLOGIES.index(label)
        true = np.asarray(result["pathology_y_true"], dtype=np.int64)
        probability = np.asarray(result["pathology_probability"], dtype=np.float64)
        if true.ndim != 2 or probability.ndim != 2 or true.shape != probability.shape or true.shape[0] == 0:
            raise ValueError(f"pathology panel {label} returned no aligned labels and probabilities")
        target = true[:, index]
        prediction = (probability[:, index] >= 0.5).astype(np.int64)
        positives = int(target.sum())
        negatives = int(target.size - positives)
        by_label[label] = {
            "f1": float(f1_score(target, prediction, zero_division=0)),
            "accuracy": float((target == prediction).mean()),
            "positive_support": positives,
            "negative_support": negatives,
        }
    missing = sum(1 for metrics in by_label.values() if not metrics["positive_support"] or not metrics["negative_support"])
    return {
        "primary_pathology_macro_f1": float(mean(metrics["f1"] for metrics in by_label.values())),
        "pathology4_macro_f1": float(mean(metrics["f1"] for metrics in by_label.values())),
        "pathology4_labelwise_accuracy": float(mean(metrics["accuracy"] for metrics in by_label.values())),
        "missing_primary_pathology_labels": int(missing),
        "pathology4_by_label": by_label,
        "full_support": {"pathology_primary4": by_label},
    }


def objective_description() -> str:
    return (
        f"{PRIMARY8_OBJECTIVE_WEIGHT:.3g} * primary8_macro_f1 + "
        f"{PRIMARY4_OBJECTIVE_WEIGHT:.3g} * pathology4_macro_f1 - "
        f"{PRIMARY_MISSING_PENALTY:.3g} * missing_primary_rhythm_classes - "
        f"{PRIMARY_MISSING_PENALTY:.3g} * missing_primary_pathology_labels"
    )


def build_optuna_sampler(*, seed: int):
    if optuna is None:
        raise RuntimeError("Optuna is not installed")
    return optuna.samplers.TPESampler(seed=seed, multivariate=True, n_startup_trials=10)


def sampler_seed_for_existing_trials(base_seed: int, persisted_trial_count: int) -> int:
    """Give each sequential Slurm invocation a distinct TPE startup sequence."""
    if persisted_trial_count < 0:
        raise ValueError("persisted_trial_count cannot be negative")
    return int(base_seed) + int(persisted_trial_count)


def build_optuna_pruner(stage: str):
    if optuna is None:
        raise RuntimeError("Optuna is not installed")
    if stage == "screening":
        return optuna.pruners.MedianPruner(n_startup_trials=10, n_warmup_steps=4)
    if stage == "screening_v5":
        return optuna.pruners.MedianPruner(n_startup_trials=8, n_warmup_steps=6)
    if stage == "refinement":
        return optuna.pruners.MedianPruner(n_startup_trials=5, n_warmup_steps=8)
    if stage == "confirmation":
        return optuna.pruners.NopPruner()
    raise ValueError(f"unsupported Optuna pruning stage: {stage}")


def _set_reproducible_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _pathology_pos_weight(record_paths, pathology_map, max_weight: float) -> list[float]:
    targets, mask = pathology_targets_for_paths(record_paths, pathology_map)
    labeled = targets[mask]
    if labeled.size == 0:
        raise ValueError("discovery has no active pathology labels")
    positive = labeled.sum(axis=0)
    if np.any(positive == 0):
        missing = [ACTIVE_PATHOLOGIES[index] for index, count in enumerate(positive) if count == 0]
        raise ValueError(f"discovery training split is missing pathology labels: {missing}")
    negative = labeled.shape[0] - positive
    return np.clip(negative / np.maximum(positive, 1.0), 1.0, float(max_weight)).astype(np.float32).tolist()


def compute_multitask_sample_weights(
    *,
    rhythm_labels,
    record_paths,
    pathology_map,
    max_rhythm_weight: float,
    max_pathology_weight: float,
    pathology_fraction: float,
) -> list[float]:
    """Blend rhythm balancing with pathology-label balancing for Optuna batches."""

    rhythm_weights = np.asarray(
        compute_sample_weights(rhythm_labels, NUM_RHYTHM_CLASSES, max_weight=max_rhythm_weight),
        dtype=np.float64,
    )
    pathology_fraction = float(pathology_fraction)
    if pathology_fraction <= 0.0:
        return rhythm_weights.astype(float).tolist()
    targets, mask = pathology_targets_for_paths(record_paths, pathology_map)
    pathology_weights = np.ones((len(record_paths),), dtype=np.float64)
    if np.any(mask):
        labeled_targets = targets[mask]
        positive = labeled_targets.sum(axis=0)
        negative = labeled_targets.shape[0] - positive
        label_weights = np.ones((NUM_PATHOLOGY_CLASSES,), dtype=np.float64)
        present = positive > 0
        label_weights[present] = np.clip(
            negative[present] / np.maximum(positive[present], 1.0),
            1.0,
            float(max_pathology_weight),
        )
        positive_mass = (targets * label_weights.reshape(1, -1)).sum(axis=1)
        positive_count = np.maximum(targets.sum(axis=1), 1.0)
        pathology_weights = np.where(targets.sum(axis=1) > 0, positive_mass / positive_count, 1.0)
    combined = (1.0 - pathology_fraction) * rhythm_weights + pathology_fraction * pathology_weights
    mean_weight = float(np.mean(combined)) if combined.size else 1.0
    if mean_weight > 0.0:
        combined = combined / mean_weight
    return np.clip(combined, 0.01, max(float(max_rhythm_weight), float(max_pathology_weight))).astype(float).tolist()


def _manifest_sampler_keys_for_window(dataset, index: int) -> list[str]:
    keys: list[str] = []
    if hasattr(dataset, "split_key_for_index"):
        keys.append(str(dataset.split_key_for_index(index)))
    record_base, _window_start = dataset.windows[index]
    record_base = str(record_base)
    keys.append(record_base)
    keys.append(normalize_record_path(record_base))
    deduped: list[str] = []
    seen: set[str] = set()
    for key in keys:
        if key and key not in seen:
            deduped.append(key)
            seen.add(key)
    return deduped


def manifest_sample_weights_for_indices(
    *,
    train_dataset,
    train_indices,
    manifest_sampler_weights: dict[str, float],
) -> list[float]:
    """Map per-record manifest sampler weights onto concrete training windows."""

    weights: list[float] = []
    missing: list[str] = []
    for index in train_indices:
        value = None
        candidates = _manifest_sampler_keys_for_window(train_dataset, int(index))
        for key in candidates:
            if key in manifest_sampler_weights:
                value = float(manifest_sampler_weights[key])
                break
        if value is None:
            missing.append(candidates[0] if candidates else str(index))
            continue
        if value <= 0.0:
            raise ValueError(f"Manifest sampler_weight must be positive for train window {index}")
        weights.append(value)
    if missing:
        preview = ", ".join(missing[:5])
        raise ValueError(f"Manifest sampler weights missing for {len(missing)} train windows: {preview}")
    return weights


def resolve_training_sample_weights(
    *,
    train_dataset,
    train_indices,
    train_labels,
    train_record_paths,
    pathology_map,
    max_rhythm_weight: float,
    max_pathology_weight: float,
    pathology_fraction: float,
    manifest_sampler_weights: dict[str, float] | None = None,
) -> tuple[list[float], str]:
    if len(train_record_paths) == len(train_labels):
        pathology_targets, pathology_known = pathology_targets_for_paths(train_record_paths, pathology_map)
    else:
        pathology_targets = np.zeros((len(train_labels), len(ACTIVE_PATHOLOGIES)), dtype=np.float32)
        pathology_known = np.zeros(len(train_labels), dtype=bool)
    weight_cap = max(float(max_rhythm_weight), float(max_pathology_weight))
    weights = np.asarray(
        compute_primary8_primary4_sample_weights(
            train_labels,
            pathology_targets=pathology_targets,
            pathology_known=pathology_known,
            num_primary_classes=len(PRIMARY_RHYTHMS),
            cascade_fraction=0.20,
            pathology_fraction=float(pathology_fraction),
            max_weight=weight_cap,
        ),
        dtype=np.float64,
    )
    sampler_source = "primary8_primary4_balanced"
    if manifest_sampler_weights:
        manifest_weights = np.asarray(
            manifest_sample_weights_for_indices(
                train_dataset=train_dataset,
                train_indices=train_indices,
                manifest_sampler_weights=manifest_sampler_weights,
            ),
            dtype=np.float64,
        )
        if manifest_weights.shape != weights.shape:
            raise ValueError("Manifest sampler weights must align with train labels")
        weights = weights * manifest_weights
        mean_weight = float(weights.mean()) if weights.size else 1.0
        if mean_weight > 0.0:
            weights = weights / mean_weight
        weights = np.clip(weights, 0.01, weight_cap)
        sampler_source = "primary8_primary4_balanced+manifest_sampler"
    return weights.astype(float).tolist(), sampler_source


def merge_clinical_axis_maps(*maps: Mapping[str, Mapping[str, Sequence[float]]]) -> dict[str, dict[str, np.ndarray]]:
    merged: dict[str, dict[str, np.ndarray]] = {}
    for axis_map in maps:
        for record, axes in axis_map.items():
            current = merged.setdefault(str(record), {})
            for axis, vector in axes.items():
                values = np.asarray(vector, dtype=np.float32)
                if axis in current:
                    current[axis] = np.maximum(current[axis], values)
                else:
                    current[axis] = values
    return merged


def build_search_context(args: argparse.Namespace) -> dict[str, object]:
    contract = resolve_data_contract(args.data_root, external_dataset=args.external_dataset)
    structure = _structure_from_approved_preflight(contract, getattr(args, "_approved_preflight", None))
    if structure is None:
        print("Validating data contract by scanning WFDB headers...", flush=True)
        structure = validate_data_contract(contract)
    else:
        print("Using approved preflight data contract cache; skipping repeated WFDB tree scan.", flush=True)
    data_paths = [str(path) for path in contract.discovery_paths]
    print(f"Discovery datasets: {[Path(path).name for path in data_paths]}", flush=True)
    print(f"External gate dataset reserved: {[path.name for path in contract.external_paths]}", flush=True)
    if bool(args.train_manifest_csv) != bool(args.val_manifest_csv):
        raise ValueError("train_manifest_csv and val_manifest_csv must be provided together")
    manifest_split = bool(args.train_manifest_csv and args.val_manifest_csv)
    if manifest_split:
        print(
            f"Using manifest record split: train={args.train_manifest_csv} val={args.val_manifest_csv}",
            flush=True,
        )
        split = load_record_split_from_manifests(
            args.train_manifest_csv,
            args.val_manifest_csv,
            data_root=args.data_root,
            seed=args.seed,
        )
        train_manifest_sampler_weights = load_manifest_sampler_weights(
            args.train_manifest_csv,
            data_root=args.data_root,
        )
        if train_manifest_sampler_weights:
            print(
                f"Using manifest sampler weights for {len(train_manifest_sampler_weights)} train records",
                flush=True,
            )
    else:
        split = build_record_splits(
            data_paths,
            SNOMED_MAPPING,
            val_fraction=args.val_fraction,
            seed=args.seed,
            unknown_policy="skip",
        )
        train_manifest_sampler_weights = {}
    split = _filter_split_excluded_rhythm_classes(split, args.exclude_rhythm_classes)
    if not split.train_records or not split.val_records:
        raise ValueError("excluded rhythm classes removed all train or validation records")
    train_dataset = ClinicalECGDataset(
        data_paths,
        target_length=TARGET_LENGTH,
        augment=True,
        record_label_map=split.record_labels,
        skip_unlabeled=True,
        return_morphology=bool(args.use_morphology_features),
        return_window_key=bool(args.teacher_logits_npz),
    )
    val_dataset = ClinicalECGDataset(
        data_paths,
        target_length=TARGET_LENGTH,
        augment=False,
        record_label_map=split.record_labels,
        skip_unlabeled=True,
        return_morphology=bool(args.use_morphology_features),
        return_window_key=bool(args.teacher_logits_npz),
    )
    train_indices, val_indices, _ = split_window_indices_by_record(train_dataset, split)
    if not train_indices or not val_indices:
        raise ValueError("record-level split generated an empty train or validation set")
    frozen = freeze_search_indices(
        train_dataset=train_dataset,
        val_dataset=val_dataset,
        train_indices=train_indices,
        val_indices=val_indices,
        max_train_windows=args.max_train_windows,
        max_val_windows=args.max_val_windows,
        max_train_virtual_fraction=args.max_train_virtual_fraction,
        max_val_virtual_fraction=args.max_val_virtual_fraction,
        seed=args.seed,
    )
    pathology_map = load_active_pathology_label_map(contract.discovery_paths)
    clinical_axis_maps = []
    for manifest in (args.train_manifest_csv, args.val_manifest_csv, args.rhythm_val_manifest_csv):
        if manifest:
            clinical_axis_maps.append(load_manifest_clinical_axis_label_map(manifest, data_root=args.data_root))
    clinical_axis_map = merge_clinical_axis_maps(*clinical_axis_maps)
    if clinical_axis_map:
        print(f"Using V3C clinical-axis labels for {len(clinical_axis_map)} records", flush=True)
    rhythm_panel_indices = (
        _indices_for_manifest_panel(
            val_dataset,
            frozen["val_indices"],
            args.rhythm_val_manifest_csv,
            data_root=args.data_root,
        )
        if args.rhythm_val_manifest_csv
        else list(frozen["val_indices"])
    )
    pathology_panel_indices = (
        _pathology_panel_indices(
            val_dataset,
            frozen["val_indices"],
            args.pathology_panel_index_json,
            data_root=args.data_root,
        )
        if args.pathology_panel_index_json
        else {label: list(frozen["val_indices"]) for label in PRIMARY_PATHOLOGIES}
    )
    train_virtual = sum(_is_virtual_window_index(train_dataset, index) for index in frozen["train_indices"])
    val_virtual = sum(_is_virtual_window_index(val_dataset, index) for index in frozen["val_indices"])
    return {
        "structure": structure,
        "train_dataset": train_dataset,
        "val_dataset": val_dataset,
        "train_indices": train_indices,
        "val_indices": val_indices,
        "search_train_indices": frozen["train_indices"],
        "search_val_indices": frozen["val_indices"],
        "search_rhythm_val_indices": rhythm_panel_indices,
        "search_pathology_val_indices": pathology_panel_indices,
        "search_train_virtual_windows": train_virtual,
        "search_val_virtual_windows": val_virtual,
        "record_labels": split.record_labels,
        "pathology_map": pathology_map,
        "clinical_axis_map": clinical_axis_map,
        "manifest_split": manifest_split,
        "train_manifest_sampler_weights": train_manifest_sampler_weights,
        "excluded_rhythm_classes": _parse_active_rhythm_labels(args.exclude_rhythm_classes)[0],
    }


def objective(trial, args: argparse.Namespace, context: dict[str, object]) -> float:
    lr_base = trial.suggest_float("base_lr", *BASE_LR_RANGE, log=True)
    max_lr_base = trial.suggest_float("max_lr", *MAX_LR_RANGE, log=True)
    weight_decay = trial.suggest_float("weight_decay", 1e-6, 5e-3, log=True)
    gamma = _suggest_float_range(trial, "gamma", args.gamma_min, args.gamma_max)
    label_smoothing = _suggest_float_range(
        trial,
        "label_smoothing",
        args.label_smoothing_min,
        args.label_smoothing_max,
    )
    batch_size = trial.suggest_categorical("batch_size", list(args.batch_size_choices_tuple))
    mixup_alpha = _suggest_float_range(trial, "mixup_alpha", args.mixup_min, args.mixup_max)
    if args.fixed_lambda_pathology is None:
        lambda_pathology = _suggest_float_range(
            trial,
            "lambda_pathology",
            args.lambda_pathology_min,
            args.lambda_pathology_max,
        )
    else:
        lambda_pathology = float(args.fixed_lambda_pathology)
    params = dict(trial.params)
    params["lambda_pathology"] = float(lambda_pathology)
    params["lambda_clinical_axes"] = float(args.lambda_clinical_axes)

    _set_reproducible_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    train_dataset = context["train_dataset"]
    val_dataset = context["val_dataset"]
    record_labels = context["record_labels"]
    pathology_map = context["pathology_map"]
    clinical_axis_map = context.get("clinical_axis_map") or {}
    train_indices = context["search_train_indices"]
    rhythm_val_indices = context["search_rhythm_val_indices"]
    pathology_val_indices = context["search_pathology_val_indices"]
    train_labels = labels_for_indices(train_dataset, train_indices, record_labels)
    class_weights = compute_class_weights(train_labels, NUM_RHYTHM_CLASSES, max_weight=args.max_class_weight)
    train_record_paths = [train_dataset.windows[index][0] for index in train_indices]
    sample_weights, sampler_source = resolve_training_sample_weights(
        train_dataset=train_dataset,
        train_indices=train_indices,
        train_labels=train_labels,
        train_record_paths=train_record_paths,
        pathology_map=pathology_map,
        max_rhythm_weight=args.max_class_weight,
        max_pathology_weight=args.max_pathology_sampler_weight,
        pathology_fraction=args.pathology_sampler_fraction,
        manifest_sampler_weights=context.get("train_manifest_sampler_weights") or {},
    )
    pathology_weights = _pathology_pos_weight(
        train_record_paths,
        pathology_map,
        max_weight=args.max_pathology_pos_weight,
    )

    train_loader = DataLoader(
        Subset(train_dataset, train_indices),
        batch_size=batch_size,
        sampler=WeightedRandomSampler(sample_weights, num_samples=len(sample_weights), replacement=True),
        drop_last=True,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
    )
    rhythm_val_loader = DataLoader(
        Subset(val_dataset, rhythm_val_indices),
        batch_size=batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
    )
    pathology_val_loaders = {
        label: DataLoader(
            Subset(val_dataset, indices),
            batch_size=batch_size,
            shuffle=False,
            num_workers=args.num_workers,
            pin_memory=device.type == "cuda",
        )
        for label, indices in pathology_val_indices.items()
    }
    if not len(train_loader):
        raise ValueError("training loader is empty after batch sizing")

    morphology_dim = MORPHOLOGY_FEATURE_DIM if bool(args.use_morphology_features) else 0
    params["use_morphology_features"] = bool(args.use_morphology_features)
    params["morphology_dim"] = int(morphology_dim)
    model = build_titan_v45_multihead(morphology_dim=morphology_dim).to(device)
    print(
        f"Trial {trial.number}: num_pathology={NUM_PATHOLOGY_CLASSES} "
        f"clinical_axis_records={len(clinical_axis_map)} params={model_parameter_count(model):,}"
    )
    print(
        f"Trial {trial.number}: sampler_source={sampler_source} "
        f"sample_weight_min={min(sample_weights):.8f} sample_weight_max={max(sample_weights):.8f}",
        flush=True,
    )
    trial.set_user_attr("sampler_source", sampler_source)
    trial.set_user_attr("fixed_training_params", {"use_morphology_features": bool(args.use_morphology_features)})
    if torch.cuda.device_count() > 1:
        model = nn.DataParallel(model)
    scale_factor = batch_size / 32.0
    optimizer = optim.AdamW(model.parameters(), lr=lr_base * scale_factor, weight_decay=weight_decay)
    scheduler = optim.lr_scheduler.OneCycleLR(
        optimizer,
        max_lr=max_lr_base * scale_factor,
        steps_per_epoch=len(train_loader),
        epochs=args.epochs,
        pct_start=0.3,
    )
    criterion_rhythm = FocalLoss(
        alpha=torch.tensor(class_weights, dtype=torch.float32, device=device),
        gamma=gamma,
        label_smoothing=label_smoothing,
    )
    criterion_quality = nn.BCELoss()
    criterion_pathology = nn.BCEWithLogitsLoss(
        pos_weight=torch.tensor(pathology_weights, dtype=torch.float32, device=device)
    )
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")

    checkpoint = checkpoint_path_for_params(args.trial_checkpoint_dir, params)
    restored = load_training_checkpoint(
        path=checkpoint,
        model=model,
        optimizer=optimizer,
        scheduler=scheduler,
        scaler=scaler,
        params=params,
        target_epochs=args.epochs,
    )
    start_epoch = int(restored["completed_epochs"])
    start_batch = int(restored["completed_batches_in_epoch"])
    partial_train_state = dict(restored["train_state"])
    score_history = list(restored["score_history"])
    primary8_history = list(restored["primary8_history"])
    best_score = max(score_history, default=float("-inf"))
    if start_epoch or start_batch:
        print(
            f"Trial {trial.number}: resuming checkpoint at epoch {start_epoch}/{args.epochs} "
            f"batch {start_batch}/{len(train_loader)}"
        )
    epochs_this_invocation = 0
    for epoch in range(start_epoch, args.epochs):
        def checkpoint_partial_train(state) -> None:
            save_training_checkpoint(
                path=checkpoint,
                model=model,
                optimizer=optimizer,
                scheduler=scheduler,
                scaler=scaler,
                params=params,
                target_epochs=args.epochs,
                completed_epochs=epoch,
                current_epoch=epoch,
                completed_batches_in_epoch=int(state["completed_batches"]),
                train_state=dict(state),
                score_history=score_history,
                primary8_history=primary8_history,
            )

        train = train_multihead_epoch(
            model,
            train_loader,
            device,
            optimizer=optimizer,
            scheduler=scheduler,
            scaler=scaler,
            criterion_rhythm=criterion_rhythm,
            criterion_quality=criterion_quality,
            criterion_pathology=criterion_pathology,
            pathology_record_to_multihot=pathology_map,
            clinical_axis_record_to_multihot=clinical_axis_map,
            mixup_alpha=mixup_alpha,
            lambda_pathology=lambda_pathology,
            lambda_clinical_axes=args.lambda_clinical_axes,
            start_batch=start_batch,
            max_batches=args.max_train_batches_per_invocation,
            initial_state=partial_train_state,
            checkpoint_every_batches=args.checkpoint_every_batches,
            checkpoint_callback=checkpoint_partial_train,
            teacher_tables=args.offline_teacher_tables,
            teacher_kl_weight=args.teacher_logits_kl_weight,
            teacher_temperature=args.teacher_logits_temperature,
        )
        if not train["epoch_complete"]:
            checkpoint_partial_train(train["resume_state"])
            trial.study.enqueue_trial(params)
            trial.set_user_attr("resumable_checkpoint", str(checkpoint))
            trial.set_user_attr("completed_epochs", epoch)
            trial.set_user_attr("completed_batches_in_epoch", train["completed_batches"])
            raise optuna.exceptions.TrialPruned("resumable batch segment completed")
        rhythm_val = evaluate_multihead_epoch(
            model,
            rhythm_val_loader,
            device,
            criterion_rhythm=criterion_rhythm,
            criterion_quality=criterion_quality,
            criterion_pathology=criterion_pathology,
            pathology_record_to_multihot={},
            clinical_axis_record_to_multihot=clinical_axis_map,
            lambda_pathology=lambda_pathology,
            lambda_clinical_axes=args.lambda_clinical_axes,
        )
        pathology_val = aggregate_primary4_panel_metrics(
            {
                label: evaluate_multihead_epoch(
                    model,
                    loader,
                    device,
                    criterion_rhythm=criterion_rhythm,
                    criterion_quality=criterion_quality,
                    criterion_pathology=criterion_pathology,
                    pathology_record_to_multihot=pathology_map,
                    clinical_axis_record_to_multihot={},
                    lambda_pathology=lambda_pathology,
                    lambda_clinical_axes=0.0,
                )
                for label, loader in pathology_val_loaders.items()
            }
        )
        val = merge_primary_panel_metrics(rhythm_val, pathology_val)
        _augment_active_rhythm_metrics(val, args)
        score = objective_score(
            val,
            active_rhythm_weight=args.active_rhythm_objective_weight,
            active_rhythm_floor=args.active_rhythm_floor,
            active_rhythm_floor_penalty=args.active_rhythm_floor_penalty,
            clinical_axis_weight=args.clinical_axis_objective_weight,
        )
        best_score = max(best_score, score)
        score_history.append(score)
        rank_score = stable_tail_score(score_history)
        primary8_history.append(float(val["primary8_macro_f1"]))
        trial.report(rank_score, epoch)
        print(
            f"Trial {trial.number} epoch {epoch + 1}/{args.epochs}: "
            f"score={score:.4f} rank_score={rank_score:.4f} p8_f1={val['primary8_macro_f1']:.4f} "
            f"path4_f1={val['pathology4_macro_f1']:.4f} "
            f"axis_f1={float(val.get('clinical_axis_macro_f1', 0.0)):.4f} "
            f"r14_f1={val['rhythm14_macro_f1']:.4f} path7_f1={val['pathology7_macro_f1']:.4f} "
            f"train_loss={train['loss']:.4f} val_loss={val['loss']:.4f} "
            f"axis_loss={float(train.get('clinical_axis_loss', 0.0)):.4f} "
            f"teacher_loss={float(train.get('teacher_loss', 0.0)):.4f} "
            f"teacher_matched={int(train.get('teacher_matched', 0))} "
            f"amp_skips={train['skipped_optimizer_steps']}"
        )
        save_training_checkpoint(
            path=checkpoint,
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            scaler=scaler,
            params=params,
            target_epochs=args.epochs,
            completed_epochs=epoch + 1,
            current_epoch=epoch + 1,
            completed_batches_in_epoch=0,
            train_state={},
            score_history=score_history,
            primary8_history=primary8_history,
        )
        start_batch = 0
        partial_train_state = {}
        epochs_this_invocation += 1
        if should_prune_collapsed_rhythm(primary8_history):
            checkpoint.unlink(missing_ok=True)
            raise optuna.exceptions.TrialPruned("primary8 rhythm head collapsed after initial learning")
        if trial.should_prune():
            checkpoint.unlink(missing_ok=True)
            raise optuna.exceptions.TrialPruned()
        if epoch + 1 < args.epochs and epochs_this_invocation >= args.max_epochs_per_invocation:
            trial.study.enqueue_trial(params)
            trial.set_user_attr("resumable_checkpoint", str(checkpoint))
            trial.set_user_attr("completed_epochs", epoch + 1)
            raise optuna.exceptions.TrialPruned("resumable epoch segment completed")
    rank_score = stable_tail_score(score_history)
    trial.set_user_attr("peak_composite_score", best_score)
    trial.set_user_attr("tail_composite_scores", score_history[-3:])
    trial.set_user_attr("ranking_score", rank_score)
    trial.set_user_attr("teacher_distillation_enabled", bool(args.offline_teacher_tables and args.teacher_logits_kl_weight > 0.0))
    if bool(args.keep_completed_checkpoint):
        completed_checkpoint = (
            Path(args.completed_checkpoint_path).expanduser().resolve()
            if args.completed_checkpoint_path
            else checkpoint.with_name(f"{checkpoint.stem}_completed.pt")
        )
        completed_checkpoint.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(checkpoint, completed_checkpoint)
        trial.set_user_attr("completed_checkpoint", str(completed_checkpoint))
    else:
        checkpoint.unlink(missing_ok=True)
    return rank_score


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data_root", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--preflight_json", required=True)
    parser.add_argument("--external_dataset", default="chapman_shaoxing")
    parser.add_argument("--stage", choices=("screening", "screening_v5", "refinement", "confirmation"), default="screening")
    parser.add_argument("--epochs", type=int)
    parser.add_argument("--n_trials", type=int)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--val_fraction", type=float, default=0.15)
    parser.add_argument("--num_workers", type=int, default=2)
    parser.add_argument("--max_train_windows", type=int, default=120000)
    parser.add_argument("--max_val_windows", type=int, default=30000)
    parser.add_argument("--max_train_virtual_fraction", type=float, default=1.0)
    parser.add_argument("--max_val_virtual_fraction", type=float, default=1.0)
    parser.add_argument("--train_manifest_csv")
    parser.add_argument("--val_manifest_csv")
    parser.add_argument("--rhythm_val_manifest_csv")
    parser.add_argument("--pathology_panel_index_json")
    parser.add_argument("--exclude_rhythm_classes", default="")
    parser.add_argument("--max_class_weight", type=float, default=20.0)
    parser.add_argument("--max_pathology_pos_weight", type=float, default=20.0)
    parser.add_argument("--max_pathology_sampler_weight", type=float, default=10.0)
    parser.add_argument("--pathology_sampler_fraction", type=float, default=0.35)
    parser.add_argument("--fixed_lambda_pathology", type=float)
    parser.add_argument("--gamma_min", type=float, default=1.0)
    parser.add_argument("--gamma_max", type=float, default=4.0)
    parser.add_argument("--label_smoothing_min", type=float, default=0.0)
    parser.add_argument("--label_smoothing_max", type=float, default=0.1)
    parser.add_argument("--mixup_min", type=float, default=0.05)
    parser.add_argument("--mixup_max", type=float, default=0.4)
    parser.add_argument("--lambda_pathology_min", type=float, default=0.2)
    parser.add_argument("--lambda_pathology_max", type=float, default=1.5)
    parser.add_argument("--batch_size_choices", default="16,32")
    parser.add_argument("--active_rhythm_classes", default="")
    parser.add_argument("--active_rhythm_objective_weight", type=float, default=0.0)
    parser.add_argument("--active_rhythm_floor", type=float, default=0.0)
    parser.add_argument("--active_rhythm_floor_penalty", type=float, default=0.0)
    parser.add_argument("--lambda_clinical_axes", type=float, default=0.12)
    parser.add_argument("--clinical_axis_objective_weight", type=float, default=0.08)
    parser.add_argument("--min_complete_trials", type=int)
    parser.add_argument("--min_promotion_score", type=float)
    parser.add_argument("--study_db")
    parser.add_argument("--study_name")
    parser.add_argument("--result_json")
    parser.add_argument("--candidate_seed_json")
    parser.add_argument("--enforce_promotion", action="store_true")
    parser.add_argument("--trial_checkpoint_dir")
    parser.add_argument("--keep_completed_checkpoint", action="store_true")
    parser.add_argument("--completed_checkpoint_path")
    parser.add_argument("--max_epochs_per_invocation", type=int, default=0)
    parser.add_argument("--max_train_batches_per_invocation", type=int)
    parser.add_argument("--checkpoint_every_batches", type=int, default=250)
    parser.add_argument("--target_complete_trials", type=int, default=0)
    parser.add_argument("--teacher_logits_npz", action="append", default=[])
    parser.add_argument("--teacher_logits_weight", default=None)
    parser.add_argument("--teacher_logits_kl_weight", type=float, default=0.0)
    parser.add_argument("--teacher_logits_temperature", type=float, default=2.5)
    parser.add_argument("--use_morphology_features", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if optuna is None:
        raise SystemExit("Optuna is not installed in this environment")
    defaults = stage_defaults(args.stage)
    args.epochs = int(args.epochs if args.epochs is not None else defaults["epochs"])
    args.n_trials = int(args.n_trials if args.n_trials is not None else defaults["n_trials"])
    args.min_complete_trials = int(
        args.min_complete_trials if args.min_complete_trials is not None else defaults["min_complete_trials"]
    )
    args.min_promotion_score = float(
        args.min_promotion_score if args.min_promotion_score is not None else defaults["min_promotion_score"]
    )
    args.batch_size_choices_tuple = _parse_int_choices(args.batch_size_choices)
    args.offline_teacher_tables = load_offline_teacher_tables(
        args.teacher_logits_npz,
        weights=_parse_float_weights(args.teacher_logits_weight, expected_len=len(args.teacher_logits_npz)),
    )
    if args.offline_teacher_tables and float(args.teacher_logits_kl_weight) <= 0.0:
        raise SystemExit("teacher_logits_npz was provided but teacher_logits_kl_weight <= 0")
    args._approved_preflight = _load_approved_preflight(args.preflight_json)
    out_dir = Path(args.output_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    context = build_search_context(args)
    study_db = Path(args.study_db).expanduser().resolve() if args.study_db else out_dir / "titan_v45_41m_multihead_optuna.db"
    study_db.parent.mkdir(parents=True, exist_ok=True)
    args.trial_checkpoint_dir = str(
        Path(args.trial_checkpoint_dir).expanduser().resolve()
        if args.trial_checkpoint_dir
        else study_db.parent / "resumable_trials"
    )
    if args.max_epochs_per_invocation <= 0:
        args.max_epochs_per_invocation = args.epochs
    storage = f"sqlite:///{study_db}"
    study_name = args.study_name or f"titan_v45_41m_multihead_{args.stage}"
    study = optuna.create_study(
        study_name=study_name,
        storage=storage,
        direction="maximize",
        load_if_exists=True,
        sampler=build_optuna_sampler(seed=args.seed),
        pruner=build_optuna_pruner(args.stage),
    )
    persisted_trial_count = len(study.get_trials(deepcopy=False))
    sampler_seed = sampler_seed_for_existing_trials(args.seed, persisted_trial_count)
    study.sampler = build_optuna_sampler(seed=sampler_seed)
    print(
        f"Optuna sampler seed={sampler_seed} persisted_trials={persisted_trial_count}",
        flush=True,
    )
    seeded_params = _load_candidate_seed_params(args.candidate_seed_json)
    trial_states = [getattr(trial.state, "name", str(trial.state)) for trial in study.trials]
    complete_before = len([state for state in trial_states if state == "COMPLETE"])
    has_waiting = any(state == "WAITING" for state in trial_states)
    has_running = any(state == "RUNNING" for state in trial_states)
    if seeded_params and (not study.trials or (not has_waiting and not has_running and complete_before < args.target_complete_trials)):
        for params in seeded_params:
            study.enqueue_trial(params)
    def objective_with_cleanup(trial) -> float:
        try:
            return objective(trial, args, context)
        finally:
            release_trial_resources()

    complete_before = len(
        [trial for trial in study.trials if getattr(trial.state, "name", str(trial.state)) == "COMPLETE"]
    )
    if not args.target_complete_trials or complete_before < args.target_complete_trials:
        study.optimize(objective_with_cleanup, n_trials=args.n_trials)
    else:
        print(f"Target complete trials already satisfied: {complete_before} >= {args.target_complete_trials}")
    top_candidates = _top_complete_trials(study, int(defaults["top_k"]))
    best_value = float(study.best_value) if top_candidates else float("-inf")
    promoted = len(top_candidates) >= args.min_complete_trials and best_value >= args.min_promotion_score
    payload = {
        "protocol": "TITAN_V45_41M_MULTIHEAD_OPTUNA",
        "stage": args.stage,
        "objective": objective_description(),
        "num_rhythm": NUM_RHYTHM_CLASSES,
        "num_pathology": NUM_PATHOLOGY_CLASSES,
        "best_value_composite_score": best_value,
        "best_params": dict(study.best_trial.params) if top_candidates else {},
        "fixed_training_params": {
            "use_morphology_features": bool(args.use_morphology_features),
            "morphology_dim": MORPHOLOGY_FEATURE_DIM if bool(args.use_morphology_features) else 0,
            "lambda_clinical_axes": float(args.lambda_clinical_axes),
            "clinical_axis_objective_weight": float(args.clinical_axis_objective_weight),
        },
        "n_trials": len(study.trials),
        "complete_trials": len([trial for trial in study.trials if getattr(trial.state, "name", str(trial.state)) == "COMPLETE"]),
        "top_candidates": top_candidates,
        "promotion": {
            "passed": promoted,
            "minimum_score": args.min_promotion_score,
            "minimum_complete_trials": args.min_complete_trials,
        },
        "search_profile": {
            "epochs_per_trial": args.epochs,
            "base_lr_range": list(BASE_LR_RANGE),
            "max_lr_range": list(MAX_LR_RANGE),
            "batch_size_choices": list(args.batch_size_choices_tuple),
            "gamma_range": [args.gamma_min, args.gamma_max],
            "label_smoothing_range": [args.label_smoothing_min, args.label_smoothing_max],
            "mixup_alpha_range": [args.mixup_min, args.mixup_max],
            "lambda_pathology_range": (
                [args.lambda_pathology_min, args.lambda_pathology_max]
                if args.fixed_lambda_pathology is None
                else [args.fixed_lambda_pathology, args.fixed_lambda_pathology]
            ),
            "num_workers": args.num_workers,
            "sampler": f"TPESampler(seed={sampler_seed}, multivariate=True, n_startup_trials=10)",
            "batch_sampler": "WeightedRandomSampler(primary8_primary4_balanced, cascade_fraction=0.20, pathology_fraction=0.35, pathology_positive_boost=12.0)",
            "ranking": "mean(last_3_composite_scores) - 0.25 * pstdev(last_3_composite_scores)",
            "frozen_train_windows": len(context["search_train_indices"]),
            "frozen_val_windows": len(context["search_val_indices"]),
            "frozen_train_virtual_windows": int(context["search_train_virtual_windows"]),
            "frozen_val_virtual_windows": int(context["search_val_virtual_windows"]),
            "max_train_virtual_fraction": args.max_train_virtual_fraction,
            "max_val_virtual_fraction": args.max_val_virtual_fraction,
            "manifest_split": bool(context.get("manifest_split", False)),
            "train_manifest_csv": args.train_manifest_csv,
            "val_manifest_csv": args.val_manifest_csv,
            "rhythm_val_manifest_csv": args.rhythm_val_manifest_csv,
            "pathology_panel_index_json": args.pathology_panel_index_json,
            "fixed_lambda_pathology": args.fixed_lambda_pathology,
            "objective_weights": {
                "primary8_macro_f1": PRIMARY8_OBJECTIVE_WEIGHT,
                "pathology4_macro_f1": PRIMARY4_OBJECTIVE_WEIGHT,
                "clinical_axis_macro_f1_auxiliary": float(args.clinical_axis_objective_weight),
            },
            "clinical_axis_heads": {
                "enabled": True,
                "lambda_clinical_axes": float(args.lambda_clinical_axes),
                "clinical_axis_objective_weight": float(args.clinical_axis_objective_weight),
                "clinical_axis_records": len(context.get("clinical_axis_map") or {}),
            },
            "active_rhythm_classes": _parse_active_rhythm_labels(args.active_rhythm_classes)[0],
            "active_rhythm_objective": {
                "weight": float(args.active_rhythm_objective_weight),
                "floor": float(args.active_rhythm_floor),
                "floor_penalty": float(args.active_rhythm_floor_penalty),
            },
            "excluded_rhythm_classes": _parse_active_rhythm_labels(args.exclude_rhythm_classes)[0],
            "missing_penalties": {
                "missing_primary_rhythm_classes": PRIMARY_MISSING_PENALTY,
                "missing_primary_pathology_labels": PRIMARY_MISSING_PENALTY,
            },
            "teacher_distillation": {
                "enabled": bool(args.offline_teacher_tables and args.teacher_logits_kl_weight > 0.0),
                "teacher_logits_npz": list(args.teacher_logits_npz),
                "teacher_logits_kl_weight": float(args.teacher_logits_kl_weight),
                "teacher_logits_temperature": float(args.teacher_logits_temperature),
                "teacher_logits_weight": _parse_float_weights(
                    args.teacher_logits_weight,
                    expected_len=len(args.teacher_logits_npz),
                ),
                "student_projection": "disabled_until_primary8_teacher_projection_is_verified",
                "rare_classes_not_distilled": ["Flutter", "LQTS"],
            },
            "morphology_features": {
                "enabled": bool(args.use_morphology_features),
                "dimension": MORPHOLOGY_FEATURE_DIM if bool(args.use_morphology_features) else 0,
            },
        },
        "discovery_datasets": context["structure"]["discovery_datasets"],
    }
    result_json = Path(args.result_json).expanduser().resolve() if args.result_json else out_dir / "optuna_best_params.json"
    result_json.parent.mkdir(parents=True, exist_ok=True)
    with result_json.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    print("MULTI-HEAD OPTUNA SEARCH COMPLETED")
    print(json.dumps(payload, indent=2))
    if args.enforce_promotion and not promoted:
        failure = {
            "protocol": "TITAN_V45_STAGE_FAILURE",
            "stage": args.stage,
            "reason": "promotion gate not satisfied",
            "promotion": payload["promotion"],
            "best_value_composite_score": best_value,
            "result_json": str(result_json),
        }
        (result_json.parent / "stage_failure_report.json").write_text(
            json.dumps(failure, indent=2),
            encoding="utf-8",
        )
        raise SystemExit(
            f"Optuna screening did not pass promotion gate: "
            f"{study.best_value:.4f} < {args.min_promotion_score:.4f}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
