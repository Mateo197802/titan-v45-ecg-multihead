from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path
from typing import Iterable, Mapping, Sequence

from REGISTRIES.label_registry import RHYTHM_CLASS_NAMES, SNOMED_TO_RHYTHM
from TRAINING.v3ag_external_final_curation import BROAD_PATHOLOGY4_CODES, parse_dx_codes


BROAD_PATHOLOGY4 = tuple(BROAD_PATHOLOGY4_CODES)
_MI_PTBXL_COLUMNS = ("pathology_IMI", "pathology_ASMI", "pathology_ILMI", "pathology_AMI", "pathology_ALMI")


def _split_labels(value: object) -> list[str]:
    text = str(value or "").replace(",", "|").replace(";", "|")
    return [part.strip() for part in text.split("|") if part.strip()]


def candidate_labels_from_row(
    row: Mapping[str, object],
    candidate_classes: Sequence[str],
) -> tuple[str, ...]:
    labels: set[str] = set()
    for column in (
        "accepted_primary_labels",
        "separator_primary_labels",
        "separator_cascade_labels",
        "separator_rhythm_labels",
        "rhythm_label_name",
    ):
        labels.update(_split_labels(row.get(column, "")))
    return tuple(name for name in candidate_classes if name in labels)


def broad_pathology_labels_from_row(row: Mapping[str, object]) -> tuple[str, ...]:
    labels = set(_split_labels(row.get("accepted_pathology_labels", "")))
    codes = set(_split_labels(row.get("dx_codes", "")))
    for class_name, class_codes in BROAD_PATHOLOGY4_CODES.items():
        if codes.intersection(class_codes):
            labels.add(class_name)
    if any(str(row.get(column, "")).strip().casefold() in {"1", "1.0", "true", "yes"} for column in _MI_PTBXL_COLUMNS):
        labels.add("MI")
    if str(row.get("pathology_LVH", "")).strip().casefold() in {"1", "1.0", "true", "yes"}:
        labels.add("LVH")
    return tuple(name for name in BROAD_PATHOLOGY4 if name in labels)


def split_role(record_id: str, *, validation_percent: int = 20, seed: int = 46) -> str:
    if not 1 <= int(validation_percent) <= 99:
        raise ValueError("validation_percent must be between 1 and 99")
    digest = hashlib.sha256(f"{seed}:{record_id}".encode("utf-8")).digest()
    bucket = int.from_bytes(digest[:8], "big") % 100
    return "validation" if bucket < int(validation_percent) else "train"


def is_external_dev_monitor(record_id: str, *, seed: int = 146) -> bool:
    digest = hashlib.sha256(f"{seed}:{record_id}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") % 2 == 0


def _read_rows(path: str | Path) -> list[dict[str, str]]:
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def _primary_label(labels: Sequence[str], candidate_classes: Sequence[str]) -> str:
    for name in candidate_classes:
        if name in labels and name != "NSR":
            return name
    return labels[0]


def _adapt_base_rows(
    rows: Iterable[Mapping[str, object]],
    candidate_classes: Sequence[str],
) -> list[dict[str, object]]:
    adapted: list[dict[str, object]] = []
    for raw in rows:
        labels = candidate_labels_from_row(raw, candidate_classes)
        if not labels:
            continue
        row = dict(raw)
        primary = _primary_label(labels, candidate_classes)
        row["accepted_primary_labels"] = "|".join(labels)
        row["separator_primary_labels"] = "|".join(labels)
        row["rhythm_label_name"] = primary
        row["rhythm_label"] = RHYTHM_CLASS_NAMES.index(primary)
        row["external_reserved"] = 0
        adapted.append(row)
    return adapted


def _rows_from_downloaded_records(
    records_dir: str | Path,
    candidate_classes: Sequence[str],
    *,
    validation_percent: int,
    seed: int,
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    train: list[dict[str, object]] = []
    validation: list[dict[str, object]] = []
    directory = Path(records_dir)
    for header in sorted(directory.glob("*.hea"), key=lambda path: path.name):
        record_base = header.with_suffix("")
        if not record_base.with_suffix(".mat").is_file():
            continue
        codes = parse_dx_codes(header.read_text(encoding="utf-8", errors="ignore"))
        active_labels = {
            RHYTHM_CLASS_NAMES[int(SNOMED_TO_RHYTHM[code])]
            for code in codes
            if code in SNOMED_TO_RHYTHM
        }
        labels = tuple(name for name in candidate_classes if name in active_labels)
        if not labels:
            continue
        primary = _primary_label(labels, candidate_classes)
        role = split_role(header.stem, validation_percent=validation_percent, seed=seed)
        row: dict[str, object] = {
            "record_base": str(record_base),
            "header_path": str(header),
            "record_id": header.stem,
            "source": "ningbo_development",
            "source_family": "ningbo_development",
            "rhythm_label": RHYTHM_CLASS_NAMES.index(primary),
            "rhythm_label_name": primary,
            "accepted_primary_labels": "|".join(labels),
            "separator_primary_labels": "|".join(labels),
            "separator_rhythm_labels": "|".join(labels),
            "dx_codes": "|".join(codes),
            "label_source": "header_dx",
            "sampler_weight": 1.0,
            "external_reserved": 0,
            "development_role": role,
        }
        (validation if role == "validation" else train).append(row)
    return train, validation


def _deduplicate(rows: Iterable[Mapping[str, object]]) -> list[dict[str, object]]:
    unique: dict[str, dict[str, object]] = {}
    for row in rows:
        key = str(row.get("record_base", "")).strip().casefold()
        if not key:
            continue
        unique[key] = dict(row)
    return [unique[key] for key in sorted(unique)]


def _write_rows(path: Path, rows: Sequence[Mapping[str, object]]) -> None:
    preferred = [
        "record_base",
        "header_path",
        "record_id",
        "source",
        "source_family",
        "rhythm_label",
        "rhythm_label_name",
        "accepted_primary_labels",
        "accepted_pathology_labels",
        "separator_primary_labels",
        "separator_rhythm_labels",
        "dx_codes",
        "label_source",
        "sampler_weight",
        "external_reserved",
        "development_role",
    ]
    extras = sorted({key for row in rows for key in row}.difference(preferred))
    fields = preferred + extras
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _class_counts(rows: Iterable[Mapping[str, object]], classes: Sequence[str]) -> dict[str, int]:
    counts: Counter[str] = Counter()
    for row in rows:
        counts.update(candidate_labels_from_row(row, classes))
    return {name: int(counts[name]) for name in classes}


def build_replacement_manifests(
    *,
    base_train_manifest: str | Path,
    base_val_manifest: str | Path,
    downloaded_records_dir: str | Path,
    output_dir: str | Path,
    candidate_classes: Sequence[str],
    validation_percent: int = 20,
    seed: int = 46,
) -> dict[str, object]:
    classes = tuple(candidate_classes)
    if len(classes) != 8 or len(set(classes)) != 8:
        raise ValueError("candidate Primary8 must contain exactly 8 unique classes")
    unknown = [name for name in classes if name not in RHYTHM_CLASS_NAMES]
    if unknown:
        raise ValueError(f"candidate classes outside active rhythm registry: {unknown}")

    base_train = _adapt_base_rows(_read_rows(base_train_manifest), classes)
    base_val = _adapt_base_rows(_read_rows(base_val_manifest), classes)
    new_train, new_val_all = _rows_from_downloaded_records(
        downloaded_records_dir,
        classes,
        validation_percent=validation_percent,
        seed=seed,
    )
    new_monitor = [row for row in new_val_all if is_external_dev_monitor(str(row.get("record_id", "")), seed=seed + 100)]
    new_val = [row for row in new_val_all if row not in new_monitor]
    train = _deduplicate([*base_train, *new_train])
    validation = _deduplicate([*base_val, *new_val])
    external_dev = _deduplicate(new_monitor)
    train_keys = {str(row["record_base"]).casefold() for row in train}
    val_keys = {str(row["record_base"]).casefold() for row in validation}
    overlap = sorted(train_keys.intersection(val_keys))
    if overlap:
        raise ValueError(f"train/validation overlap detected: {len(overlap)} records")

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    train_path = output / "v3ag_candidate_primary8_train.csv"
    val_path = output / "v3ag_candidate_primary8_validation.csv"
    monitor_path = output / "v3ag_candidate_primary8_external_dev.csv"
    _write_rows(train_path, train)
    _write_rows(val_path, validation)
    _write_rows(monitor_path, external_dev)
    audit = {
        "protocol": "TITAN_V45_V3AG_REPLACEMENT_PRIMARY8_MANIFESTS",
        "primary8_classes": list(classes),
        "train_records": len(train),
        "validation_records": len(validation),
        "overlap_records": 0,
        "train_class_counts": _class_counts(train, classes),
        "validation_class_counts": _class_counts(validation, classes),
        "new_development_train_records": len(new_train),
        "new_development_validation_records": len(new_val),
        "external_dev_monitor_records": len(external_dev),
        "external_final_records_used": 0,
        "train_manifest": str(train_path),
        "validation_manifest": str(val_path),
        "external_dev_monitor_manifest": str(monitor_path),
        "seed": int(seed),
    }
    (output / "v3ag_candidate_primary8_manifest_audit.json").write_text(
        json.dumps(audit, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return audit


def _adapt_broad_pathology_row(row: Mapping[str, object]) -> dict[str, object]:
    adapted = dict(row)
    adapted["accepted_pathology_labels"] = "|".join(broad_pathology_labels_from_row(row))
    adapted["external_reserved"] = 0
    return adapted


def _broad_rows_from_downloaded_records(
    records_dir: str | Path,
    *,
    validation_percent: int,
    seed: int,
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    train: list[dict[str, object]] = []
    validation: list[dict[str, object]] = []
    directory = Path(records_dir)
    for header in sorted(directory.glob("*.hea"), key=lambda path: path.name):
        record_base = header.with_suffix("")
        if not record_base.with_suffix(".mat").is_file():
            continue
        codes = parse_dx_codes(header.read_text(encoding="utf-8", errors="ignore"))
        row: dict[str, object] = {
            "record_base": str(record_base),
            "header_path": str(header),
            "record_id": header.stem,
            "source": "ningbo_development",
            "source_family": "ningbo_development",
            "rhythm_label": 3,
            "rhythm_label_name": "NSR",
            "dx_codes": "|".join(codes),
            "label_source": "header_dx",
            "sampler_weight": 1.0,
            "external_reserved": 0,
        }
        row["accepted_pathology_labels"] = "|".join(broad_pathology_labels_from_row(row))
        role = split_role(header.stem, validation_percent=validation_percent, seed=seed)
        row["development_role"] = role
        (validation if role == "validation" else train).append(row)
    return train, validation


def _stable_rows(rows: Iterable[Mapping[str, object]], *, salt: str) -> list[dict[str, object]]:
    return sorted(
        (dict(row) for row in rows),
        key=lambda row: hashlib.sha256(f"{salt}:{row.get('record_base', '')}".encode("utf-8")).hexdigest(),
    )


def build_broad_pathology_manifests(
    *,
    base_train_manifest: str | Path,
    base_val_manifest: str | Path,
    downloaded_records_dir: str | Path,
    output_dir: str | Path,
    validation_percent: int = 20,
    max_val_per_class: int = 128,
    seed: int = 47,
) -> dict[str, object]:
    base_train = [_adapt_broad_pathology_row(row) for row in _read_rows(base_train_manifest)]
    base_val = [_adapt_broad_pathology_row(row) for row in _read_rows(base_val_manifest)]
    new_train, new_val_all = _broad_rows_from_downloaded_records(
        downloaded_records_dir,
        validation_percent=validation_percent,
        seed=seed,
    )
    new_monitor = [row for row in new_val_all if is_external_dev_monitor(str(row.get("record_id", "")), seed=seed + 100)]
    new_val = [row for row in new_val_all if row not in new_monitor]
    train = _deduplicate([*base_train, *new_train])
    validation = _deduplicate([*base_val, *new_val])
    external_dev = _deduplicate(new_monitor)
    train_keys = {str(row["record_base"]).casefold() for row in train}
    val_keys = {str(row["record_base"]).casefold() for row in validation}
    overlap = train_keys.intersection(val_keys)
    if overlap:
        raise ValueError(f"broad Pathology4 train/validation overlap: {len(overlap)}")

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    train_path = output / "v3ag_broad_pathology4_train.csv"
    validation_path = output / "v3ag_broad_pathology4_validation.csv"
    _write_rows(train_path, train)
    _write_rows(validation_path, validation)

    panels: dict[str, str] = {}
    panel_counts: dict[str, dict[str, int]] = {}
    for class_name in BROAD_PATHOLOGY4:
        positives = _stable_rows(
            (row for row in validation if class_name in broad_pathology_labels_from_row(row)),
            salt=f"{seed}:{class_name}:positive",
        )[:max_val_per_class]
        negatives = _stable_rows(
            (row for row in validation if class_name not in broad_pathology_labels_from_row(row)),
            salt=f"{seed}:{class_name}:negative",
        )[: len(positives)]
        panel_size = min(len(positives), len(negatives))
        panel_rows: list[dict[str, object]] = []
        for target, source_rows in ((1, positives[:panel_size]), (0, negatives[:panel_size])):
            for row in source_rows:
                panel_rows.append({**row, "class_name": class_name, "target": target})
        panel_path = output / f"v3ag_broad_pathology4_{class_name.lower()}_validation_panel.csv"
        _write_rows(panel_path, panel_rows)
        panels[class_name] = str(panel_path)
        panel_counts[class_name] = {"positive": panel_size, "negative": panel_size}

    panel_index_path = output / "v3ag_broad_pathology4_validation_panel_index.json"
    panel_index_path.write_text(json.dumps({"panels": panels}, indent=2, sort_keys=True), encoding="utf-8")

    monitor_panels: dict[str, str] = {}
    monitor_panel_counts: dict[str, dict[str, int]] = {}
    for class_name in BROAD_PATHOLOGY4:
        positives = _stable_rows(
            (row for row in external_dev if class_name in broad_pathology_labels_from_row(row)),
            salt=f"{seed}:{class_name}:monitor-positive",
        )[:max_val_per_class]
        negatives = _stable_rows(
            (row for row in external_dev if class_name not in broad_pathology_labels_from_row(row)),
            salt=f"{seed}:{class_name}:monitor-negative",
        )[: len(positives)]
        panel_size = min(len(positives), len(negatives))
        panel_rows = [
            {**row, "class_name": class_name, "target": target}
            for target, source_rows in ((1, positives[:panel_size]), (0, negatives[:panel_size]))
            for row in source_rows
        ]
        panel_path = output / f"v3ag_broad_pathology4_{class_name.lower()}_external_dev_panel.csv"
        _write_rows(panel_path, panel_rows)
        monitor_panels[class_name] = str(panel_path)
        monitor_panel_counts[class_name] = {"positive": panel_size, "negative": panel_size}
    monitor_index_path = output / "v3ag_broad_pathology4_external_dev_panel_index.json"
    monitor_index_path.write_text(json.dumps({"panels": monitor_panels}, indent=2, sort_keys=True), encoding="utf-8")
    report = {
        "protocol": "TITAN_V45_V3AG_BROAD_PATHOLOGY4_MANIFESTS",
        "pathology4_classes": list(BROAD_PATHOLOGY4),
        "train_records": len(train),
        "validation_records": len(validation),
        "overlap_records": 0,
        "train_class_counts": {name: sum(name in broad_pathology_labels_from_row(row) for row in train) for name in BROAD_PATHOLOGY4},
        "validation_class_counts": {
            name: sum(name in broad_pathology_labels_from_row(row) for row in validation) for name in BROAD_PATHOLOGY4
        },
        "validation_panel_counts": panel_counts,
        "external_dev_monitor_records": len(external_dev),
        "external_dev_panel_counts": monitor_panel_counts,
        "external_final_records_used": 0,
        "train_manifest": str(train_path),
        "validation_manifest": str(validation_path),
        "validation_panel_index": str(panel_index_path),
        "external_dev_panel_index": str(monitor_index_path),
        "seed": int(seed),
    }
    (output / "v3ag_broad_pathology4_manifest_audit.json").write_text(
        json.dumps(report, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("primary8", "broad-pathology4"), default="primary8")
    parser.add_argument("--base_train_manifest", required=True)
    parser.add_argument("--base_val_manifest", required=True)
    parser.add_argument("--downloaded_records_dir", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--primary8")
    parser.add_argument("--validation_percent", type=int, default=20)
    parser.add_argument("--max_val_per_class", type=int, default=128)
    parser.add_argument("--seed", type=int, default=46)
    args = parser.parse_args()
    if args.mode == "broad-pathology4":
        report = build_broad_pathology_manifests(
            base_train_manifest=args.base_train_manifest,
            base_val_manifest=args.base_val_manifest,
            downloaded_records_dir=args.downloaded_records_dir,
            output_dir=args.output_dir,
            validation_percent=args.validation_percent,
            max_val_per_class=args.max_val_per_class,
            seed=args.seed,
        )
    else:
        if not args.primary8:
            parser.error("--primary8 is required in primary8 mode")
        report = build_replacement_manifests(
            base_train_manifest=args.base_train_manifest,
            base_val_manifest=args.base_val_manifest,
            downloaded_records_dir=args.downloaded_records_dir,
            output_dir=args.output_dir,
            candidate_classes=tuple(name.strip() for name in args.primary8.split(",") if name.strip()),
            validation_percent=args.validation_percent,
            seed=args.seed,
        )
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
