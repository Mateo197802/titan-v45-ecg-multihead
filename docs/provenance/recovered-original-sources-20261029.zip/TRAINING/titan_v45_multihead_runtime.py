"""Shared train/evaluation runtime for TITAN V4.5 41M multi-head jobs."""

from __future__ import annotations

from typing import Callable, Mapping, Sequence

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, f1_score

from MODEL_CORE.titan_v4_hybrid import TitanV4Hybrid
from UTILS_MANAGER.morphology_features import MORPHOLOGY_FEATURE_DIM
from TRAINING.titan_v45_multihead_contract import (
    CLINICAL_AXIS_HEAD_DIMS,
    NUM_PATHOLOGY_CLASSES,
    NUM_RHYTHM_CLASSES,
    clinical_axis_targets_for_paths,
    evaluate_multihead_predictions,
    pathology_targets_for_paths,
)
from TRAINING.distillation_utils import project_full14_logits_to_primary9
from TRAINING.train_v4_lite import masked_age_sex_loss, offline_teacher_distillation_loss


def build_titan_v45_multihead(*, morphology_dim: int = 0) -> TitanV4Hybrid:
    return TitanV4Hybrid(
        in_channels=12,
        num_rhythm=NUM_RHYTHM_CLASSES,
        num_pathology=NUM_PATHOLOGY_CLASSES,
        clinical_axis_heads=CLINICAL_AXIS_HEAD_DIMS,
        morphology_dim=int(morphology_dim),
        d_model=640,
        num_transformer_layers=9,
        nhead=10,
        stage_channels=(96, 192, 384, 768),
    )


def model_parameter_count(model: nn.Module) -> int:
    target = model.module if isinstance(model, nn.DataParallel) else model
    return int(sum(parameter.numel() for parameter in target.parameters()))


def mixup_lead_mask(lead_mask: torch.Tensor, permutation: torch.Tensor, *, lam: float) -> torch.Tensor:
    """Preserve explicit lead availability when mixup combines two ECGs."""

    if float(lam) >= 1.0:
        return lead_mask
    return lead_mask | lead_mask[permutation]


def _lead_mask_from_batch(batch, batch_x: torch.Tensor, device: torch.device) -> torch.Tensor:
    if len(batch) >= 6 and torch.is_tensor(batch[5]):
        lead_mask = batch[5].to(device=device, dtype=torch.bool)
        if lead_mask.shape == (batch_x.shape[0], batch_x.shape[1]):
            return lead_mask
    return torch.ones((batch_x.shape[0], batch_x.shape[1]), device=device, dtype=torch.bool)


def _morphology_from_batch(batch, batch_x: torch.Tensor, device: torch.device) -> torch.Tensor | None:
    if not isinstance(batch, (list, tuple)):
        return None
    for item in batch[5:]:
        if not torch.is_tensor(item):
            continue
        if item.ndim != 2 or item.shape[0] != batch_x.shape[0]:
            continue
        if item.dtype == torch.bool and item.shape[1] == batch_x.shape[1]:
            continue
        if item.shape[1] == MORPHOLOGY_FEATURE_DIM:
            return item.to(device=device, dtype=batch_x.dtype)
    return None


def _mixed_optional_tensor(tensor: torch.Tensor | None, permutation: torch.Tensor, lam: float) -> torch.Tensor | None:
    if tensor is None:
        return None
    if float(lam) >= 1.0:
        return tensor
    return float(lam) * tensor + (1.0 - float(lam)) * tensor[permutation]


def _pathology_tensors(
    batch_paths: Sequence[str],
    pathology_record_to_multihot: Mapping[str, Sequence[float]],
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor]:
    targets, mask = pathology_targets_for_paths(batch_paths, pathology_record_to_multihot)
    return (
        torch.from_numpy(targets).to(device=device, dtype=torch.float32),
        torch.from_numpy(mask).to(device=device, dtype=torch.bool),
    )


def _clinical_axis_tensors(
    batch_paths: Sequence[str],
    clinical_axis_record_to_multihot: Mapping[str, Mapping[str, Sequence[float]]] | None,
    device: torch.device,
) -> tuple[dict[str, torch.Tensor], torch.Tensor]:
    targets, mask = clinical_axis_targets_for_paths(batch_paths, clinical_axis_record_to_multihot or {})
    return (
        {axis: torch.from_numpy(values).to(device=device, dtype=torch.float32) for axis, values in targets.items()},
        torch.from_numpy(mask).to(device=device, dtype=torch.bool),
    )


def _clinical_axis_logits(model: nn.Module, features: torch.Tensor) -> dict[str, torch.Tensor]:
    target = model.module if isinstance(model, nn.DataParallel) else model
    if not hasattr(target, "clinical_axis_logits"):
        return {}
    return target.clinical_axis_logits(features)


def clinical_axis_loss(
    logits: Mapping[str, torch.Tensor],
    targets: Mapping[str, torch.Tensor],
    mask: torch.Tensor,
) -> tuple[torch.Tensor, dict[str, int]]:
    if logits:
        device = next(iter(logits.values())).device
    elif targets:
        device = next(iter(targets.values())).device
    else:
        device = mask.device
    losses: list[torch.Tensor] = []
    label_count = 0
    if torch.any(mask):
        for axis, axis_logits in logits.items():
            axis_targets = targets.get(axis)
            if axis_targets is None:
                continue
            losses.append(
                nn.functional.binary_cross_entropy_with_logits(
                    axis_logits[mask].float(),
                    axis_targets[mask].float(),
                )
            )
            label_count += int(axis_targets.shape[1])
    if not losses:
        return torch.zeros((), device=device), {"clinical_axis_batches": 0, "clinical_axis_labels": 0}
    return torch.stack(losses).mean(), {"clinical_axis_batches": 1, "clinical_axis_labels": label_count}


def clinical_axis_metrics(
    targets: Mapping[str, np.ndarray],
    probabilities: Mapping[str, np.ndarray],
) -> dict[str, object]:
    by_axis: dict[str, dict[str, float | int]] = {}
    f1_values: list[float] = []
    for axis, y_true in targets.items():
        y_prob = probabilities.get(axis)
        if y_prob is None or y_true.size == 0 or y_prob.size == 0:
            continue
        y_pred = (np.asarray(y_prob) >= 0.5).astype(np.int64)
        y_true_i = np.asarray(y_true).astype(np.int64)
        axis_f1 = float(f1_score(y_true_i, y_pred, average="macro", zero_division=0))
        by_axis[axis] = {
            "macro_f1": axis_f1,
            "labelwise_accuracy": float(np.mean(y_true_i == y_pred)),
            "support": int(np.sum(y_true_i)),
        }
        f1_values.append(axis_f1)
    return {
        "clinical_axis_macro_f1": float(np.mean(f1_values)) if f1_values else 0.0,
        "clinical_axis_by_axis": by_axis,
    }


def _mixed_biometrics(batch_bio: torch.Tensor, permutation: torch.Tensor, lam: float) -> torch.Tensor:
    mixed = torch.full_like(batch_bio, -1.0)
    mixed[:, 0] = batch_bio[:, 0]
    left = batch_bio[:, 1:3]
    right = batch_bio[permutation, 1:3]
    valid = (left >= 0.0) & (right >= 0.0)
    blended = float(lam) * left + (1.0 - float(lam)) * right
    mixed[:, 1:3] = torch.where(valid, blended, mixed[:, 1:3])
    return mixed


def _window_keys_from_batch(batch) -> Sequence[str] | None:
    if not isinstance(batch, (list, tuple)):
        return None
    keys = None
    for item in reversed(batch[5:]):
        if torch.is_tensor(item):
            continue
        keys = item
        break
    if keys is None:
        return None
    if isinstance(keys, str):
        return [keys]
    return keys


def step_optimizer_and_scheduler(scaler, optimizer, scheduler) -> bool:
    """Advance OneCycleLR only when AMP actually applied the optimizer step."""
    scale_before = float(scaler.get_scale())
    scaler.step(optimizer)
    scaler.update()
    optimizer_step_applied = float(scaler.get_scale()) >= scale_before
    if optimizer_step_applied:
        scheduler.step()
    return optimizer_step_applied


def train_multihead_epoch(
    model: nn.Module,
    loader,
    device: torch.device,
    *,
    optimizer,
    scheduler,
    scaler,
    criterion_rhythm,
    criterion_quality,
    criterion_pathology,
    pathology_record_to_multihot: Mapping[str, Sequence[float]],
    clinical_axis_record_to_multihot: Mapping[str, Mapping[str, Sequence[float]]] | None = None,
    mixup_alpha: float,
    lambda_pathology: float,
    lambda_clinical_axes: float = 0.0,
    start_batch: int = 0,
    max_batches: int | None = None,
    initial_state: Mapping[str, float | int] | None = None,
    checkpoint_every_batches: int = 0,
    checkpoint_callback: Callable[[dict[str, float | int]], None] | None = None,
    teacher_tables: Sequence[Mapping[str, object]] | None = None,
    teacher_kl_weight: float = 0.0,
    teacher_temperature: float = 2.5,
) -> dict[str, float | int | bool | dict[str, float | int]]:
    model.train()
    state = dict(initial_state or {})
    loss_sum = float(state.get("loss_sum", 0.0))
    finite_batches = int(state.get("finite_batches", 0))
    pathology_batches = int(state.get("pathology_batches", 0))
    clinical_axis_loss_sum = float(state.get("clinical_axis_loss_sum", 0.0))
    clinical_axis_batches = int(state.get("clinical_axis_batches", 0))
    skipped_optimizer_steps = int(state.get("skipped_optimizer_steps", 0))
    teacher_loss_sum = float(state.get("teacher_loss_sum", 0.0))
    teacher_batches = int(state.get("teacher_batches", 0))
    teacher_matched = int(state.get("teacher_matched", 0))
    teacher_missing = int(state.get("teacher_missing", 0))
    total_batches = len(loader)
    completed_batches = int(start_batch)
    remaining_batches = max(0, total_batches - completed_batches)
    invocation_limit = remaining_batches if max_batches is None else min(remaining_batches, int(max_batches))
    processed_batches = 0

    def resume_state() -> dict[str, float | int]:
        return {
            "loss_sum": loss_sum,
            "finite_batches": finite_batches,
            "pathology_batches": pathology_batches,
            "clinical_axis_loss_sum": clinical_axis_loss_sum,
            "clinical_axis_batches": clinical_axis_batches,
            "skipped_optimizer_steps": skipped_optimizer_steps,
            "teacher_loss_sum": teacher_loss_sum,
            "teacher_batches": teacher_batches,
            "teacher_matched": teacher_matched,
            "teacher_missing": teacher_missing,
            "completed_batches": completed_batches,
        }

    for batch in loader:
        if processed_batches >= invocation_limit:
            break
        batch_x = batch[0].to(device)
        batch_ry = batch[1].to(device)
        batch_qy = batch[2].to(device)
        batch_bio = batch[3].to(device)
        batch_paths = batch[4]
        batch_lead_mask = _lead_mask_from_batch(batch, batch_x, device)
        batch_morphology = _morphology_from_batch(batch, batch_x, device)
        pathology_y, pathology_mask = _pathology_tensors(batch_paths, pathology_record_to_multihot, device)
        clinical_axis_y, clinical_axis_mask = _clinical_axis_tensors(
            batch_paths,
            clinical_axis_record_to_multihot,
            device,
        )

        lam = float(np.random.beta(mixup_alpha, mixup_alpha)) if mixup_alpha > 0.0 else 1.0
        permutation = torch.randperm(batch_x.shape[0], device=device)
        mixed_x = lam * batch_x + (1.0 - lam) * batch_x[permutation]
        mixed_quality = lam * batch_qy + (1.0 - lam) * batch_qy[permutation]
        mixed_bio = _mixed_biometrics(batch_bio, permutation, lam)
        mixed_lead_mask = mixup_lead_mask(batch_lead_mask, permutation, lam=lam)
        mixed_morphology = _mixed_optional_tensor(batch_morphology, permutation, lam)
        mixed_pathology = lam * pathology_y + (1.0 - lam) * pathology_y[permutation]
        mixed_pathology_mask = pathology_mask & pathology_mask[permutation]
        mixed_clinical_axis = {
            axis: lam * target + (1.0 - lam) * target[permutation]
            for axis, target in clinical_axis_y.items()
        }
        mixed_clinical_axis_mask = clinical_axis_mask & clinical_axis_mask[permutation]

        optimizer.zero_grad(set_to_none=True)
        with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
            out_rhythm, out_quality, out_biometrics, out_pathology, features = model(
                mixed_x,
                morphology_features=mixed_morphology,
                lead_mask=mixed_lead_mask,
                return_features=True,
            )
            loss_rhythm = (
                lam * criterion_rhythm(out_rhythm, batch_ry)
                + (1.0 - lam) * criterion_rhythm(out_rhythm, batch_ry[permutation])
            )
            loss_biometrics = masked_age_sex_loss(out_biometrics, mixed_bio)
            loss_clinical_axes, clinical_stats = clinical_axis_loss(
                _clinical_axis_logits(model, features),
                mixed_clinical_axis,
                mixed_clinical_axis_mask,
            )
        out_quality_safe = torch.clamp(out_quality.float(), min=1e-7, max=1.0 - 1e-7)
        loss_quality = criterion_quality(out_quality_safe, mixed_quality.float())
        if torch.any(mixed_pathology_mask):
            loss_pathology = criterion_pathology(
                out_pathology[mixed_pathology_mask].float(),
                mixed_pathology[mixed_pathology_mask].float(),
            )
            pathology_batches += 1
        else:
            loss_pathology = out_pathology.sum() * 0.0
        loss = (
            loss_rhythm
            + float(lambda_pathology) * loss_pathology
            + float(lambda_clinical_axes) * loss_clinical_axes
            + 0.1 * loss_quality
            + 0.2 * loss_biometrics
        )
        if int(clinical_stats["clinical_axis_batches"]):
            clinical_axis_loss_sum += float(loss_clinical_axes.detach().cpu().item())
            clinical_axis_batches += int(clinical_stats["clinical_axis_batches"])
        if teacher_tables and float(teacher_kl_weight) > 0.0:
            batch_window_keys = _window_keys_from_batch(batch)
            if batch_window_keys is not None:
                student_primary9_logits = project_full14_logits_to_primary9(out_rhythm.float())
                loss_teacher, teacher_stats = offline_teacher_distillation_loss(
                    student_primary9_logits,
                    batch_window_keys,
                    teacher_tables,
                    primary9_mode=False,
                    temperature=float(teacher_temperature),
                )
                teacher_matched += int(teacher_stats.get("matched", 0))
                teacher_missing += int(teacher_stats.get("missing", 0))
                if loss_teacher is not None:
                    loss = loss + float(teacher_kl_weight) * loss_teacher
                    teacher_loss_sum += float(loss_teacher.detach().cpu().item())
                    teacher_batches += 1
        if torch.isfinite(loss):
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            if not step_optimizer_and_scheduler(scaler, optimizer, scheduler):
                skipped_optimizer_steps += 1
            loss_sum += float(loss.detach().cpu().item())
            finite_batches += 1
        processed_batches += 1
        completed_batches += 1
        if (
            checkpoint_callback is not None
            and checkpoint_every_batches > 0
            and completed_batches % int(checkpoint_every_batches) == 0
        ):
            checkpoint_callback(resume_state())
    epoch_complete = completed_batches >= total_batches
    return {
        "loss": float(loss_sum / finite_batches) if finite_batches else float("inf"),
        "finite_batches": finite_batches,
        "pathology_batches": pathology_batches,
        "clinical_axis_loss": float(clinical_axis_loss_sum / clinical_axis_batches) if clinical_axis_batches else 0.0,
        "clinical_axis_batches": clinical_axis_batches,
        "skipped_optimizer_steps": skipped_optimizer_steps,
        "teacher_loss": float(teacher_loss_sum / teacher_batches) if teacher_batches else 0.0,
        "teacher_batches": teacher_batches,
        "teacher_matched": teacher_matched,
        "teacher_missing": teacher_missing,
        "completed_batches": completed_batches,
        "epoch_complete": epoch_complete,
        "resume_state": resume_state(),
    }


def evaluate_multihead_epoch(
    model: nn.Module,
    loader,
    device: torch.device,
    *,
    criterion_rhythm,
    criterion_quality,
    criterion_pathology,
    pathology_record_to_multihot: Mapping[str, Sequence[float]],
    clinical_axis_record_to_multihot: Mapping[str, Mapping[str, Sequence[float]]] | None = None,
    lambda_pathology: float,
    lambda_clinical_axes: float = 0.0,
) -> dict[str, object]:
    model.eval()
    losses: list[float] = []
    rhythm_true: list[np.ndarray] = []
    rhythm_pred: list[np.ndarray] = []
    rhythm_confidence: list[np.ndarray] = []
    rhythm_probability: list[np.ndarray] = []
    pathology_true: list[np.ndarray] = []
    pathology_prob: list[np.ndarray] = []
    clinical_true: dict[str, list[np.ndarray]] = {}
    clinical_prob: dict[str, list[np.ndarray]] = {}
    record_paths: list[str] = []
    window_keys: list[str] = []
    with torch.no_grad():
        for batch in loader:
            batch_x = batch[0].to(device)
            batch_ry = batch[1].to(device)
            batch_qy = batch[2].to(device)
            batch_bio = batch[3].to(device)
            batch_paths = batch[4]
            batch_lead_mask = _lead_mask_from_batch(batch, batch_x, device)
            batch_morphology = _morphology_from_batch(batch, batch_x, device)
            pathology_y, pathology_mask = _pathology_tensors(batch_paths, pathology_record_to_multihot, device)
            clinical_axis_y, clinical_axis_mask = _clinical_axis_tensors(
                batch_paths,
                clinical_axis_record_to_multihot,
                device,
            )

            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                out_rhythm, out_quality, out_biometrics, out_pathology, features = model(
                    batch_x,
                    morphology_features=batch_morphology,
                    lead_mask=batch_lead_mask,
                    return_features=True,
                )
                loss_rhythm = criterion_rhythm(out_rhythm, batch_ry)
                loss_biometrics = masked_age_sex_loss(out_biometrics, batch_bio)
                clinical_logits = _clinical_axis_logits(model, features)
                loss_clinical_axes, _clinical_stats = clinical_axis_loss(
                    clinical_logits,
                    clinical_axis_y,
                    clinical_axis_mask,
                )
            out_quality_safe = torch.clamp(out_quality.float(), min=1e-7, max=1.0 - 1e-7)
            loss_quality = criterion_quality(out_quality_safe, batch_qy.float())
            if torch.any(pathology_mask):
                loss_pathology = criterion_pathology(out_pathology[pathology_mask].float(), pathology_y[pathology_mask])
                pathology_true.append(pathology_y[pathology_mask].detach().cpu().numpy())
                pathology_prob.append(torch.sigmoid(out_pathology[pathology_mask]).detach().cpu().numpy())
            else:
                loss_pathology = out_pathology.sum() * 0.0
            loss = (
                loss_rhythm
                + float(lambda_pathology) * loss_pathology
                + float(lambda_clinical_axes) * loss_clinical_axes
                + 0.1 * loss_quality
                + 0.2 * loss_biometrics
            )
            if torch.isfinite(loss):
                losses.append(float(loss.detach().cpu().item()))
            if torch.any(clinical_axis_mask):
                for axis, axis_logits in clinical_logits.items():
                    if axis not in clinical_axis_y:
                        continue
                    clinical_true.setdefault(axis, []).append(
                        clinical_axis_y[axis][clinical_axis_mask].detach().cpu().numpy()
                    )
                    clinical_prob.setdefault(axis, []).append(
                        torch.sigmoid(axis_logits[clinical_axis_mask]).detach().cpu().numpy()
                    )

            probabilities = torch.softmax(out_rhythm.float(), dim=1)
            confidence, predicted = torch.max(probabilities, dim=1)
            rhythm_true.append(batch_ry.detach().cpu().numpy())
            rhythm_pred.append(predicted.detach().cpu().numpy())
            rhythm_confidence.append(confidence.detach().cpu().numpy())
            rhythm_probability.append(probabilities.detach().cpu().numpy())
            record_paths.extend(str(path) for path in batch_paths)
            keys = _window_keys_from_batch(batch)
            if keys is None:
                window_keys.extend([""] * len(batch_paths))
            else:
                window_keys.extend(str(key) for key in keys)

    y_r_true = np.concatenate(rhythm_true) if rhythm_true else np.asarray([], dtype=np.int64)
    y_r_pred = np.concatenate(rhythm_pred) if rhythm_pred else np.asarray([], dtype=np.int64)
    y_r_confidence = np.concatenate(rhythm_confidence) if rhythm_confidence else np.asarray([], dtype=np.float32)
    y_r_probability = (
        np.concatenate(rhythm_probability) if rhythm_probability else np.empty((0, NUM_RHYTHM_CLASSES), dtype=np.float32)
    )
    y_p_true = np.concatenate(pathology_true) if pathology_true else np.empty((0, NUM_PATHOLOGY_CLASSES), dtype=np.float32)
    y_p_prob = np.concatenate(pathology_prob) if pathology_prob else np.empty((0, NUM_PATHOLOGY_CLASSES), dtype=np.float32)
    y_c_true = {axis: np.concatenate(values) for axis, values in clinical_true.items() if values}
    y_c_prob = {axis: np.concatenate(values) for axis, values in clinical_prob.items() if values}
    clinical_report = clinical_axis_metrics(y_c_true, y_c_prob)
    report = evaluate_multihead_predictions(
        y_r_true,
        y_r_pred,
        y_p_true,
        y_p_prob,
        rhythm_confidence=y_r_confidence,
        rhythm_acceptance_threshold=0.80,
    )
    return {
        **report,
        **clinical_report,
        "loss": float(np.mean(losses)) if losses else float("inf"),
        "rhythm_accuracy": float(accuracy_score(y_r_true, y_r_pred)) if y_r_true.size else 0.0,
        "rhythm_macro_f1": float(f1_score(y_r_true, y_r_pred, average="macro", zero_division=0)) if y_r_true.size else 0.0,
        "rhythm_y_true": y_r_true,
        "rhythm_y_pred": y_r_pred,
        "rhythm_confidence": y_r_confidence,
        "rhythm_probability": y_r_probability,
        "record_paths": record_paths,
        "window_keys": window_keys,
        "pathology_y_true": y_p_true,
        "pathology_probability": y_p_prob,
    }
