"""V3D gate and ensemble helpers for TITAN V4.5.

These helpers keep the final gate explicit: exactly eight primary rhythm
classes and exactly four primary pathology classes. Specialist heads may change
which class wins inside Primary8, but they cannot shrink the gate.
"""

from __future__ import annotations

import os
from collections.abc import Mapping, Sequence

import numpy as np

from TRAINING.titan_v45_multihead_contract import ACTIVE14_RHYTHMS, PRIMARY_PATHOLOGIES, PRIMARY_RHYTHMS


def configured_primary8_gate_classes(environment: Mapping[str, str] | None = None) -> tuple[str, ...]:
    env = os.environ if environment is None else environment
    raw = str(env.get("TITAN_V45_PRIMARY8_GATE_CLASSES", "")).strip()
    classes = tuple(name.strip() for name in raw.split(",") if name.strip()) if raw else tuple(PRIMARY_RHYTHMS)
    if len(classes) != 8:
        raise ValueError(f"Primary8 must contain exactly 8 classes, got {len(classes)}")
    if len(set(classes)) != len(classes):
        raise ValueError("Primary8 classes must be unique")
    unknown = [name for name in classes if name not in ACTIVE14_RHYTHMS]
    if unknown:
        raise ValueError(f"Primary8 classes are outside ACTIVE14: {unknown}")
    return classes


PRIMARY8_GATE_CLASSES = configured_primary8_gate_classes()


def configured_pathology4_gate_classes(environment: Mapping[str, str] | None = None) -> tuple[str, ...]:
    env = os.environ if environment is None else environment
    raw = str(env.get("TITAN_V45_PATHOLOGY4_GATE_CLASSES", "")).strip()
    classes = tuple(name.strip() for name in raw.split(",") if name.strip()) if raw else tuple(PRIMARY_PATHOLOGIES)
    if len(classes) != 4:
        raise ValueError(f"Primary4 must contain exactly 4 classes, got {len(classes)}")
    if len(set(classes)) != len(classes):
        raise ValueError("Primary4 classes must be unique")
    allowed = set(PRIMARY_PATHOLOGIES) | {
        "MI",
        "LVH",
        "ST_DEPRESSION",
        "T_WAVE_INVERSION",
        # PTB-XL SCP endpoints with fold10 support audited for Primary4 replacement.
        "NDT",
        "NST_",
        "LAFB",
        "CLBBB",
        "IRBBB",
    }
    unknown = [name for name in classes if name not in allowed]
    if unknown:
        raise ValueError(f"Primary4 classes are outside the supported candidate registry: {unknown}")
    return classes


PATHOLOGY4_GATE_CLASSES = configured_pathology4_gate_classes()
_SPECIALIST_PRIORITY = (
    "NSR",
    "SB",
    "STACH",
    "PAC",
    "PVC",
    "RBBB",
    "1AVB",
    "Flutter",
    "Paced",
    "LQTS",
    "LBBB",
    "2AVB",
    "3AVB",
)
SPECIALIST_RHYTHM_CLASSES = tuple(name for name in _SPECIALIST_PRIORITY if name in PRIMARY8_GATE_CLASSES)


def _as_2d_float(values: np.ndarray | Sequence[Sequence[float]], *, name: str) -> np.ndarray:
    arr = np.asarray(values, dtype=np.float64)
    if arr.ndim != 2:
        raise ValueError(f"{name} must be a 2D array, got shape={arr.shape}")
    return arr


def _class_indices(class_names: Sequence[str], universe: Sequence[str]) -> list[int]:
    missing = [name for name in class_names if name not in universe]
    if missing:
        raise ValueError(f"classes are outside the gate universe: {missing}")
    return [universe.index(name) for name in class_names]


def apply_primary8_specialist_policy(
    primary8_probabilities: np.ndarray | Sequence[Sequence[float]],
    specialist_probabilities: np.ndarray | Sequence[Sequence[float]],
    *,
    specialist_classes: Sequence[str] = SPECIALIST_RHYTHM_CLASSES,
    min_specialist_confidence: float = 0.68,
    min_specialist_margin: float = 0.08,
    protect_global_confidence: float = 0.92,
) -> tuple[np.ndarray, list[dict[str, object]]]:
    """Combine global Primary8 probabilities with a focused rhythm specialist.

    Replacement is intentionally conservative. It is allowed when the global top
    class already belongs to the specialist domain, or when the global model is
    not very confident. A very confident global prediction is preserved unless
    the specialist is also highly confident and has enough margin.
    """

    primary = _as_2d_float(primary8_probabilities, name="primary8_probabilities")
    specialist = _as_2d_float(specialist_probabilities, name="specialist_probabilities")
    if primary.shape[1] != len(PRIMARY8_GATE_CLASSES):
        raise ValueError(f"primary8_probabilities must have {len(PRIMARY8_GATE_CLASSES)} columns")
    if specialist.shape != (primary.shape[0], len(specialist_classes)):
        raise ValueError(
            "specialist_probabilities shape mismatch: "
            f"expected {(primary.shape[0], len(specialist_classes))}, got {specialist.shape}"
        )

    specialist_indices = _class_indices(specialist_classes, PRIMARY8_GATE_CLASSES)
    global_pred = np.argmax(primary, axis=1).astype(np.int64)
    global_conf = np.max(primary, axis=1)
    order = np.argsort(specialist, axis=1)
    specialist_local = order[:, -1].astype(np.int64)
    specialist_conf = specialist[np.arange(specialist.shape[0]), specialist_local]
    second_conf = specialist[np.arange(specialist.shape[0]), order[:, -2]] if specialist.shape[1] > 1 else np.zeros_like(specialist_conf)
    specialist_margin = specialist_conf - second_conf
    specialist_pred = np.asarray([specialist_indices[index] for index in specialist_local], dtype=np.int64)

    final = global_pred.copy()
    details: list[dict[str, object]] = []
    specialist_domain = set(specialist_indices)
    for row in range(primary.shape[0]):
        global_name = PRIMARY8_GATE_CLASSES[int(global_pred[row])]
        specialist_name = PRIMARY8_GATE_CLASSES[int(specialist_pred[row])]
        confident = (
            float(specialist_conf[row]) >= float(min_specialist_confidence)
            and float(specialist_margin[row]) >= float(min_specialist_margin)
        )
        global_is_protected = float(global_conf[row]) >= float(protect_global_confidence)
        eligible = int(global_pred[row]) in specialist_domain or not global_is_protected
        if confident and eligible:
            final[row] = specialist_pred[row]
            decision = "specialist_replace"
        else:
            decision = "global_keep"
        details.append(
            {
                "decision": decision,
                "global_label": global_name,
                "global_confidence": float(global_conf[row]),
                "specialist_label": specialist_name,
                "specialist_confidence": float(specialist_conf[row]),
                "specialist_margin": float(specialist_margin[row]),
            }
        )
    return final, details


def apply_thresholds(probabilities: np.ndarray | Sequence[Sequence[float]], thresholds: Sequence[float]) -> np.ndarray:
    probs = _as_2d_float(probabilities, name="probabilities")
    thr = np.asarray(list(thresholds), dtype=np.float64)
    if thr.shape != (probs.shape[1],):
        raise ValueError(f"thresholds must have shape {(probs.shape[1],)}, got {thr.shape}")
    return (probs >= thr.reshape(1, -1)).astype(np.int64)


def _binary_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float | int]:
    true = y_true.astype(bool)
    pred = y_pred.astype(bool)
    tp = int(np.sum(true & pred))
    tn = int(np.sum(~true & ~pred))
    fp = int(np.sum(~true & pred))
    fn = int(np.sum(true & ~pred))
    precision = float(tp / max(tp + fp, 1))
    recall = float(tp / max(tp + fn, 1))
    specificity = float(tn / max(tn + fp, 1))
    f1 = float(2.0 * precision * recall / max(precision + recall, 1e-12))
    return {
        "tp": tp,
        "tn": tn,
        "fp": fp,
        "fn": fn,
        "accuracy": float((tp + tn) / max(len(true), 1)),
        "balanced_accuracy": float((recall + specificity) / 2.0),
        "precision": precision,
        "recall": recall,
        "specificity": specificity,
        "f1": f1,
    }


def binary_panel_report(
    y_true: np.ndarray | Sequence[Sequence[float]],
    y_pred: np.ndarray | Sequence[Sequence[float]],
    class_names: Sequence[str],
) -> dict[str, object]:
    truth = _as_2d_float(y_true, name="y_true").astype(np.int64)
    pred = _as_2d_float(y_pred, name="y_pred").astype(np.int64)
    if truth.shape != pred.shape:
        raise ValueError(f"truth/pred shape mismatch: {truth.shape} vs {pred.shape}")
    if truth.shape[1] != len(class_names):
        raise ValueError(f"class_names must describe {truth.shape[1]} columns")
    panels: dict[str, Mapping[str, float | int]] = {}
    for index, name in enumerate(class_names):
        panels[str(name)] = _binary_metrics(truth[:, index], pred[:, index])
    return {
        "panels": panels,
        "macro_f1": float(np.mean([float(panel["f1"]) for panel in panels.values()])) if panels else 0.0,
        "mean_accuracy": float(np.mean([float(panel["accuracy"]) for panel in panels.values()])) if panels else 0.0,
        "mean_balanced_accuracy": (
            float(np.mean([float(panel["balanced_accuracy"]) for panel in panels.values()])) if panels else 0.0
        ),
    }
