"""Frozen TITAN V4.5 41M multi-head data, label, metric, and gate contract."""

from __future__ import annotations

import glob
import hashlib
import csv
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import numpy as np
from sklearn.metrics import accuracy_score, f1_score

from REGISTRIES.label_registry import SNOMED_TO_RHYTHM, RHYTHM_CLASS_NAMES, normalize_record_path, parse_dx_codes_from_header
from REGISTRIES.label_registry_pathology import (
    PATHOLOGY_CLASS_NAMES,
    pathology_labels_from_snomed_codes,
)


ACTIVE14_RHYTHMS = (
    "AFIB",
    "SB",
    "STACH",
    "NSR",
    "RBBB",
    "PAC",
    "1AVB",
    "PVC",
    "Flutter",
    "LBBB",
    "2AVB",
    "3AVB",
    "LQTS",
    "Paced",
)
DEFAULT_PRIMARY_RHYTHMS = ("AFIB", "SB", "STACH", "NSR", "RBBB", "PAC", "1AVB", "PVC")


def _resolve_primary_rhythms() -> tuple[str, ...]:
    raw = os.getenv("TITAN_PRIMARY_RHYTHMS", "").strip()
    if not raw:
        return DEFAULT_PRIMARY_RHYTHMS
    values = tuple(item.strip() for item in raw.replace(";", ",").split(",") if item.strip())
    if len(values) != 8:
        raise ValueError("TITAN_PRIMARY_RHYTHMS must contain exactly 8 classes")
    if len(set(values)) != len(values):
        raise ValueError("TITAN_PRIMARY_RHYTHMS cannot contain duplicate classes")
    unknown = [name for name in values if name not in ACTIVE14_RHYTHMS]
    if unknown:
        raise ValueError(f"TITAN_PRIMARY_RHYTHMS contains classes outside ACTIVE14: {unknown}")
    return values


PRIMARY_RHYTHMS = _resolve_primary_rhythms()
CASCADE_RHYTHMS = tuple(name for name in ACTIVE14_RHYTHMS if name not in PRIMARY_RHYTHMS)
ACTIVE_RHYTHM_INDEX = {name: index for index, name in enumerate(ACTIVE14_RHYTHMS)}
ACTIVE_SNOMED_MAPPING = {
    code: ACTIVE_RHYTHM_INDEX[RHYTHM_CLASS_NAMES[index]]
    for code, index in SNOMED_TO_RHYTHM.items()
    if RHYTHM_CLASS_NAMES[index] in ACTIVE_RHYTHM_INDEX
}

PRIMARY_PATHOLOGIES = ("ASMI", "LVH", "IMI", "ISC_")
CASCADE_PATHOLOGIES = ("ALMI", "ILMI", "LAE")
ACTIVE_PATHOLOGIES = PRIMARY_PATHOLOGIES + CASCADE_PATHOLOGIES
CANONICAL10_PATHOLOGIES = tuple(PATHOLOGY_CLASS_NAMES)
CLINICAL_AXIS_LABELS = {
    "rate_frequency": ("NSR", "SB", "STACH"),
    "supraventricular_irregular": ("AFIB", "Flutter"),
    "ectopy": ("PAC", "PVC"),
    "conduction": ("RBBB", "LBBB", "1AVB", "2AVB", "3AVB", "Paced"),
    "repolarization_qt": ("LQTS",),
}
CLINICAL_AXIS_HEAD_DIMS = {axis: len(labels) for axis, labels in CLINICAL_AXIS_LABELS.items()}
CLINICAL_AXIS_MANIFEST_COLUMNS = {
    "rate_frequency": "separator_axis_rate_labels",
    "supraventricular_irregular": "separator_axis_supraventricular_irregular_labels",
    "ectopy": "separator_axis_ectopy_labels",
    "conduction": "separator_axis_conduction_labels",
    "repolarization_qt": "separator_axis_repolarization_qt_labels",
}

NUM_RHYTHM_CLASSES = len(ACTIVE14_RHYTHMS)
NUM_PATHOLOGY_CLASSES = len(ACTIVE_PATHOLOGIES)
PRIMARY8_OBJECTIVE_WEIGHT = 0.60
PRIMARY4_OBJECTIVE_WEIGHT = 0.40
PRIMARY_MISSING_PENALTY = 0.05

DISCOVERY_PARENT_NAMES = (
    "00_FUENTES_FISICAS_RAW",
    "03_PULLS_DIRIGIDOS_CLASES_RARAS",
    "04_SEGMENTOS_Y_VENTANAS",
)
EXCLUDED_DISCOVERY_TOKENS = (
    "chapman",
    "chapman_shaoxing",
    "external_test",
    "external_rhythm_pull",
    "05_final_external_validation_set",
    "90_legacy_docs",
    "90_superseded",
)


@dataclass(frozen=True)
class DataContract:
    data_root: Path
    discovery_paths: tuple[Path, ...]
    external_paths: tuple[Path, ...]
    external_pathology_paths: tuple[Path, ...]
    external_dataset: str


def _contains_excluded_token(path: Path, external_dataset: str) -> bool:
    lowered = str(path).replace("\\", "/").lower()
    tokens = set(EXCLUDED_DISCOVERY_TOKENS) | {external_dataset.lower()}
    return any(token in lowered for token in tokens)


def resolve_data_contract(data_root: str | Path, external_dataset: str = "chapman_shaoxing") -> DataContract:
    """Resolve physical discovery roots and the isolated external gate.

    Discovery is intentionally limited to raw sources plus curated rare pulls
    and windows. Manifest-only audit folders and historical test packages are
    never passed into the dataset scanner.
    """

    root = Path(data_root).expanduser().resolve()
    discovery: list[Path] = []
    for parent_name in DISCOVERY_PARENT_NAMES:
        parent = root / parent_name
        if not parent.is_dir():
            continue
        for child in sorted(parent.iterdir(), key=lambda item: item.name.lower()):
            if child.is_dir() and not _contains_excluded_token(child, external_dataset):
                discovery.append(child.resolve())

    external = root / "00_FUENTES_FISICAS_RAW" / external_dataset
    external_paths = (external.resolve(),) if external.is_dir() else ()
    external_pathology = root.parent / "05_FINAL_EXTERNAL_VALIDATION_SET" / "ACTIVE_PACKAGE" / "PTBXL_FOLD10_PATHOLOGY"
    external_pathology_paths = (external_pathology.resolve(),) if external_pathology.is_dir() else ()
    return DataContract(
        data_root=root,
        discovery_paths=tuple(discovery),
        external_paths=external_paths,
        external_pathology_paths=external_pathology_paths,
        external_dataset=str(external_dataset),
    )


def _record_headers(paths: Iterable[str | Path]) -> list[Path]:
    headers: list[Path] = []
    for path in paths:
        headers.extend(Path(path).glob("**/*.hea"))
    return sorted({item.resolve() for item in headers})


def validate_data_contract(contract: DataContract) -> dict[str, object]:
    """Abort on structural data-contract violations before allocating a GPU."""

    if not contract.external_paths:
        raise ValueError("external gate dataset is empty or missing")
    if not contract.external_pathology_paths:
        raise ValueError("external pathology gate package is empty or missing")
    if len(contract.discovery_paths) < 2:
        raise ValueError("discovery must contain more than one eligible source")
    if any(_contains_excluded_token(path, contract.external_dataset) for path in contract.discovery_paths):
        raise ValueError("external or quarantine source leaked into discovery")

    external_headers = _record_headers(contract.external_paths)
    if not external_headers:
        raise ValueError("external gate dataset contains no WFDB .hea records")
    external_pathology_headers = _record_headers(contract.external_pathology_paths)
    if not external_pathology_headers:
        raise ValueError("external pathology gate package contains no WFDB .hea records")

    discovery_headers = _record_headers(contract.discovery_paths)
    if not discovery_headers:
        raise ValueError("discovery contains no WFDB .hea records")

    discovery_records = {normalize_record_path(str(path.with_suffix(""))) for path in discovery_headers}
    external_records = {
        normalize_record_path(str(path.with_suffix("")))
        for path in [*external_headers, *external_pathology_headers]
    }
    overlap = sorted(discovery_records & external_records)
    if overlap:
        raise ValueError(f"train/external overlap detected: {overlap[:5]}")

    return {
        "data_root": str(contract.data_root),
        "discovery_datasets": [path.name for path in contract.discovery_paths],
        "external_gate_datasets": [path.name for path in contract.external_paths],
        "external_pathology_gate_datasets": [path.name for path in contract.external_pathology_paths],
        "discovery_headers": len(discovery_headers),
        "external_headers": len(external_headers),
        "external_pathology_headers": len(external_pathology_headers),
        "overlap_records": 0,
    }


def project_canonical10_pathology_vector(vector: Sequence[float]) -> np.ndarray:
    """Project the canonical pathology-10 order to the primary-first active head."""

    source = np.asarray(vector, dtype=np.float32)
    if source.shape != (len(CANONICAL10_PATHOLOGIES),):
        raise ValueError(f"expected pathology-10 vector, got shape={source.shape}")
    source_index = {name: idx for idx, name in enumerate(CANONICAL10_PATHOLOGIES)}
    return np.asarray([source[source_index[name]] for name in ACTIVE_PATHOLOGIES], dtype=np.float32)


def _labels_to_active_pathologies(labels: Sequence[int], class_names: Sequence[str]) -> np.ndarray:
    active = np.zeros((NUM_PATHOLOGY_CLASSES,), dtype=np.float32)
    active_index = {name: idx for idx, name in enumerate(ACTIVE_PATHOLOGIES)}
    for raw_index in labels:
        try:
            name = class_names[int(raw_index)]
        except (IndexError, TypeError, ValueError):
            continue
        if name in active_index:
            active[active_index[name]] = 1.0
    return active


def load_active_pathology_label_map(data_paths: Sequence[str | Path]) -> dict[str, np.ndarray]:
    """Load projected sidecars and active SNOMED pathology labels by record."""

    record_to_multihot: dict[str, np.ndarray] = {}
    for data_path in data_paths:
        pattern = os.path.join(str(data_path), "**", "*pathology_label_map.json")
        for sidecar in glob.glob(pattern, recursive=True):
            with open(sidecar, "r", encoding="utf-8") as handle:
                payload = json.load(handle)
            class_names = tuple(payload.get("class_names") or CANONICAL10_PATHOLOGIES)
            records = payload.get("records") or {}
            if not isinstance(records, dict):
                continue
            sidecar_root = Path(sidecar).parent
            for relative_record, metadata in records.items():
                if not isinstance(metadata, dict):
                    continue
                labels = metadata.get("labels")
                if not isinstance(labels, list):
                    continue
                key = normalize_record_path(str(sidecar_root / relative_record))
                record_to_multihot[key] = _labels_to_active_pathologies(labels, class_names)

    for header in _record_headers(data_paths):
        record_base = str(header.with_suffix(""))
        labels = pathology_labels_from_snomed_codes(parse_dx_codes_from_header(record_base))
        if not labels:
            continue
        active = _labels_to_active_pathologies(labels, CANONICAL10_PATHOLOGIES)
        if np.any(active):
            key = normalize_record_path(record_base)
            previous = record_to_multihot.get(key)
            record_to_multihot[key] = active if previous is None else np.maximum(previous, active)
    return record_to_multihot


def pathology_targets_for_paths(
    record_paths: Sequence[str | Path],
    pathology_record_to_multihot: Mapping[str, Sequence[float]],
) -> tuple[np.ndarray, np.ndarray]:
    """Build active head-7 targets and a row mask for records with labels."""

    targets = np.zeros((len(record_paths), NUM_PATHOLOGY_CLASSES), dtype=np.float32)
    mask = np.zeros((len(record_paths),), dtype=bool)
    normalized_labels = {
        normalize_record_path(str(record_path)): vector
        for record_path, vector in pathology_record_to_multihot.items()
    }
    for index, record_path in enumerate(record_paths):
        vector = normalized_labels.get(normalize_record_path(str(record_path)))
        if vector is None:
            continue
        projected = np.asarray(vector, dtype=np.float32)
        if projected.shape != (NUM_PATHOLOGY_CLASSES,):
            raise ValueError(f"expected pathology-7 vector for {record_path}, got shape={projected.shape}")
        targets[index, :] = projected
        mask[index] = True
    return targets, mask


def _split_axis_labels(raw: object) -> list[str]:
    text = str(raw or "").strip()
    if not text:
        return []
    for separator in (";", ",", " "):
        text = text.replace(separator, "|")
    return [part.strip() for part in text.split("|") if part.strip()]


def _resolve_manifest_record_base(row: Mapping[str, str], data_root: str | Path | None = None) -> str:
    candidates: list[Path] = []
    for key in ("record_base", "record_path", "path", "hea_base"):
        value = str(row.get(key, "")).strip()
        if value:
            candidates.append(Path(value))
    header = str(row.get("header_path", "")).strip()
    if header:
        candidates.append(Path(header).with_suffix(""))
    if data_root is not None:
        root = Path(data_root).expanduser()
        candidates.extend(root / candidate for candidate in list(candidates) if not candidate.is_absolute())
    for candidate in candidates:
        if Path(str(candidate) + ".hea").is_file():
            return normalize_record_path(str(candidate))
    if candidates:
        return normalize_record_path(str(candidates[0]))
    raise ValueError("manifest row without usable record_base/header_path")


def load_manifest_clinical_axis_label_map(
    manifest_csv: str | Path,
    data_root: str | Path | None = None,
) -> dict[str, dict[str, np.ndarray]]:
    """Load multi-label clinical-axis targets from a derived V3C manifest."""

    record_to_axes: dict[str, dict[str, np.ndarray]] = {}
    with Path(manifest_csv).open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        fieldnames = set(reader.fieldnames or [])
        available_axes = {
            axis: column
            for axis, column in CLINICAL_AXIS_MANIFEST_COLUMNS.items()
            if column in fieldnames
        }
        if not available_axes:
            return record_to_axes
        for row in reader:
            record = _resolve_manifest_record_base(row, data_root=data_root)
            axis_targets: dict[str, np.ndarray] = {}
            for axis, column in available_axes.items():
                labels = CLINICAL_AXIS_LABELS[axis]
                index = {label: idx for idx, label in enumerate(labels)}
                target = np.zeros((len(labels),), dtype=np.float32)
                for label in _split_axis_labels(row.get(column, "")):
                    if label in index:
                        target[index[label]] = 1.0
                axis_targets[axis] = target
            previous = record_to_axes.get(record)
            if previous is not None:
                for axis, target in axis_targets.items():
                    previous[axis] = np.maximum(previous.get(axis, target), target)
            else:
                record_to_axes[record] = axis_targets
    return record_to_axes


def clinical_axis_targets_for_paths(
    record_paths: Sequence[str | Path],
    clinical_axis_record_to_multihot: Mapping[str, Mapping[str, Sequence[float]]],
) -> tuple[dict[str, np.ndarray], np.ndarray]:
    """Build axis-wise multi-hot targets and a row mask for records with V3C labels."""

    normalized = {
        normalize_record_path(str(record_path)): axes
        for record_path, axes in clinical_axis_record_to_multihot.items()
    }
    targets = {
        axis: np.zeros((len(record_paths), len(labels)), dtype=np.float32)
        for axis, labels in CLINICAL_AXIS_LABELS.items()
    }
    mask = np.zeros((len(record_paths),), dtype=bool)
    for row_index, record_path in enumerate(record_paths):
        axes = normalized.get(normalize_record_path(str(record_path)))
        if axes is None:
            continue
        mask[row_index] = True
        for axis, labels in CLINICAL_AXIS_LABELS.items():
            vector = np.asarray(axes.get(axis, np.zeros((len(labels),), dtype=np.float32)), dtype=np.float32)
            if vector.shape != (len(labels),):
                raise ValueError(f"clinical axis {axis} expected shape {(len(labels),)}, got {vector.shape}")
            targets[axis][row_index, :] = vector
    return targets, mask


def composite_optuna_score(metrics: Mapping[str, float | int]) -> float:
    """Score only reportable primary endpoints during model selection."""

    score = (
        PRIMARY8_OBJECTIVE_WEIGHT * float(metrics.get("primary_rhythm_macro_f1", 0.0))
        + PRIMARY4_OBJECTIVE_WEIGHT * float(metrics.get("primary_pathology_macro_f1", 0.0))
    )
    score -= PRIMARY_MISSING_PENALTY * int(metrics.get("missing_primary_rhythm_classes", 0))
    score -= PRIMARY_MISSING_PENALTY * int(metrics.get("missing_primary_pathology_labels", 0))
    return float(score)


def _multilabel_metrics(y_true: np.ndarray, y_prob: np.ndarray, indices: Sequence[int]) -> dict[str, object]:
    if y_true.size == 0 or y_prob.size == 0:
        return {
            "accuracy": 0.0,
            "macro_f1": 0.0,
            "support": [0 for _ in indices],
            "missing_labels": len(indices),
        }
    selected_true = np.asarray(y_true[:, indices], dtype=np.int64)
    selected_pred = np.asarray(y_prob[:, indices] >= 0.5, dtype=np.int64)
    support = selected_true.sum(axis=0).astype(int).tolist()
    return {
        "accuracy": float(np.mean(selected_true == selected_pred)),
        "macro_f1": float(f1_score(selected_true, selected_pred, average="macro", zero_division=0)),
        "support": support,
        "missing_labels": int(sum(value == 0 for value in support)),
    }


def _rhythm_metrics(y_true: np.ndarray, y_pred: np.ndarray, labels: Sequence[int]) -> dict[str, object]:
    mask = np.isin(y_true, labels)
    filtered_true = y_true[mask]
    filtered_pred = y_pred[mask]
    support = [int(np.sum(filtered_true == label)) for label in labels]
    if filtered_true.size == 0:
        return {
            "accuracy": 0.0,
            "balanced_accuracy": 0.0,
            "macro_f1": 0.0,
            "support": support,
            "missing_classes": len(labels),
        }
    recalls = []
    for label in labels:
        label_mask = filtered_true == label
        if not np.any(label_mask):
            continue
        recalls.append(float(np.mean(filtered_pred[label_mask] == label)))
    return {
        "accuracy": float(accuracy_score(filtered_true, filtered_pred)),
        "balanced_accuracy": float(np.mean(recalls)) if recalls else 0.0,
        "macro_f1": float(f1_score(filtered_true, filtered_pred, labels=list(labels), average="macro", zero_division=0)),
        "support": support,
        "missing_classes": int(sum(value == 0 for value in support)),
    }


def evaluate_multihead_predictions(
    rhythm_true: Sequence[int],
    rhythm_pred: Sequence[int],
    pathology_true: Sequence[Sequence[float]] | np.ndarray,
    pathology_prob: Sequence[Sequence[float]] | np.ndarray,
    *,
    rhythm_confidence: Sequence[float] | None = None,
    rhythm_acceptance_threshold: float = 0.0,
    pathology_margin: float = 0.10,
) -> dict[str, object]:
    """Return full-support primary gates and cascade-accepted secondary evidence."""

    y_r_true = np.asarray(rhythm_true, dtype=np.int64)
    y_r_pred = np.asarray(rhythm_pred, dtype=np.int64)
    y_p_true = np.asarray(pathology_true, dtype=np.float32)
    y_p_prob = np.asarray(pathology_prob, dtype=np.float32)
    if y_p_true.size == 0:
        y_p_true = np.empty((0, NUM_PATHOLOGY_CLASSES), dtype=np.float32)
        y_p_prob = np.empty((0, NUM_PATHOLOGY_CLASSES), dtype=np.float32)

    rhythm_all = _rhythm_metrics(y_r_true, y_r_pred, tuple(range(NUM_RHYTHM_CLASSES)))
    primary_rhythm = _rhythm_metrics(y_r_true, y_r_pred, tuple(range(len(PRIMARY_RHYTHMS))))
    pathology_all = _multilabel_metrics(y_p_true, y_p_prob, tuple(range(NUM_PATHOLOGY_CLASSES)))
    primary_pathology = _multilabel_metrics(y_p_true, y_p_prob, tuple(range(len(PRIMARY_PATHOLOGIES))))

    cascade_rhythm_mask = y_r_true >= len(PRIMARY_RHYTHMS)
    if rhythm_confidence is None:
        accepted_rhythm_mask = cascade_rhythm_mask
    else:
        accepted_rhythm_mask = cascade_rhythm_mask & (
            np.asarray(rhythm_confidence, dtype=np.float32) >= float(rhythm_acceptance_threshold)
        )
    cascade_rhythm = _rhythm_metrics(
        y_r_true[accepted_rhythm_mask],
        y_r_pred[accepted_rhythm_mask],
        tuple(range(len(PRIMARY_RHYTHMS), NUM_RHYTHM_CLASSES)),
    )
    cascade_rhythm["coverage"] = float(np.sum(accepted_rhythm_mask) / max(np.sum(cascade_rhythm_mask), 1))

    cascade_indices = tuple(range(len(PRIMARY_PATHOLOGIES), NUM_PATHOLOGY_CLASSES))
    cascade_pathology_full = _multilabel_metrics(y_p_true, y_p_prob, cascade_indices)
    if y_p_true.size:
        accepted_pathology_mask = np.all(np.abs(y_p_prob[:, cascade_indices] - 0.5) >= float(pathology_margin), axis=1)
    else:
        accepted_pathology_mask = np.asarray([], dtype=bool)
    cascade_pathology = _multilabel_metrics(y_p_true[accepted_pathology_mask], y_p_prob[accepted_pathology_mask], cascade_indices)
    cascade_pathology["coverage"] = float(np.sum(accepted_pathology_mask) / max(len(accepted_pathology_mask), 1))
    cascade_pathology["full_support"] = cascade_pathology_full

    flat = {
        "primary_rhythm_macro_f1": float(primary_rhythm["macro_f1"]),
        "primary_pathology_macro_f1": float(primary_pathology["macro_f1"]),
        "primary8_macro_f1": float(primary_rhythm["macro_f1"]),
        "primary8_accuracy": float(primary_rhythm["accuracy"]),
        "primary8_balanced_accuracy": float(primary_rhythm["balanced_accuracy"]),
        "pathology4_macro_f1": float(primary_pathology["macro_f1"]),
        "pathology4_labelwise_accuracy": float(primary_pathology["accuracy"]),
        "rhythm_macro_f1": float(rhythm_all["macro_f1"]),
        "pathology_macro_f1": float(pathology_all["macro_f1"]),
        "rhythm14_macro_f1": float(rhythm_all["macro_f1"]),
        "rhythm14_balanced_accuracy": float(rhythm_all["balanced_accuracy"]),
        "pathology7_macro_f1": float(pathology_all["macro_f1"]),
        "missing_rhythm_classes": int(rhythm_all["missing_classes"]),
        "missing_pathology_labels": int(pathology_all["missing_labels"]),
        "missing_primary_rhythm_classes": int(primary_rhythm["missing_classes"]),
        "missing_primary_pathology_labels": int(primary_pathology["missing_labels"]),
    }
    flat["optuna_composite_score"] = composite_optuna_score(flat)
    return {
        **flat,
        "full_support": {
            "rhythm_primary8": primary_rhythm,
            "rhythm_all": rhythm_all,
            "pathology_primary4": primary_pathology,
            "pathology_all": pathology_all,
            "gate": {
                "rhythm_primary8_passed": bool(primary_rhythm["accuracy"] >= 0.95 and primary_rhythm["macro_f1"] >= 0.80),
                "pathology_primary4_passed": bool(primary_pathology["accuracy"] >= 0.95 and primary_pathology["macro_f1"] >= 0.80),
            },
        },
        "cascade_accepted": {
            "rhythm_cascade": cascade_rhythm,
            "pathology_cascade": cascade_pathology,
        },
    }


def sha256_tree(paths: Sequence[str | Path]) -> dict[str, str]:
    """Hash external files deterministically for the locked gate manifest."""

    out: dict[str, str] = {}
    for root in paths:
        root_path = Path(root).resolve()
        for path in sorted(item for item in root_path.glob("**/*") if item.is_file()):
            digest = hashlib.sha256()
            with path.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                    digest.update(chunk)
            out[str(path.relative_to(root_path)).replace("\\", "/")] = digest.hexdigest()
    return out
