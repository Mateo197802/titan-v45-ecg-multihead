"""Clean Primary6 calibration for the historical V3Q rhythm specialist.

This diagnostic keeps six non-NSR rhythm classes:
AFIB, SB, STACH, RBBB, 1AVB, PVC.

Biases and binary thresholds are selected only on an internal validation
manifest. The external manifest is evaluated once with those frozen values.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

import numpy as np
import torch

from TRAINING.calibrate_v3d_rhythm_logit_biases import build_rhythm_specialist, collect_record_level_logits
from TRAINING.titan_v45_internal_runner import json_ready
from TRAINING.train_v3d_specialists_hpc import (
    PRIMARY8_GATE_CLASSES,
    load_base_model,
    load_manifest_primary8_membership_labels,
)


PRIMARY6_NO_NSR_PAC = ("AFIB", "SB", "STACH", "RBBB", "1AVB", "PVC")


def sigmoid(values: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(values, -50.0, 50.0)))


def binary_metrics_for_thresholds(
    truth: np.ndarray,
    probability: np.ndarray,
    thresholds: Sequence[float],
    class_names: Sequence[str],
) -> tuple[dict[str, object], list[dict[str, object]]]:
    panels: list[dict[str, object]] = []
    for index, class_name in enumerate(class_names):
        pred = probability[:, index] >= float(thresholds[index])
        y = truth[:, index].astype(bool)
        tp = int(np.sum(pred & y))
        tn = int(np.sum(~pred & ~y))
        fp = int(np.sum(pred & ~y))
        fn = int(np.sum(~pred & y))
        precision = float(tp / max(tp + fp, 1))
        recall = float(tp / max(tp + fn, 1))
        f1 = float(2.0 * precision * recall / max(precision + recall, 1e-12))
        accuracy = float((tp + tn) / max(tp + tn + fp + fn, 1))
        panels.append(
            {
                "class": class_name,
                "tp": tp,
                "tn": tn,
                "fp": fp,
                "fn": fn,
                "support": int(tp + fn),
                "accuracy": accuracy,
                "precision": precision,
                "recall": recall,
                "f1": f1,
                "threshold": float(thresholds[index]),
            }
        )
    summary = {
        "binary_mean_accuracy": float(np.mean([row["accuracy"] for row in panels])) if panels else 0.0,
        "binary_macro_f1": float(np.mean([row["f1"] for row in panels])) if panels else 0.0,
        "binary_panels": panels,
    }
    return summary, panels


def tune_thresholds(truth: np.ndarray, probability: np.ndarray, *, steps: int = 181) -> list[float]:
    grid = np.linspace(0.05, 0.95, int(steps), dtype=np.float64)
    thresholds: list[float] = []
    for index in range(truth.shape[1]):
        best_f1 = -1.0
        best_acc = -1.0
        best_threshold = 0.5
        for threshold in grid:
            summary, panels = binary_metrics_for_thresholds(
                truth[:, [index]],
                probability[:, [index]],
                [float(threshold)],
                ["class"],
            )
            panel = panels[0]
            f1 = float(panel["f1"])
            accuracy = float(panel["accuracy"])
            if (f1, accuracy) > (best_f1, best_acc):
                best_f1 = f1
                best_acc = accuracy
                best_threshold = float(threshold)
        thresholds.append(best_threshold)
    return thresholds


def evaluate_with_biases(
    truth: np.ndarray,
    logits: np.ndarray,
    biases: np.ndarray,
    *,
    class_names: Sequence[str],
    thresholds: Sequence[float] | None = None,
) -> dict[str, object]:
    adjusted = logits + biases.reshape(1, -1)
    probability = sigmoid(adjusted)
    if thresholds is None:
        thresholds = tune_thresholds(truth, probability)
    top_pred = np.argmax(adjusted, axis=1)
    top1_correct = truth[np.arange(truth.shape[0]), top_pred] > 0.5
    binary_summary, panels = binary_metrics_for_thresholds(truth, probability, thresholds, class_names)
    return {
        "records": int(truth.shape[0]),
        "accepted_top1_accuracy": float(np.mean(top1_correct)) if truth.shape[0] else 0.0,
        "correct_top1": int(np.sum(top1_correct)),
        "thresholds": [float(value) for value in thresholds],
        "biases": [float(value) for value in biases],
        **binary_summary,
        "binary_panels": panels,
    }


def tune_biases(
    truth: np.ndarray,
    logits: np.ndarray,
    *,
    class_names: Sequence[str],
    grid_min: float,
    grid_max: float,
    grid_steps: int,
    passes: int,
    top1_weight: float,
    f1_weight: float,
    mean_accuracy_weight: float,
) -> tuple[np.ndarray, dict[str, object]]:
    grid = np.linspace(float(grid_min), float(grid_max), int(grid_steps), dtype=np.float64)
    biases = np.zeros((truth.shape[1],), dtype=np.float64)

    def score(report: dict[str, object]) -> float:
        return (
            float(top1_weight) * float(report["accepted_top1_accuracy"])
            + float(f1_weight) * float(report["binary_macro_f1"])
            + float(mean_accuracy_weight) * float(report["binary_mean_accuracy"])
        )

    best_report = evaluate_with_biases(truth, logits, biases, class_names=class_names)
    best_score = score(best_report)
    for _ in range(int(passes)):
        changed = False
        for index in range(truth.shape[1]):
            local_bias = float(biases[index])
            local_report = best_report
            local_score = best_score
            for candidate in grid:
                trial = biases.copy()
                trial[index] = float(candidate)
                report = evaluate_with_biases(truth, logits, trial, class_names=class_names)
                candidate_score = score(report)
                if candidate_score > local_score + 1e-12:
                    local_score = candidate_score
                    local_bias = float(candidate)
                    local_report = report
            if abs(local_bias - float(biases[index])) > 1e-12:
                biases[index] = local_bias
                best_report = local_report
                best_score = local_score
                changed = True
        if not changed:
            break
    return biases.astype(np.float32), best_report


def select_primary6(truth8: np.ndarray, logits8: np.ndarray) -> tuple[np.ndarray, np.ndarray, list[int]]:
    indices = [PRIMARY8_GATE_CLASSES.index(name) for name in PRIMARY6_NO_NSR_PAC]
    truth6 = truth8[:, indices].astype(bool)
    logits6 = logits8[:, indices].astype(np.float64)
    keep_rows = np.sum(truth6, axis=1) > 0
    return truth6[keep_rows], logits6[keep_rows], indices


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data_root", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--v3d_specialists_checkpoint", required=True)
    parser.add_argument("--internal_manifest", required=True)
    parser.add_argument("--external_manifest", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--output_checkpoint", required=True)
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--num_workers", type=int, default=2)
    parser.add_argument("--grid_min", type=float, default=-2.0)
    parser.add_argument("--grid_max", type=float, default=2.0)
    parser.add_argument("--grid_steps", type=int, default=81)
    parser.add_argument("--passes", type=int, default=5)
    parser.add_argument("--top1_weight", type=float, default=8.0)
    parser.add_argument("--f1_weight", type=float, default=1.0)
    parser.add_argument("--mean_accuracy_weight", type=float, default=0.25)
    args = parser.parse_args()

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    base_model, _saved, morphology_dim = load_base_model(args.checkpoint, device)
    specialist_payload = torch.load(args.v3d_specialists_checkpoint, map_location=device)
    specialist = build_rhythm_specialist(specialist_payload, device)

    internal_map = load_manifest_primary8_membership_labels(args.internal_manifest, data_root=str(args.data_root))
    internal_truth8, internal_logits8 = collect_record_level_logits(
        data_root=str(args.data_root),
        base_model=base_model,
        specialist=specialist,
        manifest_csv=str(args.internal_manifest),
        membership_map=internal_map,
        morphology_dim=int(morphology_dim),
        device=device,
        batch_size=int(args.batch_size),
        num_workers=int(args.num_workers),
    )
    internal_truth, internal_logits, primary8_indices = select_primary6(internal_truth8, internal_logits8)
    baseline_internal = evaluate_with_biases(
        internal_truth,
        internal_logits,
        np.zeros((len(PRIMARY6_NO_NSR_PAC),), dtype=np.float32),
        class_names=PRIMARY6_NO_NSR_PAC,
    )
    biases, calibrated_internal = tune_biases(
        internal_truth,
        internal_logits,
        class_names=PRIMARY6_NO_NSR_PAC,
        grid_min=float(args.grid_min),
        grid_max=float(args.grid_max),
        grid_steps=int(args.grid_steps),
        passes=int(args.passes),
        top1_weight=float(args.top1_weight),
        f1_weight=float(args.f1_weight),
        mean_accuracy_weight=float(args.mean_accuracy_weight),
    )

    external_map = load_manifest_primary8_membership_labels(args.external_manifest, data_root=str(args.data_root))
    external_truth8, external_logits8 = collect_record_level_logits(
        data_root=str(args.data_root),
        base_model=base_model,
        specialist=specialist,
        manifest_csv=str(args.external_manifest),
        membership_map=external_map,
        morphology_dim=int(morphology_dim),
        device=device,
        batch_size=int(args.batch_size),
        num_workers=int(args.num_workers),
    )
    external_truth, external_logits, _ = select_primary6(external_truth8, external_logits8)
    baseline_external = evaluate_with_biases(
        external_truth,
        external_logits,
        np.zeros((len(PRIMARY6_NO_NSR_PAC),), dtype=np.float32),
        class_names=PRIMARY6_NO_NSR_PAC,
    )
    calibrated_external = evaluate_with_biases(
        external_truth,
        external_logits,
        biases,
        class_names=PRIMARY6_NO_NSR_PAC,
        thresholds=calibrated_internal["thresholds"],
    )
    needed_95 = int(np.ceil(0.95 * int(calibrated_external["records"])))
    report = {
        "protocol": "TITAN_V45_PRIMARY6_NO_NSR_PAC_CLEAN_INTERNAL_BIAS_CALIBRATION",
        "classes": list(PRIMARY6_NO_NSR_PAC),
        "dropped_from_primary8": ["NSR", "PAC"],
        "primary8_indices": [int(index) for index in primary8_indices],
        "source_checkpoint": str(args.v3d_specialists_checkpoint),
        "base_checkpoint": str(args.checkpoint),
        "internal_manifest": str(args.internal_manifest),
        "external_manifest": str(args.external_manifest),
        "calibration_objective": {
            "top1_weight": float(args.top1_weight),
            "f1_weight": float(args.f1_weight),
            "mean_accuracy_weight": float(args.mean_accuracy_weight),
            "grid_min": float(args.grid_min),
            "grid_max": float(args.grid_max),
            "grid_steps": int(args.grid_steps),
            "passes": int(args.passes),
        },
        "baseline_internal": baseline_internal,
        "calibrated_internal": calibrated_internal,
        "baseline_external": baseline_external,
        "calibrated_external": calibrated_external,
        "external_gate_diagnostic": {
            "accuracy_required": 0.95,
            "macro_f1_required": 0.80,
            "accuracy": float(calibrated_external["accepted_top1_accuracy"]),
            "macro_f1": float(calibrated_external["binary_macro_f1"]),
            "passes": bool(
                float(calibrated_external["accepted_top1_accuracy"]) >= 0.95
                and float(calibrated_external["binary_macro_f1"]) >= 0.80
            ),
            "correct_top1": int(calibrated_external["correct_top1"]),
            "needed_correct_for_95": needed_95,
            "correct_margin_vs_95": int(calibrated_external["correct_top1"]) - needed_95,
        },
    }
    (out / "primary6_no_nsr_pac_clean_calibration_report.json").write_text(
        json.dumps(json_ready(report), indent=2),
        encoding="utf-8",
    )
    calibrated_payload = dict(specialist_payload)
    calibrated_payload["primary6_no_nsr_pac_clean_calibration"] = report
    torch.save(calibrated_payload, args.output_checkpoint)
    print(json.dumps(json_ready(report), indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
