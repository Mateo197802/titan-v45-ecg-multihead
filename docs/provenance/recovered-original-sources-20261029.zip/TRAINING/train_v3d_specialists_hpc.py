"""Train and evaluate V3D specialist heads on top of a frozen V3C checkpoint."""

from __future__ import annotations

import argparse
import csv
import json
import random
from collections import Counter, defaultdict
from pathlib import Path
from typing import Mapping, Sequence

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from torch.utils.data import DataLoader, WeightedRandomSampler

from DATA_PIPELINE.data_loader_ultra import ClinicalECGDataset, TARGET_LENGTH, load_virtual_windows
from REGISTRIES.label_registry import normalize_record_path
from TRAINING.evaluate_external_v3c_adapted_hpc import (
    _accepted_labels,
    _binary_metrics,
    _record_dirs_from_manifest,
    _safe_f1,
    _split_labels,
    _write_rows,
)
from TRAINING.titan_v45_internal_runner import json_ready, manifest_sample_weights_for_indices
from TRAINING.titan_v45_multihead_contract import (
    ACTIVE14_RHYTHMS,
    ACTIVE_PATHOLOGIES,
    NUM_PATHOLOGY_CLASSES,
    NUM_RHYTHM_CLASSES,
    PRIMARY_PATHOLOGIES,
    PRIMARY_RHYTHMS,
)
from TRAINING.titan_v45_multihead_runtime import (
    _lead_mask_from_batch,
    _morphology_from_batch,
    _window_keys_from_batch,
    build_titan_v45_multihead,
)
from TRAINING.training_utils import (
    _resolve_manifest_record_base,
    load_manifest_pathology_labels,
    load_manifest_record_labels,
    load_manifest_sampler_weights,
)
from TRAINING.v3d_gate_tools import (
    PATHOLOGY4_GATE_CLASSES,
    PRIMARY8_GATE_CLASSES,
    SPECIALIST_RHYTHM_CLASSES,
    apply_primary8_specialist_policy,
    apply_thresholds,
    binary_panel_report,
)


PRIMARY8_INDICES = tuple(ACTIVE14_RHYTHMS.index(name) for name in PRIMARY8_GATE_CLASSES)
PRIMARY8_ACTIVE_TO_LOCAL = {active_index: local_index for local_index, active_index in enumerate(PRIMARY8_INDICES)}
EFFECTIVE_SPECIALIST_RHYTHM_CLASSES = tuple(name for name in SPECIALIST_RHYTHM_CLASSES if name in PRIMARY8_GATE_CLASSES)
SPECIALIST_PRIMARY8_INDICES = PRIMARY8_INDICES
BASE_PATHOLOGY_FEATURE_CLASSES = tuple(PRIMARY_PATHOLOGIES)
BASE_PATHOLOGY_FEATURE_INDICES = tuple(ACTIVE_PATHOLOGIES.index(name) for name in BASE_PATHOLOGY_FEATURE_CLASSES)
PATHOLOGY4_INDICES = tuple(
    ACTIVE_PATHOLOGIES.index(name) for name in PATHOLOGY4_GATE_CLASSES if name in ACTIVE_PATHOLOGIES
)
PATHOLOGY4_USES_ACTIVE_HEAD = len(PATHOLOGY4_INDICES) == len(PATHOLOGY4_GATE_CLASSES)
USE_SIGNAL_EVENT_FEATURES = False
CURRENT_SIGNAL_EVENT_FEATURE_DIM = 16
SIGNAL_EVENT_FEATURE_DIM = CURRENT_SIGNAL_EVENT_FEATURE_DIM


def apply_saved_specialist_feature_layout(specialist_saved: Mapping[str, object]) -> None:
    global EFFECTIVE_SPECIALIST_RHYTHM_CLASSES, SPECIALIST_PRIMARY8_INDICES, USE_SIGNAL_EVENT_FEATURES, SIGNAL_EVENT_FEATURE_DIM
    saved_specialist_classes = specialist_saved.get("specialist_rhythm_classes")
    if saved_specialist_classes:
        EFFECTIVE_SPECIALIST_RHYTHM_CLASSES = tuple(
            name for name in saved_specialist_classes if name in PRIMARY8_GATE_CLASSES and name in ACTIVE14_RHYTHMS
        )
        SPECIALIST_PRIMARY8_INDICES = tuple(ACTIVE14_RHYTHMS.index(name) for name in EFFECTIVE_SPECIALIST_RHYTHM_CLASSES)
    USE_SIGNAL_EVENT_FEATURES = bool(specialist_saved.get("signal_event_features", False))
    saved_signal_dim = specialist_saved.get("signal_event_feature_dim")
    if saved_signal_dim is not None:
        SIGNAL_EVENT_FEATURE_DIM = int(saved_signal_dim)


def set_signal_event_feature_mode(enabled: bool, *, feature_dim: int | None = None) -> None:
    global USE_SIGNAL_EVENT_FEATURES, SIGNAL_EVENT_FEATURE_DIM
    USE_SIGNAL_EVENT_FEATURES = bool(enabled)
    if feature_dim is not None:
        SIGNAL_EVENT_FEATURE_DIM = int(feature_dim)


def reset_current_specialist_feature_layout(*, signal_features: bool = False, feature_dim: int | None = None) -> None:
    global EFFECTIVE_SPECIALIST_RHYTHM_CLASSES, SPECIALIST_PRIMARY8_INDICES
    EFFECTIVE_SPECIALIST_RHYTHM_CLASSES = tuple(
        name for name in SPECIALIST_RHYTHM_CLASSES if name in PRIMARY8_GATE_CLASSES and name in ACTIVE14_RHYTHMS
    )
    SPECIALIST_PRIMARY8_INDICES = tuple(ACTIVE14_RHYTHMS.index(name) for name in EFFECTIVE_SPECIALIST_RHYTHM_CLASSES)
    set_signal_event_feature_mode(signal_features, feature_dim=feature_dim)


def infer_specialist_input_dim(state_dict: Mapping[str, torch.Tensor], fallback: int) -> int:
    for key in ("net.0.weight", "heads.0.0.weight"):
        value = state_dict.get(key)
        if value is not None and hasattr(value, "shape") and len(value.shape) >= 1:
            return int(value.shape[0])
    for key, value in state_dict.items():
        if str(key).endswith(".0.weight") and hasattr(value, "shape") and len(value.shape) == 1:
            return int(value.shape[0])
    return int(fallback)


def infer_specialist_hidden_dim(state_dict: Mapping[str, torch.Tensor], fallback: int) -> int:
    for key in ("net.1.weight", "heads.0.1.weight"):
        value = state_dict.get(key)
        if value is not None and hasattr(value, "shape") and len(value.shape) >= 2:
            return int(value.shape[0])
    return int(fallback)


def signal_event_mode_for_input_dim(target_input_dim: int, checkpoint_input_dim: int, checkpoint_uses_signal: bool) -> bool:
    enabled, _feature_dim = signal_event_layout_for_input_dim(
        target_input_dim=target_input_dim,
        checkpoint_input_dim=checkpoint_input_dim,
        checkpoint_signal_dim=SIGNAL_EVENT_FEATURE_DIM,
        checkpoint_uses_signal=checkpoint_uses_signal,
    )
    return enabled


def signal_event_layout_for_input_dim(
    *,
    target_input_dim: int,
    checkpoint_input_dim: int,
    checkpoint_signal_dim: int,
    checkpoint_uses_signal: bool,
) -> tuple[bool, int]:
    if not checkpoint_uses_signal:
        if int(target_input_dim) != int(checkpoint_input_dim):
            raise ValueError(
                f"specialist input mismatch without signal features: {target_input_dim} vs {checkpoint_input_dim}"
            )
        return False, 0
    base_input_dim = int(checkpoint_input_dim) - int(checkpoint_signal_dim)
    target_signal_dim = int(target_input_dim) - base_input_dim
    if target_signal_dim < 0 or target_signal_dim > int(checkpoint_signal_dim):
        raise ValueError(
            "specialist input dimension is incompatible with the saved feature layout: "
            f"target={target_input_dim}, base={base_input_dim}, saved_signal={checkpoint_signal_dim}"
        )
    return target_signal_dim > 0, target_signal_dim


def primary8_local_from_active_index(active_index: int) -> int:
    return int(PRIMARY8_ACTIVE_TO_LOCAL.get(int(active_index), -1))


def primary8_active_from_local_index(local_index: int) -> int:
    if 0 <= int(local_index) < len(PRIMARY8_INDICES):
        return int(PRIMARY8_INDICES[int(local_index)])
    return -1


def active_labels_to_primary8_local_array(labels: Sequence[int] | np.ndarray) -> np.ndarray:
    return np.asarray([primary8_local_from_active_index(int(label)) for label in labels], dtype=np.int64)


def active_labels_to_primary8_local_tensor(labels: torch.Tensor) -> torch.Tensor:
    mapped = active_labels_to_primary8_local_array(labels.detach().cpu().numpy().astype(int).tolist())
    return torch.tensor(mapped, dtype=torch.long, device=labels.device)


def read_rows(path: str | Path) -> list[dict[str, str]]:
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _internal_development_records(
    manifest_csv: str | Path,
    *,
    split_name: str,
    data_root: str | None = None,
) -> set[str]:
    records: set[str] = set()
    rows = read_rows(manifest_csv)
    if not rows:
        raise ValueError(f"{split_name} manifest is empty: {manifest_csv}")
    for row_index, row in enumerate(rows, start=2):
        if "external_reserved" not in row:
            raise ValueError(
                f"{split_name} manifest must declare external_reserved=0 for every row: {manifest_csv}"
            )
        reserved = str(row.get("external_reserved", "")).strip().lower()
        if reserved not in {"0", "false", "no"}:
            raise ValueError(
                f"{split_name} manifest contains external_reserved data at row {row_index}: {manifest_csv}"
            )
        record = normalize_record_path(_resolve_manifest_record_base(row, data_root=data_root))
        records.add(record)
    return records


def validate_development_manifests(
    train_manifest_csv: str | Path,
    val_manifest_csv: str | Path,
    *,
    data_root: str | None = None,
) -> dict[str, object]:
    train_records = _internal_development_records(
        train_manifest_csv,
        split_name="train",
        data_root=data_root,
    )
    val_records = _internal_development_records(
        val_manifest_csv,
        split_name="validation",
        data_root=data_root,
    )
    overlap = sorted(train_records & val_records)
    if overlap:
        preview = ", ".join(overlap[:5])
        raise ValueError(f"train/validation overlap detected ({len(overlap)} records): {preview}")
    return {
        "protocol": "TITAN_V45_INTERNAL_DEVELOPMENT_MANIFEST_AUDIT",
        "train_manifest": str(train_manifest_csv),
        "val_manifest": str(val_manifest_csv),
        "train_records": len(train_records),
        "val_records": len(val_records),
        "overlap_records": 0,
        "external_reserved_records": 0,
    }


def load_virtual_window_label_maps(data_dirs: Sequence[str]) -> tuple[dict[str, int], dict[str, str]]:
    virtual_labels: dict[str, int] = {}
    virtual_groups: dict[str, str] = {}
    for record_base, _start, key, label in load_virtual_windows(data_dirs):
        virtual_labels[key] = int(label)
        virtual_groups[key] = normalize_record_path(record_base)
    return virtual_labels, virtual_groups


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def load_base_model(checkpoint: str | Path, device: torch.device) -> tuple[nn.Module, dict[str, object], int]:
    saved = torch.load(checkpoint, map_location=device)
    if int(saved.get("num_rhythm", 0)) != NUM_RHYTHM_CLASSES:
        raise ValueError("V3D requires a V3C-compatible rhythm checkpoint")
    if int(saved.get("num_pathology", 0)) != NUM_PATHOLOGY_CLASSES:
        raise ValueError("V3D requires a V3C-compatible pathology checkpoint")
    morphology_dim = int(saved.get("morphology_dim", 0) or 0)
    model = build_titan_v45_multihead(morphology_dim=morphology_dim).to(device)
    model.load_state_dict(saved["state_dict"])
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad = False
    return model, saved, morphology_dim


def load_finetune_model(checkpoint: str | Path, device: torch.device) -> tuple[nn.Module, dict[str, object], int]:
    saved = torch.load(checkpoint, map_location=device)
    if int(saved.get("num_rhythm", 0)) != NUM_RHYTHM_CLASSES:
        raise ValueError("V3F requires a V3C-compatible rhythm checkpoint")
    if int(saved.get("num_pathology", 0)) != NUM_PATHOLOGY_CLASSES:
        raise ValueError("V3F requires a V3C-compatible pathology checkpoint")
    morphology_dim = int(saved.get("morphology_dim", 0) or 0)
    model = build_titan_v45_multihead(morphology_dim=morphology_dim).to(device)
    model.load_state_dict(saved["state_dict"])
    return model, saved, morphology_dim


def configure_v3f_trainable(model: nn.Module, *, unfreeze_transformer_layers: int = 2) -> dict[str, int]:
    for parameter in model.parameters():
        parameter.requires_grad = False

    trainable_modules = ["head_rhythm", "head_pathology", "final_norm", "lead_mask_projection"]
    for name in trainable_modules:
        module = getattr(model, name, None)
        if module is None:
            continue
        for parameter in module.parameters():
            parameter.requires_grad = True

    transformer = getattr(model, "transformer", None)
    layers = getattr(transformer, "layers", None)
    if layers is not None and int(unfreeze_transformer_layers) > 0:
        for layer in list(layers)[-int(unfreeze_transformer_layers) :]:
            for parameter in layer.parameters():
                parameter.requires_grad = True

    trainable = int(sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad))
    total = int(sum(parameter.numel() for parameter in model.parameters()))
    return {"trainable_parameters": trainable, "total_parameters": total}


def build_manifest_dataset(
    manifest_csv: str | Path,
    *,
    data_root: str | Path,
    augment: bool,
    morphology_dim: int,
) -> ClinicalECGDataset:
    data_dirs, _rows_by_record = _record_dirs_from_manifest(manifest_csv, data_root)
    labels = load_manifest_record_labels(str(manifest_csv), data_root=str(data_root))
    virtual_labels, _virtual_groups = load_virtual_window_label_maps(data_dirs)
    labels.update(virtual_labels)
    return ClinicalECGDataset(
        data_dirs,
        target_length=TARGET_LENGTH,
        augment=augment,
        record_label_map=labels,
        skip_unlabeled=True,
        return_morphology=morphology_dim > 0,
        return_window_key=True,
    )


def build_pathology_manifest_dataset(
    manifest_csv: str | Path,
    *,
    data_root: str | Path,
    augment: bool,
    morphology_dim: int,
) -> ClinicalECGDataset:
    pathology_labels = load_gate_pathology_labels(str(manifest_csv), data_root=str(data_root))
    data_dirs, _rows_by_record = _record_dirs_from_manifest(manifest_csv, data_root)
    dummy_labels = {record: 0 for record in pathology_labels}
    return ClinicalECGDataset(
        data_dirs,
        target_length=TARGET_LENGTH,
        augment=augment,
        record_label_map=dummy_labels,
        skip_unlabeled=True,
        return_morphology=morphology_dim > 0,
        return_window_key=True,
    )


def complete_manifest_weights_for_dataset(
    dataset: ClinicalECGDataset,
    sampler_weights: Mapping[str, float] | None,
) -> np.ndarray | None:
    if not sampler_weights:
        return None
    try:
        return np.asarray(
            manifest_sample_weights_for_indices(dataset, range(len(dataset)), dict(sampler_weights)),
            dtype=np.float64,
        )
    except ValueError as exc:
        if "Manifest sampler weights missing" in str(exc):
            return None
        raise


def balanced_sampler_for_dataset(dataset: ClinicalECGDataset, *, sampler_weights: Mapping[str, float] | None = None):
    labels: list[int] = []
    for index in range(len(dataset)):
        labels.append(int(dataset.label_for_index(index)))
    counts = Counter(labels)
    weights = np.asarray([1.0 / max(counts[label], 1) for label in labels], dtype=np.float64)
    manifest_weights = complete_manifest_weights_for_dataset(dataset, sampler_weights)
    if manifest_weights is not None:
        weights = weights * manifest_weights
    if weights.size and float(weights.mean()) > 0:
        weights = weights / float(weights.mean())
    weights = np.clip(weights, 0.05, 4.0).astype(np.float64)
    return WeightedRandomSampler(weights.tolist(), num_samples=len(weights), replacement=True), counts, weights


def pathology_balanced_sampler_for_dataset(
    dataset: ClinicalECGDataset,
    pathology_map: Mapping[str, np.ndarray],
) -> tuple[WeightedRandomSampler, dict[str, int], np.ndarray]:
    paths = [str(dataset.windows[index][0]) for index in range(len(dataset))]
    targets = pathology_targets_for_paths(paths, pathology_map) if paths else np.empty((0, len(PATHOLOGY4_GATE_CLASSES)))
    if targets.size == 0:
        weights = np.ones((len(dataset),), dtype=np.float64)
        return WeightedRandomSampler(weights.tolist(), num_samples=len(weights), replacement=True), {}, weights
    positives = np.maximum(targets.sum(axis=0), 1.0)
    class_weights = np.clip(targets.shape[0] / positives, 1.0, 12.0)
    positive_counts = {name: int(targets[:, idx].sum()) for idx, name in enumerate(PATHOLOGY4_GATE_CLASSES)}
    per_sample_positive_count = np.maximum(targets.sum(axis=1), 1.0)
    weights = (targets * class_weights.reshape(1, -1)).sum(axis=1) / per_sample_positive_count
    weights = np.where(targets.sum(axis=1) > 0, weights, 0.25)
    if weights.size and float(weights.mean()) > 0:
        weights = weights / float(weights.mean())
    weights = np.clip(weights, 0.05, 4.0).astype(np.float64)
    return WeightedRandomSampler(weights.tolist(), num_samples=len(weights), replacement=True), positive_counts, weights


def format_label_counts(counts: Mapping[object, int], class_names: Sequence[str]) -> dict[str, int]:
    formatted: dict[str, int] = {}
    for key, value in counts.items():
        if isinstance(key, str):
            formatted[key] = int(value)
            continue
        index = int(key)
        if 0 <= index < len(class_names):
            formatted[class_names[index]] = int(value)
    return formatted


def primary8_labels_from_row(row: Mapping[str, str]) -> list[str]:
    raw = (
        str(row.get("accepted_primary_labels", "")).strip()
        or str(row.get("separator_primary_labels", "")).strip()
        or str(row.get("rhythm_label_name", "")).strip()
    )
    labels = [label for label in _split_labels(raw) if label in PRIMARY8_GATE_CLASSES]
    if not labels:
        raw_index = str(row.get("rhythm_label", "")).strip()
        if raw_index:
            index = int(float(raw_index))
            if index in PRIMARY8_ACTIVE_TO_LOCAL:
                labels = [ACTIVE14_RHYTHMS[index]]
    return sorted(set(labels), key=PRIMARY8_GATE_CLASSES.index)


def pathology_labels_from_row(
    row: Mapping[str, object],
    class_names: Sequence[str] = PATHOLOGY4_GATE_CLASSES,
) -> np.ndarray:
    target = np.zeros((len(class_names),), dtype=np.float32)
    raw_labels = str(row.get("accepted_pathology_labels", "")).strip()
    labels = _split_labels(raw_labels) if raw_labels else []
    if not labels:
        class_name = str(row.get("class_name", "")).strip()
        raw_target = str(row.get("target", "")).strip().casefold()
        if class_name and raw_target in {"1", "1.0", "true", "yes"}:
            labels = [class_name]
    for label in labels:
        if label in class_names:
            target[class_names.index(label)] = 1.0
    return target


def load_gate_pathology_labels(manifest_csv: str, data_root: str | None = None) -> dict[str, np.ndarray]:
    with open(manifest_csv, "r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        fields = set(reader.fieldnames or [])
        if "accepted_pathology_labels" not in fields and not {"class_name", "target"}.issubset(fields):
            return load_manifest_pathology_labels(manifest_csv, data_root=data_root)
        records: dict[str, np.ndarray] = {}
        for row in reader:
            record = normalize_record_path(_resolve_manifest_record_base(row, data_root=data_root))
            target = pathology_labels_from_row(row)
            previous = records.get(record)
            if previous is not None and not np.array_equal(previous, target):
                records[record] = np.maximum(previous, target)
            else:
                records[record] = target
        return records


def load_manifest_primary8_membership_labels(manifest_csv: str, data_root: str | None = None) -> dict[str, np.ndarray]:
    records: dict[str, np.ndarray] = {}
    with open(manifest_csv, "r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            labels = primary8_labels_from_row(row)
            if not labels:
                continue
            target = np.zeros((len(PRIMARY8_GATE_CLASSES),), dtype=np.float32)
            for label in labels:
                target[PRIMARY8_GATE_CLASSES.index(label)] = 1.0
            record = _resolve_manifest_record_base(row, data_root=data_root)
            previous = records.get(record)
            if previous is not None and not np.array_equal(previous, target):
                raise ValueError(f"Conflicting Primary8 membership labels for manifest record: {record}")
            records[record] = target
    if data_root is not None:
        data_dirs, _rows_by_record = _record_dirs_from_manifest(manifest_csv, data_root)
        virtual_labels, _virtual_groups = load_virtual_window_label_maps(data_dirs)
        for key, label in virtual_labels.items():
            local = primary8_local_from_active_index(int(label))
            if local < 0:
                continue
            target = np.zeros((len(PRIMARY8_GATE_CLASSES),), dtype=np.float32)
            target[local] = 1.0
            previous = records.get(key)
            if previous is not None and not np.array_equal(previous, target):
                raise ValueError(f"Conflicting Primary8 virtual membership label for manifest window: {key}")
            records[key] = target
    return records


def _membership_lookup_keys(path_or_keys) -> list[str]:
    if isinstance(path_or_keys, (list, tuple)):
        return [str(key) for key in path_or_keys]
    return [str(path_or_keys)]


def _record_base_from_virtual_or_record_key(path_or_keys) -> str:
    keys = _membership_lookup_keys(path_or_keys)
    for raw_key in reversed(keys):
        key = str(raw_key)
        if key.startswith("virtual::"):
            continue
        return normalize_record_path(key)
    if keys:
        key = str(keys[-1])
        if key.startswith("virtual::"):
            key = key[len("virtual::") :].split("|w:", 1)[0]
        return normalize_record_path(key)
    return normalize_record_path(str(path_or_keys))


def _lookup_membership_target(
    membership_map: Mapping[str, np.ndarray],
    *path_or_keys,
) -> np.ndarray | None:
    for path_or_key in path_or_keys:
        for raw_key in _membership_lookup_keys(path_or_key):
            key = str(raw_key)
            value = membership_map.get(key)
            if value is not None:
                return value
            if key.startswith("virtual::"):
                record_key = key[len("virtual::") :].split("|w:", 1)[0]
                value = membership_map.get(record_key)
                if value is not None:
                    return value
                value = membership_map.get(normalize_record_path(record_key))
                if value is not None:
                    return value
            value = membership_map.get(normalize_record_path(key))
            if value is not None:
                return value
    return None


def primary8_membership_targets_for_paths(paths: Sequence[str], membership_map: Mapping[str, np.ndarray]) -> np.ndarray:
    targets: list[np.ndarray] = []
    for path in paths:
        value = _lookup_membership_target(membership_map, path)
        if value is None:
            value = np.zeros((len(PRIMARY8_GATE_CLASSES),), dtype=np.float32)
        targets.append(np.asarray(value, dtype=np.float32))
    return np.stack(targets, axis=0).astype(np.float32)


def primary8_target_keys_for_dataset(dataset: ClinicalECGDataset) -> list[str | tuple[str, str]]:
    keys: list[str | tuple[str, str]] = []
    for index in range(len(dataset)):
        record_path = str(dataset.windows[index][0])
        if hasattr(dataset, "window_key_for_index"):
            keys.append((str(dataset.window_key_for_index(index)), record_path))
        else:
            keys.append(record_path)
    return keys


def primary8_target_keys_from_batch(batch) -> Sequence[str | tuple[str, str]]:
    record_paths = [str(path) for path in batch[4]]
    window_keys = _window_keys_from_batch(batch)
    if window_keys is None:
        return record_paths
    return [(str(window_key), record_path) for window_key, record_path in zip(window_keys, record_paths)]


def primary8_membership_balanced_sampler_for_dataset(
    dataset: ClinicalECGDataset,
    membership_map: Mapping[str, np.ndarray],
    *,
    sampler_weights: Mapping[str, float] | None = None,
) -> tuple[WeightedRandomSampler, dict[str, int], np.ndarray]:
    paths = primary8_target_keys_for_dataset(dataset)
    targets = primary8_membership_targets_for_paths(paths, membership_map) if paths else np.empty((0, len(PRIMARY8_GATE_CLASSES)))
    if targets.size == 0:
        weights = np.ones((len(dataset),), dtype=np.float64)
        return WeightedRandomSampler(weights.tolist(), num_samples=len(weights), replacement=True), {}, weights

    positives = np.maximum(targets.sum(axis=0), 1.0)
    class_weights = np.clip(targets.shape[0] / positives, 1.0, 12.0)
    counts = {name: int(targets[:, index].sum()) for index, name in enumerate(PRIMARY8_GATE_CLASSES)}
    per_sample_positive_count = np.maximum(targets.sum(axis=1), 1.0)
    weights = (targets * class_weights.reshape(1, -1)).sum(axis=1) / per_sample_positive_count
    weights = np.where(targets.sum(axis=1) > 0, weights, 0.25)
    manifest_weights = complete_manifest_weights_for_dataset(dataset, sampler_weights)
    if manifest_weights is not None:
        weights = weights * manifest_weights
    if weights.size and float(weights.mean()) > 0:
        weights = weights / float(weights.mean())
    weights = np.clip(weights, 0.05, 4.0).astype(np.float64)
    return WeightedRandomSampler(weights.tolist(), num_samples=len(weights), replacement=True), counts, weights


class SpecialistMLP(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, *, hidden_dim: int = 256, dropout: float = 0.25) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(input_dim),
            nn.Linear(input_dim, hidden_dim),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class ClassWiseBinaryMLP(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, *, hidden_dim: int = 192, dropout: float = 0.25) -> None:
        super().__init__()
        self.heads = nn.ModuleList(
            [
                nn.Sequential(
                    nn.LayerNorm(input_dim),
                    nn.Linear(input_dim, hidden_dim),
                    nn.SiLU(),
                    nn.Dropout(dropout),
                    nn.Linear(hidden_dim, hidden_dim),
                    nn.SiLU(),
                    nn.Dropout(dropout),
                    nn.Linear(hidden_dim, 1),
                )
                for _ in range(int(output_dim))
            ]
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.cat([head(x) for head in self.heads], dim=1)


def _select_event_peaks_1d(values: np.ndarray, *, fs: int = 125, min_distance_sec: float = 0.28) -> list[int]:
    values = np.asarray(values, dtype=np.float64)
    if values.size < 3:
        return []
    threshold = max(float(np.percentile(values, 88)), float(np.mean(values) + 0.8 * np.std(values)))
    candidates = np.where(
        (values[1:-1] >= values[:-2])
        & (values[1:-1] >= values[2:])
        & (values[1:-1] >= threshold)
    )[0] + 1
    ordered = sorted(candidates.astype(int).tolist(), key=lambda idx: float(values[idx]), reverse=True)
    min_distance = max(1, int(round(float(min_distance_sec) * int(fs))))
    selected: list[int] = []
    for idx in ordered:
        if all(abs(int(idx) - int(prev)) >= min_distance for prev in selected):
            selected.append(int(idx))
    return sorted(selected)


def _signal_event_features_from_batch(batch_x: torch.Tensor) -> torch.Tensor:
    """Cheap event/interval descriptors for PAC/PVC/AVB specialist decisions."""
    x_np = batch_x.detach().float().cpu().numpy()
    rows: list[list[float]] = []
    fs = 125
    eps = 1e-8
    for sample in x_np:
        signal = np.asarray(sample, dtype=np.float64)
        if signal.ndim != 2 or signal.shape[1] < 4:
            rows.append([0.0] * SIGNAL_EVENT_FEATURE_DIM)
            continue
        lead_index = 1 if signal.shape[0] > 1 and float(np.std(signal[1])) > eps else int(np.argmax(np.std(signal, axis=1)))
        lead = np.nan_to_num(signal[lead_index], nan=0.0, posinf=0.0, neginf=0.0)
        centered = lead - float(np.median(lead))
        detector = np.abs(centered)
        peaks = _select_event_peaks_1d(detector, fs=fs)
        rr = np.diff(peaks) / float(fs) if len(peaks) >= 2 else np.asarray([], dtype=np.float64)
        rr = rr[rr > eps]
        peak_amp = detector[peaks] if peaks else np.asarray([], dtype=np.float64)
        diff_abs = np.abs(np.diff(lead))
        diff_median = float(np.median(diff_abs)) if diff_abs.size else 0.0
        diff_mean_norm = float(np.mean(diff_abs) / max(float(np.std(lead)), eps)) if diff_abs.size else 0.0
        spike_fraction = float(np.mean(diff_abs > max(3.0 * diff_median, eps))) if diff_abs.size else 0.0
        derivative = np.diff(centered)
        zero_cross_rate = float(np.mean(derivative[1:] * derivative[:-1] < 0.0)) if derivative.size >= 2 else 0.0

        peak_count = float(len(peaks))
        hr_proxy = 6.0 * peak_count
        rr_median = float(np.median(rr)) if rr.size else 0.0
        rr_cv = float(np.std(rr) / max(float(np.mean(rr)), eps)) if rr.size else 0.0
        rr_rmssd = float(np.sqrt(np.mean(np.diff(rr) ** 2)) * 1000.0) if rr.size >= 2 else 0.0
        premature_fraction = float(np.mean(rr < 0.80 * rr_median)) if rr.size and rr_median > eps else 0.0
        pause_fraction = float(np.mean(rr > 1.25 * rr_median)) if rr.size and rr_median > eps else 0.0
        peak_amp_cv = float(np.std(peak_amp) / max(float(np.mean(peak_amp)), eps)) if peak_amp.size else 0.0
        qrs_widths: list[float] = []
        pr_intervals: list[float] = []
        qrs_radius = max(1, int(round(0.12 * fs)))
        pr_lookback = max(1, int(round(0.32 * fs)))
        pr_guard = max(1, int(round(0.06 * fs)))
        for peak in peaks:
            amplitude = float(detector[peak])
            if amplitude <= eps:
                continue
            width_threshold = 0.35 * amplitude
            left = int(peak)
            right = int(peak)
            left_limit = max(0, int(peak) - qrs_radius)
            right_limit = min(len(detector) - 1, int(peak) + qrs_radius)
            while left > left_limit and float(detector[left]) >= width_threshold:
                left -= 1
            while right < right_limit and float(detector[right]) >= width_threshold:
                right += 1
            qrs_widths.append(max(0.0, float(right - left - 1) / float(fs)))

            pre_start = max(0, int(peak) - pr_lookback)
            pre_end = max(pre_start, int(peak) - pr_guard)
            pre_segment = np.abs(centered[pre_start:pre_end])
            if pre_segment.size < 3:
                continue
            smooth_width = min(5, int(pre_segment.size))
            kernel = np.ones(smooth_width, dtype=np.float64) / float(smooth_width)
            smoothed = np.convolve(pre_segment, kernel, mode="same")
            p_local = int(np.argmax(smoothed))
            if float(smoothed[p_local]) < 0.05 * amplitude:
                continue
            pr_intervals.append(float(int(peak) - (pre_start + p_local)) / float(fs))

        qrs_median = float(np.median(qrs_widths)) if qrs_widths else 0.0
        qrs_cv = (
            float(np.std(qrs_widths) / max(float(np.mean(qrs_widths)), eps))
            if qrs_widths
            else 0.0
        )
        pr_median = float(np.median(pr_intervals)) if pr_intervals else 0.0
        pr_consistency = (
            1.0 - min(float(np.std(pr_intervals) / max(float(np.mean(pr_intervals)), eps)), 1.0)
            if len(pr_intervals) >= 2
            else 0.0
        )

        features = [
            np.clip(peak_count / 30.0, 0.0, 1.0),
            np.clip(hr_proxy / 220.0, 0.0, 1.0),
            np.clip(rr_cv / 1.5, 0.0, 1.0),
            np.clip(rr_rmssd / 600.0, 0.0, 1.0),
            np.clip((float(np.min(rr)) if rr.size else 0.0) / 2.0, 0.0, 1.0),
            np.clip((float(np.max(rr)) if rr.size else 0.0) / 2.5, 0.0, 1.0),
            np.clip(premature_fraction, 0.0, 1.0),
            np.clip(pause_fraction, 0.0, 1.0),
            np.clip(peak_amp_cv / 2.0, 0.0, 1.0),
            np.clip(diff_mean_norm / 5.0, 0.0, 1.0),
            np.clip(spike_fraction, 0.0, 1.0),
            np.clip(zero_cross_rate, 0.0, 1.0),
            np.clip(qrs_median / 0.20, 0.0, 1.0),
            np.clip(qrs_cv / 1.5, 0.0, 1.0),
            np.clip(pr_median / 0.32, 0.0, 1.0),
            np.clip(pr_consistency, 0.0, 1.0),
        ]
        feature_row = [float(value) for value in features]
        if SIGNAL_EVENT_FEATURE_DIM <= len(feature_row):
            feature_row = feature_row[:SIGNAL_EVENT_FEATURE_DIM]
        else:
            feature_row.extend([0.0] * (SIGNAL_EVENT_FEATURE_DIM - len(feature_row)))
        rows.append(feature_row)
    return torch.tensor(rows, device=batch_x.device, dtype=batch_x.dtype)


def specialist_input_from_base(
    base_model: nn.Module,
    batch,
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    batch_x = batch[0].to(device)
    rhythm_y = batch[1].to(device)
    paths = primary8_target_keys_from_batch(batch)
    lead_mask = _lead_mask_from_batch(batch, batch_x, device)
    morphology = _morphology_from_batch(batch, batch_x, device)
    with torch.no_grad():
        rhythm_logits, _quality, _biometrics, pathology_logits, features = base_model(
            batch_x,
            morphology_features=morphology,
            lead_mask=lead_mask,
            return_features=True,
        )
        rhythm_prob = torch.softmax(rhythm_logits.float(), dim=1)
        pathology_prob = torch.sigmoid(pathology_logits.float())
        pieces = [
            features.float(),
            rhythm_prob[:, PRIMARY8_INDICES],
            rhythm_prob[:, SPECIALIST_PRIMARY8_INDICES],
            pathology_prob[:, BASE_PATHOLOGY_FEATURE_INDICES],
        ]
        if morphology is not None:
            pieces.insert(1, morphology.float())
        if USE_SIGNAL_EVENT_FEATURES:
            pieces.append(_signal_event_features_from_batch(batch_x).float())
        x = torch.cat(pieces, dim=1)
    return x.detach(), rhythm_y.detach(), pathology_prob[:, BASE_PATHOLOGY_FEATURE_INDICES].detach(), paths


def infer_input_dim(base_model: nn.Module, loader: DataLoader, device: torch.device) -> int:
    batch = next(iter(loader))
    features, _labels, _pathology_prob, _paths = specialist_input_from_base(base_model, batch, device)
    return int(features.shape[1])


def local_labels_from_global(labels: torch.Tensor, class_names: Sequence[str]) -> torch.Tensor:
    global_to_local = {ACTIVE14_RHYTHMS.index(name): i for i, name in enumerate(class_names)}
    mapped = [global_to_local.get(int(label), -1) for label in labels.detach().cpu().tolist()]
    return torch.tensor(mapped, dtype=torch.long, device=labels.device)


def class_weight_for_specialist(dataset: ClinicalECGDataset, class_names: Sequence[str], device: torch.device) -> torch.Tensor:
    global_to_local = {ACTIVE14_RHYTHMS.index(name): i for i, name in enumerate(class_names)}
    counts = np.ones((len(class_names),), dtype=np.float64)
    for index in range(len(dataset)):
        local = global_to_local.get(int(dataset.label_for_index(index)))
        if local is not None:
            counts[local] += 1.0
    weights = counts.max() / counts
    weights = np.clip(weights, 1.0, 6.0)
    return torch.tensor(weights, dtype=torch.float32, device=device)


def evaluate_rhythm_specialist(
    base_model: nn.Module,
    specialist: nn.Module,
    loader: DataLoader,
    device: torch.device,
    *,
    min_specialist_confidence: float,
) -> dict[str, object]:
    y_true: list[int] = []
    y_global: list[int] = []
    y_final: list[int] = []
    decisions: list[dict[str, object]] = []
    specialist.eval()
    with torch.no_grad():
        for batch in loader:
            features, labels, _pathology_prob, _paths = specialist_input_from_base(base_model, batch, device)
            logits = specialist(features)
            specialist_prob = torch.softmax(logits.float(), dim=1).detach().cpu().numpy()
            batch_x = batch[0].to(device)
            lead_mask = _lead_mask_from_batch(batch, batch_x, device)
            morphology = _morphology_from_batch(batch, batch_x, device)
            rhythm_logits, _quality, _biometrics, _pathology_logits = base_model(
                batch_x,
                morphology_features=morphology,
                lead_mask=lead_mask,
            )
            primary_prob = torch.softmax(rhythm_logits.float(), dim=1)[:, PRIMARY8_INDICES].detach().cpu().numpy()
            primary_prob = primary_prob / np.maximum(primary_prob.sum(axis=1, keepdims=True), 1e-12)
            final, detail = apply_primary8_specialist_policy(
                primary_prob,
                specialist_prob,
                specialist_classes=EFFECTIVE_SPECIALIST_RHYTHM_CLASSES,
                min_specialist_confidence=min_specialist_confidence,
            )
            y_true.extend(active_labels_to_primary8_local_array(labels.detach().cpu().numpy().astype(int).tolist()).tolist())
            y_global.extend(np.argmax(primary_prob, axis=1).astype(int).tolist())
            y_final.extend(final.astype(int).tolist())
            decisions.extend(detail)
    primary_labels = list(range(len(PRIMARY8_GATE_CLASSES)))
    return {
        "samples": len(y_true),
        "global_accuracy": float(accuracy_score(y_true, y_global)) if y_true else 0.0,
        "global_macro_f1": _safe_f1(np.asarray(y_true), np.asarray(y_global), primary_labels),
        "v3d_accuracy": float(accuracy_score(y_true, y_final)) if y_true else 0.0,
        "v3d_macro_f1": _safe_f1(np.asarray(y_true), np.asarray(y_final), primary_labels),
        "replacement_rate": float(np.mean([item["decision"] == "specialist_replace" for item in decisions])) if decisions else 0.0,
        "confusion_matrix": confusion_matrix(y_true, y_final, labels=list(range(len(PRIMARY8_GATE_CLASSES)))).tolist(),
    }


def evaluate_rhythm_multilabel_specialist(
    base_model: nn.Module,
    specialist: nn.Module,
    loader: DataLoader,
    membership_map: Mapping[str, np.ndarray],
    device: torch.device,
    *,
    thresholds: Sequence[float] | None = None,
) -> dict[str, object]:
    y_true: list[np.ndarray] = []
    y_prob: list[np.ndarray] = []
    y_top_true: list[int] = []
    y_top_pred: list[int] = []
    specialist.eval()
    with torch.no_grad():
        for batch in loader:
            features, labels, _pathology_prob, paths = specialist_input_from_base(base_model, batch, device)
            prob = torch.sigmoid(specialist(features).float()).detach().cpu().numpy()
            y_prob.append(prob)
            targets = primary8_membership_targets_for_paths(paths, membership_map)
            y_true.append(targets)
            y_top_true.extend(active_labels_to_primary8_local_array(labels.detach().cpu().numpy().astype(int).tolist()).tolist())
            y_top_pred.extend(np.argmax(prob, axis=1).astype(int).tolist())
    truth = np.concatenate(y_true, axis=0) if y_true else np.empty((0, len(PRIMARY8_GATE_CLASSES)), dtype=np.float32)
    prob = np.concatenate(y_prob, axis=0) if y_prob else np.empty((0, len(PRIMARY8_GATE_CLASSES)), dtype=np.float32)
    if thresholds is None:
        thresholds = tune_binary_thresholds(truth, prob)
    pred = apply_thresholds(prob, thresholds)
    panel = binary_panel_report(truth, pred, PRIMARY8_GATE_CLASSES)
    return {
        **panel,
        "thresholds": [float(value) for value in thresholds],
        "top1_accuracy": float(accuracy_score(y_top_true, y_top_pred)) if y_top_true else 0.0,
        "top1_macro_f1": _safe_f1(np.asarray(y_top_true), np.asarray(y_top_pred), list(range(len(PRIMARY8_GATE_CLASSES)))),
        "samples": int(truth.shape[0]),
    }


def train_rhythm_multilabel_specialist(
    *,
    base_model: nn.Module,
    train_loader: DataLoader,
    val_loader: DataLoader,
    train_membership_map: Mapping[str, np.ndarray],
    val_membership_map: Mapping[str, np.ndarray],
    device: torch.device,
    input_dim: int,
    epochs: int,
    lr: float,
    output_dir: Path,
    classwise_heads: bool = False,
    top1_loss_weight: float = 0.0,
    epoch_callback=None,
) -> tuple[SpecialistMLP, dict[str, object]]:
    hidden_dim = 512 if classwise_heads else 384
    specialist_cls = ClassWiseBinaryMLP if classwise_heads else SpecialistMLP
    specialist = specialist_cls(input_dim, len(PRIMARY8_GATE_CLASSES), hidden_dim=hidden_dim, dropout=0.30).to(device)
    optimizer = torch.optim.AdamW(specialist.parameters(), lr=lr, weight_decay=1e-4)
    train_targets = np.stack(list(train_membership_map.values()), axis=0)
    positives = np.maximum(train_targets.sum(axis=0), 1.0)
    negatives = max(train_targets.shape[0], 1) - positives
    pos_weight = torch.tensor(np.clip(negatives / positives, 1.0, 8.0), dtype=torch.float32, device=device)
    best_score = -1.0
    best_state = None
    best_thresholds = [0.5] * len(PRIMARY8_GATE_CLASSES)
    log: list[dict[str, object]] = []
    for epoch in range(1, int(epochs) + 1):
        specialist.train()
        losses: list[float] = []
        for batch in train_loader:
            features, labels, _pathology_prob, paths = specialist_input_from_base(base_model, batch, device)
            targets = torch.tensor(primary8_membership_targets_for_paths(paths, train_membership_map), dtype=torch.float32, device=device)
            optimizer.zero_grad(set_to_none=True)
            logits = specialist(features)
            bce = F.binary_cross_entropy_with_logits(logits, targets, pos_weight=pos_weight, reduction="none")
            prob = torch.sigmoid(logits.detach())
            focal = (targets * (1.0 - prob).pow(1.5) + (1.0 - targets) * prob.pow(1.5)).clamp(0.25, 3.0)
            loss = (bce * focal).mean()
            if float(top1_loss_weight) > 0.0:
                local_y = active_labels_to_primary8_local_tensor(labels)
                keep = local_y >= 0
                if torch.any(keep):
                    loss = loss + float(top1_loss_weight) * F.cross_entropy(logits[keep], local_y[keep])
            loss.backward()
            torch.nn.utils.clip_grad_norm_(specialist.parameters(), 2.0)
            optimizer.step()
            losses.append(float(loss.detach().cpu().item()))
        val = evaluate_rhythm_multilabel_specialist(base_model, specialist, val_loader, val_membership_map, device)
        row = {
            "epoch": epoch,
            "train_loss": float(np.mean(losses)) if losses else float("inf"),
            "val_macro_f1": float(val["macro_f1"]),
            "val_mean_accuracy": float(val["mean_accuracy"]),
            "val_top1_accuracy": float(val["top1_accuracy"]),
            "thresholds": val["thresholds"],
        }
        print(json.dumps(json_ready({"rhythm_multilabel_specialist": row})), flush=True)
        log.append(row)
        if epoch_callback is not None:
            epoch_callback(epoch, row, specialist, val)
        score = float(val["macro_f1"]) + 0.20 * float(val["top1_accuracy"]) + 0.10 * float(val["mean_accuracy"])
        if score > best_score:
            best_score = score
            best_thresholds = [float(value) for value in val["thresholds"]]
            best_state = {key: value.detach().cpu() for key, value in specialist.state_dict().items()}
    if best_state is not None:
        specialist.load_state_dict(best_state)
    report = {
        "classes": list(PRIMARY8_GATE_CLASSES),
        "input_dim": input_dim,
        "architecture": "classwise_binary_mlp" if classwise_heads else "shared_multilabel_mlp",
        "hidden_dim": hidden_dim,
        "top1_loss_weight": float(top1_loss_weight),
        "epochs": int(epochs),
        "best_score": best_score,
        "thresholds": best_thresholds,
        "final_validation": evaluate_rhythm_multilabel_specialist(
            base_model,
            specialist,
            val_loader,
            val_membership_map,
            device,
            thresholds=best_thresholds,
        ),
        "log": log,
    }
    (output_dir / "v3e_rhythm_multilabel_specialist_report.json").write_text(json.dumps(json_ready(report), indent=2), encoding="utf-8")
    return specialist, report


def train_rhythm_specialist(
    *,
    base_model: nn.Module,
    train_loader: DataLoader,
    val_loader: DataLoader,
    train_dataset: ClinicalECGDataset,
    device: torch.device,
    input_dim: int,
    epochs: int,
    lr: float,
    output_dir: Path,
    min_specialist_confidence: float,
) -> tuple[SpecialistMLP, dict[str, object]]:
    specialist = SpecialistMLP(input_dim, len(EFFECTIVE_SPECIALIST_RHYTHM_CLASSES), hidden_dim=320, dropout=0.30).to(device)
    optimizer = torch.optim.AdamW(specialist.parameters(), lr=lr, weight_decay=1e-4)
    class_weight = class_weight_for_specialist(train_dataset, EFFECTIVE_SPECIALIST_RHYTHM_CLASSES, device)
    best_score = -1.0
    best_state = None
    log: list[dict[str, object]] = []
    for epoch in range(1, int(epochs) + 1):
        specialist.train()
        losses: list[float] = []
        for batch in train_loader:
            features, labels, _pathology_prob, _paths = specialist_input_from_base(base_model, batch, device)
            local_y = local_labels_from_global(labels, EFFECTIVE_SPECIALIST_RHYTHM_CLASSES)
            keep = local_y >= 0
            if not torch.any(keep):
                continue
            optimizer.zero_grad(set_to_none=True)
            logits = specialist(features[keep])
            loss = F.cross_entropy(logits, local_y[keep], weight=class_weight)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(specialist.parameters(), 2.0)
            optimizer.step()
            losses.append(float(loss.detach().cpu().item()))
        val = evaluate_rhythm_specialist(
            base_model,
            specialist,
            val_loader,
            device,
            min_specialist_confidence=min_specialist_confidence,
        )
        row = {
            "epoch": epoch,
            "train_loss": float(np.mean(losses)) if losses else float("inf"),
            **{f"val_{key}": value for key, value in val.items() if key != "confusion_matrix"},
        }
        print(json.dumps(json_ready({"rhythm_specialist": row})), flush=True)
        log.append(row)
        score = float(val["v3d_macro_f1"]) + 0.25 * float(val["v3d_accuracy"])
        if score > best_score:
            best_score = score
            best_state = {key: value.detach().cpu() for key, value in specialist.state_dict().items()}
    if best_state is not None:
        specialist.load_state_dict(best_state)
    report = {
        "classes": list(EFFECTIVE_SPECIALIST_RHYTHM_CLASSES),
        "input_dim": input_dim,
        "epochs": int(epochs),
        "best_score": best_score,
        "final_validation": evaluate_rhythm_specialist(
            base_model,
            specialist,
            val_loader,
            device,
            min_specialist_confidence=min_specialist_confidence,
        ),
        "log": log,
    }
    (output_dir / "v3d_rhythm_specialist_report.json").write_text(json.dumps(json_ready(report), indent=2), encoding="utf-8")
    return specialist, report


def pathology_targets_for_paths(paths: Sequence[str], pathology_map: Mapping[str, np.ndarray]) -> np.ndarray:
    targets: list[np.ndarray] = []
    for path in paths:
        value = None
        for raw_key in _membership_lookup_keys(path):
            value = pathology_map.get(raw_key)
            if value is not None:
                break
            value = pathology_map.get(normalize_record_path(raw_key))
            if value is not None:
                break
        if value is None:
            value = np.zeros((len(PATHOLOGY4_GATE_CLASSES),), dtype=np.float32)
        array = np.asarray(value, dtype=np.float32).reshape(-1)
        if array.shape[0] == len(PATHOLOGY4_GATE_CLASSES):
            targets.append(array)
        elif PATHOLOGY4_USES_ACTIVE_HEAD and array.shape[0] >= NUM_PATHOLOGY_CLASSES:
            targets.append(array[list(PATHOLOGY4_INDICES)])
        else:
            raise ValueError(
                "pathology target layout mismatch: "
                f"values={array.shape[0]}, gate={len(PATHOLOGY4_GATE_CLASSES)}, active={NUM_PATHOLOGY_CLASSES}"
            )
    return np.stack(targets, axis=0).astype(np.float32)


def pathology_rows_from_panel_index(panel_index_json: str | Path) -> list[dict[str, str]]:
    payload = json.loads(Path(panel_index_json).read_text(encoding="utf-8"))
    panels = payload.get("panels") or {}
    rows: dict[str, dict[str, str]] = {}
    for panel_csv in panels.values():
        for row in read_rows(panel_csv):
            key = str(row.get("record_base") or row.get("header_path") or row.get("record_id"))
            rows[key] = row
    return list(rows.values())


def write_temp_manifest(rows: list[dict[str, str]], path: Path) -> None:
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def append_csv_row(path: Path, row: Mapping[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists()
    with path.open("a", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(row.keys()), extrasaction="ignore")
        if write_header:
            writer.writeheader()
        writer.writerow(row)


def evaluate_pathology_specialist(
    base_model: nn.Module,
    specialist: nn.Module,
    loader: DataLoader,
    pathology_map: Mapping[str, np.ndarray],
    device: torch.device,
    *,
    thresholds: Sequence[float] | None = None,
) -> dict[str, object]:
    y_true: list[np.ndarray] = []
    y_prob: list[np.ndarray] = []
    specialist.eval()
    with torch.no_grad():
        for batch in loader:
            features, _labels, _base_p4, paths = specialist_input_from_base(base_model, batch, device)
            logits = specialist(features)
            y_prob.append(torch.sigmoid(logits.float()).detach().cpu().numpy())
            y_true.append(pathology_targets_for_paths(paths, pathology_map))
    truth = np.concatenate(y_true, axis=0) if y_true else np.empty((0, len(PATHOLOGY4_GATE_CLASSES)), dtype=np.float32)
    prob = np.concatenate(y_prob, axis=0) if y_prob else np.empty((0, len(PATHOLOGY4_GATE_CLASSES)), dtype=np.float32)
    if thresholds is None:
        thresholds = tune_binary_thresholds(truth, prob)
    pred = apply_thresholds(prob, thresholds)
    report = binary_panel_report(truth, pred, PATHOLOGY4_GATE_CLASSES)
    return {
        **report,
        "thresholds": [float(value) for value in thresholds],
        "samples": int(truth.shape[0]),
    }


def tune_binary_thresholds(y_true: np.ndarray, y_prob: np.ndarray) -> list[float]:
    thresholds: list[float] = []
    grid = np.linspace(0.10, 0.90, 33)
    for index in range(y_prob.shape[1]):
        best_threshold = 0.5
        best_f1 = -1.0
        truth = y_true[:, index].astype(int)
        for threshold in grid:
            pred = (y_prob[:, index] >= threshold).astype(int)
            score = f1_score(truth, pred, zero_division=0)
            if score > best_f1:
                best_f1 = float(score)
                best_threshold = float(threshold)
        thresholds.append(best_threshold)
    return thresholds


def train_pathology_specialist(
    *,
    base_model: nn.Module,
    train_loader: DataLoader,
    val_loader: DataLoader,
    train_pathology_map: Mapping[str, np.ndarray],
    val_pathology_map: Mapping[str, np.ndarray],
    device: torch.device,
    input_dim: int,
    epochs: int,
    lr: float,
    output_dir: Path,
    classwise_heads: bool = False,
    epoch_callback=None,
) -> tuple[SpecialistMLP, dict[str, object]]:
    hidden_dim = 512 if classwise_heads else 384
    specialist_cls = ClassWiseBinaryMLP if classwise_heads else SpecialistMLP
    specialist = specialist_cls(input_dim, len(PATHOLOGY4_GATE_CLASSES), hidden_dim=hidden_dim, dropout=0.25).to(device)
    optimizer = torch.optim.AdamW(specialist.parameters(), lr=lr, weight_decay=1e-4)
    train_targets = pathology_targets_for_paths(list(train_pathology_map), train_pathology_map)
    positives = np.maximum(train_targets.sum(axis=0), 1.0)
    negatives = max(train_targets.shape[0], 1) - positives
    pos_weight = torch.tensor(np.clip(negatives / positives, 1.0, 8.0), dtype=torch.float32, device=device)
    best_score = -1.0
    best_state = None
    best_thresholds = [0.5] * len(PATHOLOGY4_GATE_CLASSES)
    log: list[dict[str, object]] = []
    for epoch in range(1, int(epochs) + 1):
        specialist.train()
        losses: list[float] = []
        for batch in train_loader:
            features, _labels, _base_p4, paths = specialist_input_from_base(base_model, batch, device)
            targets = torch.tensor(pathology_targets_for_paths(paths, train_pathology_map), dtype=torch.float32, device=device)
            optimizer.zero_grad(set_to_none=True)
            logits = specialist(features)
            loss = focal_bce_loss(logits, targets, pos_weight=pos_weight, gamma=1.5)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(specialist.parameters(), 2.0)
            optimizer.step()
            losses.append(float(loss.detach().cpu().item()))
        val = evaluate_pathology_specialist(base_model, specialist, val_loader, val_pathology_map, device)
        row = {
            "epoch": epoch,
            "train_loss": float(np.mean(losses)) if losses else float("inf"),
            "val_macro_f1": float(val["macro_f1"]),
            "val_mean_accuracy": float(val["mean_accuracy"]),
            "thresholds": val["thresholds"],
        }
        print(json.dumps(json_ready({"pathology4_specialist": row})), flush=True)
        log.append(row)
        if epoch_callback is not None:
            epoch_callback(epoch, row, specialist, val)
        score = float(val["macro_f1"]) + 0.25 * float(val["mean_accuracy"])
        if score > best_score:
            best_score = score
            best_thresholds = [float(value) for value in val["thresholds"]]
            best_state = {key: value.detach().cpu() for key, value in specialist.state_dict().items()}
    if best_state is not None:
        specialist.load_state_dict(best_state)
    report = {
            "classes": list(PATHOLOGY4_GATE_CLASSES),
            "input_dim": input_dim,
            "architecture": "classwise_binary_mlp" if classwise_heads else "shared_multilabel_mlp",
            "hidden_dim": hidden_dim,
        "epochs": int(epochs),
        "best_score": best_score,
        "thresholds": best_thresholds,
        "final_validation": evaluate_pathology_specialist(
            base_model,
            specialist,
            val_loader,
            val_pathology_map,
            device,
            thresholds=best_thresholds,
        ),
        "log": log,
    }
    (output_dir / "v3d_pathology4_specialist_report.json").write_text(json.dumps(json_ready(report), indent=2), encoding="utf-8")
    return specialist, report


def multilabel_pos_weight(target_map: Mapping[str, np.ndarray], *, width: int, indices: Sequence[int] | None, device: torch.device) -> torch.Tensor:
    if target_map:
        if indices is None:
            targets = np.stack([np.asarray(value, dtype=np.float32)[:width] for value in target_map.values()], axis=0)
        else:
            targets = np.stack([np.asarray(value, dtype=np.float32)[list(indices)] for value in target_map.values()], axis=0)
    else:
        targets = np.zeros((1, width), dtype=np.float32)
    positives = np.maximum(targets.sum(axis=0), 1.0)
    negatives = max(targets.shape[0], 1) - positives
    return torch.tensor(np.clip(negatives / positives, 1.0, 10.0), dtype=torch.float32, device=device)


def focal_bce_loss(logits: torch.Tensor, targets: torch.Tensor, *, pos_weight: torch.Tensor, gamma: float = 1.5) -> torch.Tensor:
    bce = F.binary_cross_entropy_with_logits(logits, targets, pos_weight=pos_weight, reduction="none")
    prob = torch.sigmoid(logits.detach())
    focal = (targets * (1.0 - prob).pow(gamma) + (1.0 - targets) * prob.pow(gamma)).clamp(0.25, 4.0)
    return (bce * focal).mean()


def evaluate_v3f_internal(
    *,
    model: nn.Module,
    rhythm_loader: DataLoader,
    rhythm_membership_map: Mapping[str, np.ndarray],
    pathology_loader: DataLoader,
    pathology_map: Mapping[str, np.ndarray],
    device: torch.device,
) -> dict[str, object]:
    model.eval()
    rhythm_true: list[np.ndarray] = []
    rhythm_prob: list[np.ndarray] = []
    rhythm_top_true: list[int] = []
    rhythm_top_pred: list[int] = []
    pathology_true: list[np.ndarray] = []
    pathology_prob: list[np.ndarray] = []
    with torch.no_grad():
        for batch in rhythm_loader:
            batch_x = batch[0].to(device)
            labels = batch[1].to(device)
            paths = primary8_target_keys_from_batch(batch)
            lead_mask = _lead_mask_from_batch(batch, batch_x, device)
            morphology = _morphology_from_batch(batch, batch_x, device)
            rhythm_logits, _quality, _biometrics, _pathology_logits = model(
                batch_x,
                morphology_features=morphology,
                lead_mask=lead_mask,
            )
            primary_logits = rhythm_logits.float()[:, PRIMARY8_INDICES]
            rhythm_prob.append(torch.sigmoid(primary_logits).detach().cpu().numpy())
            rhythm_true.append(primary8_membership_targets_for_paths(paths, rhythm_membership_map))
            primary_softmax = torch.softmax(primary_logits, dim=1)
            rhythm_top_true.extend(active_labels_to_primary8_local_array(labels.detach().cpu().numpy().astype(int).tolist()).tolist())
            rhythm_top_pred.extend(torch.argmax(primary_softmax, dim=1).detach().cpu().numpy().astype(int).tolist())
        for batch in pathology_loader:
            batch_x = batch[0].to(device)
            paths = primary8_target_keys_from_batch(batch)
            lead_mask = _lead_mask_from_batch(batch, batch_x, device)
            morphology = _morphology_from_batch(batch, batch_x, device)
            _rhythm_logits, _quality, _biometrics, pathology_logits = model(
                batch_x,
                morphology_features=morphology,
                lead_mask=lead_mask,
            )
            pathology_prob.append(torch.sigmoid(pathology_logits.float()[:, PATHOLOGY4_INDICES]).detach().cpu().numpy())
            pathology_true.append(pathology_targets_for_paths(paths, pathology_map))

    rhythm_truth = (
        np.concatenate(rhythm_true, axis=0)
        if rhythm_true
        else np.empty((0, len(PRIMARY8_GATE_CLASSES)), dtype=np.float32)
    )
    rhythm_probability = (
        np.concatenate(rhythm_prob, axis=0)
        if rhythm_prob
        else np.empty((0, len(PRIMARY8_GATE_CLASSES)), dtype=np.float32)
    )
    rhythm_thresholds = tune_binary_thresholds(rhythm_truth, rhythm_probability)
    rhythm_panel = binary_panel_report(rhythm_truth, apply_thresholds(rhythm_probability, rhythm_thresholds), PRIMARY8_GATE_CLASSES)
    rhythm_panel.update(
        {
            "thresholds": rhythm_thresholds,
            "top1_accuracy": float(accuracy_score(rhythm_top_true, rhythm_top_pred)) if rhythm_top_true else 0.0,
            "top1_macro_f1": _safe_f1(np.asarray(rhythm_top_true), np.asarray(rhythm_top_pred), list(range(len(PRIMARY8_GATE_CLASSES)))),
        }
    )

    pathology_truth = (
        np.concatenate(pathology_true, axis=0)
        if pathology_true
        else np.empty((0, len(PATHOLOGY4_GATE_CLASSES)), dtype=np.float32)
    )
    pathology_probability = (
        np.concatenate(pathology_prob, axis=0)
        if pathology_prob
        else np.empty((0, len(PATHOLOGY4_GATE_CLASSES)), dtype=np.float32)
    )
    pathology_thresholds = tune_binary_thresholds(pathology_truth, pathology_probability)
    pathology_panel = binary_panel_report(
        pathology_truth,
        apply_thresholds(pathology_probability, pathology_thresholds),
        PATHOLOGY4_GATE_CLASSES,
    )
    pathology_panel["thresholds"] = pathology_thresholds
    return {"rhythm": rhythm_panel, "pathology4": pathology_panel}


def train_v3f_partial_finetune(
    *,
    model: nn.Module,
    rhythm_train_loader: DataLoader,
    rhythm_val_loader: DataLoader,
    rhythm_train_membership: Mapping[str, np.ndarray],
    rhythm_val_membership: Mapping[str, np.ndarray],
    pathology_train_loader: DataLoader,
    pathology_val_loader: DataLoader,
    pathology_train_map: Mapping[str, np.ndarray],
    pathology_val_map: Mapping[str, np.ndarray],
    device: torch.device,
    epochs: int,
    lr: float,
    output_dir: Path,
) -> dict[str, object]:
    rhythm_pos_weight = multilabel_pos_weight(
        rhythm_train_membership,
        width=len(PRIMARY8_GATE_CLASSES),
        indices=None,
        device=device,
    )
    pathology_pos_weight = multilabel_pos_weight(
        pathology_train_map,
        width=len(PATHOLOGY4_GATE_CLASSES),
        indices=PATHOLOGY4_INDICES,
        device=device,
    )
    optimizer = torch.optim.AdamW((p for p in model.parameters() if p.requires_grad), lr=float(lr), weight_decay=5e-5)
    best_score = -1.0
    best_state = None
    log: list[dict[str, object]] = []
    for epoch in range(1, int(epochs) + 1):
        model.train()
        rhythm_losses: list[float] = []
        pathology_losses: list[float] = []
        for batch in rhythm_train_loader:
            batch_x = batch[0].to(device)
            labels = batch[1].to(device)
            paths = batch[4]
            lead_mask = _lead_mask_from_batch(batch, batch_x, device)
            morphology = _morphology_from_batch(batch, batch_x, device)
            targets = torch.tensor(primary8_membership_targets_for_paths(paths, rhythm_train_membership), dtype=torch.float32, device=device)
            optimizer.zero_grad(set_to_none=True)
            rhythm_logits, _quality, _biometrics, _pathology_logits = model(
                batch_x,
                morphology_features=morphology,
                lead_mask=lead_mask,
            )
            primary_logits = rhythm_logits.float()[:, PRIMARY8_INDICES]
            local_labels = active_labels_to_primary8_local_tensor(labels)
            loss_bce = focal_bce_loss(primary_logits, targets, pos_weight=rhythm_pos_weight)
            loss_ce = F.cross_entropy(primary_logits, local_labels)
            loss = 0.70 * loss_bce + 0.30 * loss_ce
            loss.backward()
            torch.nn.utils.clip_grad_norm_((p for p in model.parameters() if p.requires_grad), 1.5)
            optimizer.step()
            rhythm_losses.append(float(loss.detach().cpu().item()))
        for batch in pathology_train_loader:
            batch_x = batch[0].to(device)
            paths = batch[4]
            lead_mask = _lead_mask_from_batch(batch, batch_x, device)
            morphology = _morphology_from_batch(batch, batch_x, device)
            targets = torch.tensor(pathology_targets_for_paths(paths, pathology_train_map), dtype=torch.float32, device=device)
            optimizer.zero_grad(set_to_none=True)
            _rhythm_logits, _quality, _biometrics, pathology_logits = model(
                batch_x,
                morphology_features=morphology,
                lead_mask=lead_mask,
            )
            loss = focal_bce_loss(pathology_logits.float()[:, PATHOLOGY4_INDICES], targets, pos_weight=pathology_pos_weight)
            loss.backward()
            torch.nn.utils.clip_grad_norm_((p for p in model.parameters() if p.requires_grad), 1.5)
            optimizer.step()
            pathology_losses.append(float(loss.detach().cpu().item()))
        val = evaluate_v3f_internal(
            model=model,
            rhythm_loader=rhythm_val_loader,
            rhythm_membership_map=rhythm_val_membership,
            pathology_loader=pathology_val_loader,
            pathology_map=pathology_val_map,
            device=device,
        )
        row = {
            "epoch": epoch,
            "rhythm_train_loss": float(np.mean(rhythm_losses)) if rhythm_losses else float("inf"),
            "pathology_train_loss": float(np.mean(pathology_losses)) if pathology_losses else float("inf"),
            "rhythm_macro_f1": float(val["rhythm"]["macro_f1"]),
            "rhythm_top1_accuracy": float(val["rhythm"]["top1_accuracy"]),
            "pathology_macro_f1": float(val["pathology4"]["macro_f1"]),
            "pathology_mean_accuracy": float(val["pathology4"]["mean_accuracy"]),
        }
        print(json.dumps(json_ready({"v3f_partial_finetune": row})), flush=True)
        log.append(row)
        score = (
            float(val["rhythm"]["macro_f1"])
            + 0.20 * float(val["rhythm"]["top1_accuracy"])
            + float(val["pathology4"]["macro_f1"])
            + 0.20 * float(val["pathology4"]["mean_accuracy"])
        )
        if score > best_score:
            best_score = score
            best_state = {key: value.detach().cpu() for key, value in model.state_dict().items()}
    if best_state is not None:
        model.load_state_dict(best_state)
    final_validation = evaluate_v3f_internal(
        model=model,
        rhythm_loader=rhythm_val_loader,
        rhythm_membership_map=rhythm_val_membership,
        pathology_loader=pathology_val_loader,
        pathology_map=pathology_val_map,
        device=device,
    )
    report = {"best_score": best_score, "log": log, "final_validation": final_validation}
    (output_dir / "v3f_partial_finetune_report.json").write_text(json.dumps(json_ready(report), indent=2), encoding="utf-8")
    return report


def aggregate_rhythm_records_with_specialist(
    *,
    base_model: nn.Module,
    specialist: nn.Module,
    loader: DataLoader,
    rows_by_record: Mapping[str, Mapping[str, str]],
    device: torch.device,
    min_specialist_confidence: float,
) -> tuple[list[dict[str, object]], np.ndarray, np.ndarray]:
    grouped: dict[str, list[dict[str, object]]] = defaultdict(list)
    specialist.eval()
    with torch.no_grad():
        for batch in loader:
            features, labels, _base_p4, paths = specialist_input_from_base(base_model, batch, device)
            specialist_prob = torch.softmax(specialist(features).float(), dim=1).detach().cpu().numpy()
            batch_x = batch[0].to(device)
            lead_mask = _lead_mask_from_batch(batch, batch_x, device)
            morphology = _morphology_from_batch(batch, batch_x, device)
            rhythm_logits, _quality, _bio, _path = base_model(
                batch_x,
                morphology_features=morphology,
                lead_mask=lead_mask,
            )
            primary_prob = torch.softmax(rhythm_logits.float(), dim=1)[:, PRIMARY8_INDICES].detach().cpu().numpy()
            primary_prob = primary_prob / np.maximum(primary_prob.sum(axis=1, keepdims=True), 1e-12)
            for idx, path in enumerate(paths):
                grouped[_record_base_from_virtual_or_record_key(path)].append(
                    {
                        "primary_prob": primary_prob[idx],
                        "specialist_prob": specialist_prob[idx],
                        "target": int(labels.detach().cpu().numpy()[idx]),
                    }
                )
    record_rows: list[dict[str, object]] = []
    y_true: list[int] = []
    y_pred: list[int] = []
    for record, items in sorted(grouped.items()):
        primary_prob = np.mean([item["primary_prob"] for item in items], axis=0, dtype=np.float64).reshape(1, -1)
        specialist_prob = np.mean([item["specialist_prob"] for item in items], axis=0, dtype=np.float64).reshape(1, -1)
        final, details = apply_primary8_specialist_policy(
            primary_prob,
            specialist_prob,
            specialist_classes=EFFECTIVE_SPECIALIST_RHYTHM_CLASSES,
            min_specialist_confidence=min_specialist_confidence,
        )
        pred = int(final[0])
        target = int(Counter([int(item["target"]) for item in items]).most_common(1)[0][0])
        target_local = primary8_local_from_active_index(target)
        row = dict(rows_by_record.get(record, {}))
        accepted = _accepted_labels(row)
        record_row = {
            "record_base": record,
            "record_id": row.get("record_id", Path(record).name),
            "source": row.get("source", ""),
            "dx_codes": row.get("dx_codes", ""),
            "target_index": target,
            "target_label": ACTIVE14_RHYTHMS[target] if 0 <= target < len(ACTIVE14_RHYTHMS) else f"class_{target}",
            "predicted_index": pred,
            "predicted_label": PRIMARY8_GATE_CLASSES[pred],
            "accepted_labels": "|".join(PRIMARY8_GATE_CLASSES[index] for index in sorted(accepted)),
            "accepted_correct": bool(pred in accepted),
            "single_label_correct": bool(pred == target_local),
            "window_count": len(items),
            **{f"prob_{name}": float(primary_prob[0, index]) for index, name in enumerate(PRIMARY8_GATE_CLASSES)},
            **{f"specialist_prob_{name}": float(specialist_prob[0, index]) for index, name in enumerate(EFFECTIVE_SPECIALIST_RHYTHM_CLASSES)},
            **details[0],
        }
        record_rows.append(record_row)
        y_true.append(target)
        y_pred.append(pred)
    return record_rows, np.asarray(y_true, dtype=np.int64), np.asarray(y_pred, dtype=np.int64)


def membership_gate_from_rows(record_rows: list[dict[str, object]], y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, object]:
    accepted_sets: list[set[int]] = []
    for row in record_rows:
        labels = {
            PRIMARY8_GATE_CLASSES.index(label)
            for label in _split_labels(row.get("accepted_labels"))
            if label in PRIMARY8_GATE_CLASSES
        }
        if not labels:
            target_local = primary8_local_from_active_index(int(row["target_index"]))
            if target_local >= 0:
                labels = {target_local}
        accepted_sets.append(labels)
    accepted_correct = np.asarray([int(pred) in labels for pred, labels in zip(y_pred, accepted_sets)], dtype=bool)
    panels = {}
    for index, name in enumerate(PRIMARY8_GATE_CLASSES):
        true_binary = np.asarray([index in labels for labels in accepted_sets], dtype=bool)
        pred_binary = y_pred == index
        panels[name] = _binary_metrics(true_binary, pred_binary)
    y_true_local = active_labels_to_primary8_local_array(y_true)
    diagnostic_keep = y_true_local >= 0
    diagnostic_true = y_true_local[diagnostic_keep]
    diagnostic_pred = np.asarray(y_pred, dtype=np.int64)[diagnostic_keep]
    return {
        "records": int(len(record_rows)),
        "top1_accepted_accuracy": float(np.mean(accepted_correct)) if len(accepted_correct) else 0.0,
        "binary_panels": panels,
        "binary_panel_macro_f1": float(np.mean([float(panel["f1"]) for panel in panels.values()])) if panels else 0.0,
        "binary_panel_balanced_accuracy": (
            float(np.mean([float(panel["balanced_accuracy"]) for panel in panels.values()])) if panels else 0.0
        ),
        "diagnostic_single_target_accuracy": float(accuracy_score(diagnostic_true, diagnostic_pred)) if len(diagnostic_true) else 0.0,
        "diagnostic_single_target_macro_f1": _safe_f1(diagnostic_true, diagnostic_pred, list(range(len(PRIMARY8_GATE_CLASSES)))),
    }


def membership_gate_from_multilabel_rows(record_rows: list[dict[str, object]], y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, object]:
    accepted_sets: list[set[int]] = []
    predicted_sets: list[set[int]] = []
    for row in record_rows:
        accepted = {
            PRIMARY8_GATE_CLASSES.index(label)
            for label in _split_labels(row.get("accepted_labels"))
            if label in PRIMARY8_GATE_CLASSES
        }
        predicted = {
            PRIMARY8_GATE_CLASSES.index(label)
            for label in _split_labels(row.get("predicted_labels"))
            if label in PRIMARY8_GATE_CLASSES
        }
        if not accepted:
            target_local = primary8_local_from_active_index(int(row["target_index"]))
            if target_local >= 0:
                accepted = {target_local}
        if not predicted:
            predicted = {int(row["predicted_index"])}
        accepted_sets.append(accepted)
        predicted_sets.append(predicted)
    accepted_correct = np.asarray([int(pred) in labels for pred, labels in zip(y_pred, accepted_sets)], dtype=bool)
    panels = {}
    for index, name in enumerate(PRIMARY8_GATE_CLASSES):
        true_binary = np.asarray([index in labels for labels in accepted_sets], dtype=bool)
        pred_binary = np.asarray([index in labels for labels in predicted_sets], dtype=bool)
        panels[name] = _binary_metrics(true_binary, pred_binary)
    y_true_local = active_labels_to_primary8_local_array(y_true)
    diagnostic_keep = y_true_local >= 0
    diagnostic_true = y_true_local[diagnostic_keep]
    diagnostic_pred = np.asarray(y_pred, dtype=np.int64)[diagnostic_keep]
    return {
        "records": int(len(record_rows)),
        "top1_accepted_accuracy": float(np.mean(accepted_correct)) if len(accepted_correct) else 0.0,
        "binary_panels": panels,
        "binary_panel_macro_f1": float(np.mean([float(panel["f1"]) for panel in panels.values()])) if panels else 0.0,
        "binary_panel_balanced_accuracy": (
            float(np.mean([float(panel["balanced_accuracy"]) for panel in panels.values()])) if panels else 0.0
        ),
        "diagnostic_single_target_accuracy": float(accuracy_score(diagnostic_true, diagnostic_pred)) if len(diagnostic_true) else 0.0,
        "diagnostic_single_target_macro_f1": _safe_f1(diagnostic_true, diagnostic_pred, list(range(len(PRIMARY8_GATE_CLASSES)))),
    }


def aggregate_rhythm_records_with_multilabel_specialist(
    *,
    base_model: nn.Module,
    specialist: nn.Module,
    loader: DataLoader,
    rows_by_record: Mapping[str, Mapping[str, str]],
    device: torch.device,
    thresholds: Sequence[float],
    logit_biases: Sequence[float] | None = None,
    membership_map: Mapping[str | tuple[str, str], np.ndarray] | None = None,
) -> tuple[list[dict[str, object]], np.ndarray, np.ndarray]:
    grouped: dict[str, list[dict[str, object]]] = defaultdict(list)
    bias_tensor = None
    if logit_biases is not None:
        bias_values = [float(value) for value in logit_biases]
        if len(bias_values) != len(PRIMARY8_GATE_CLASSES):
            raise ValueError(f"expected {len(PRIMARY8_GATE_CLASSES)} rhythm logit biases, got {len(bias_values)}")
        bias_tensor = torch.tensor(bias_values, dtype=torch.float32, device=device)
    specialist.eval()
    with torch.no_grad():
        for batch in loader:
            features, labels, _base_p4, paths = specialist_input_from_base(base_model, batch, device)
            target_keys = primary8_target_keys_from_batch(batch)
            membership_logits = specialist(features).float()
            if bias_tensor is not None:
                membership_logits = membership_logits + bias_tensor
            membership_prob = torch.sigmoid(membership_logits).detach().cpu().numpy()
            batch_x = batch[0].to(device)
            lead_mask = _lead_mask_from_batch(batch, batch_x, device)
            morphology = _morphology_from_batch(batch, batch_x, device)
            rhythm_logits, _quality, _bio, _path = base_model(
                batch_x,
                morphology_features=morphology,
                lead_mask=lead_mask,
            )
            primary_prob = torch.softmax(rhythm_logits.float(), dim=1)[:, PRIMARY8_INDICES].detach().cpu().numpy()
            primary_prob = primary_prob / np.maximum(primary_prob.sum(axis=1, keepdims=True), 1e-12)
            for idx, path in enumerate(paths):
                membership_target = (
                    _lookup_membership_target(membership_map, target_keys[idx], path)
                    if membership_map is not None
                    else None
                )
                grouped[_record_base_from_virtual_or_record_key(path)].append(
                    {
                        "primary_prob": primary_prob[idx],
                        "membership_prob": membership_prob[idx],
                        "target": int(labels.detach().cpu().numpy()[idx]),
                        "membership_target": membership_target,
                    }
                )
    thresholds_array = np.asarray(thresholds, dtype=np.float64)
    record_rows: list[dict[str, object]] = []
    y_true: list[int] = []
    y_pred: list[int] = []
    for record, items in sorted(grouped.items()):
        primary_prob = np.mean([item["primary_prob"] for item in items], axis=0, dtype=np.float64)
        membership_prob = np.mean([item["membership_prob"] for item in items], axis=0, dtype=np.float64)
        pred = int(np.argmax(membership_prob))
        pred_binary = membership_prob >= thresholds_array
        if not bool(np.any(pred_binary)):
            pred_binary[pred] = True
        target = int(Counter([int(item["target"]) for item in items]).most_common(1)[0][0])
        target_local = primary8_local_from_active_index(target)
        row = dict(rows_by_record.get(record, {}))
        accepted = {PRIMARY8_GATE_CLASSES.index(label) for label in primary8_labels_from_row(row)}
        target_vectors = [
            np.asarray(item["membership_target"], dtype=np.float32)
            for item in items
            if item.get("membership_target") is not None
        ]
        if not accepted and target_vectors:
            target_vector = np.max(np.stack(target_vectors, axis=0), axis=0)
            accepted = {int(index) for index, value in enumerate(target_vector) if float(value) >= 0.5}
        if not accepted:
            accepted = _accepted_labels(row)
        predicted_labels = [PRIMARY8_GATE_CLASSES[index] for index, flag in enumerate(pred_binary) if bool(flag)]
        record_row = {
            "record_base": record,
            "record_id": row.get("record_id", Path(record).name),
            "source": row.get("source", ""),
            "dx_codes": row.get("dx_codes", ""),
            "target_index": target,
            "target_label": ACTIVE14_RHYTHMS[target] if 0 <= target < len(ACTIVE14_RHYTHMS) else f"class_{target}",
            "predicted_index": pred,
            "predicted_label": PRIMARY8_GATE_CLASSES[pred],
            "predicted_labels": "|".join(predicted_labels),
            "accepted_labels": "|".join(PRIMARY8_GATE_CLASSES[index] for index in sorted(accepted)),
            "accepted_correct": bool(pred in accepted),
            "single_label_correct": bool(pred == target_local),
            "window_count": len(items),
            **{f"prob_{name}": float(primary_prob[index]) for index, name in enumerate(PRIMARY8_GATE_CLASSES)},
            **{f"membership_prob_{name}": float(membership_prob[index]) for index, name in enumerate(PRIMARY8_GATE_CLASSES)},
        }
        record_rows.append(record_row)
        y_true.append(target)
        y_pred.append(pred)
    return record_rows, np.asarray(y_true, dtype=np.int64), np.asarray(y_pred, dtype=np.int64)


def evaluate_rhythm_external_view(
    *,
    name: str,
    manifest_csv: str | Path,
    data_root: str | Path,
    base_model: nn.Module,
    specialist: nn.Module,
    device: torch.device,
    output_dir: Path,
    num_workers: int,
    morphology_dim: int,
    min_specialist_confidence: float,
) -> dict[str, object]:
    data_dirs, rows_by_record = _record_dirs_from_manifest(manifest_csv, data_root)
    membership_map = load_manifest_primary8_membership_labels(str(manifest_csv), data_root=str(data_root))
    dataset = build_manifest_dataset(manifest_csv, data_root=data_root, augment=False, morphology_dim=morphology_dim)
    loader = DataLoader(dataset, batch_size=32, shuffle=False, num_workers=num_workers, pin_memory=device.type == "cuda")
    record_rows, y_true, y_pred = aggregate_rhythm_records_with_specialist(
        base_model=base_model,
        specialist=specialist,
        loader=loader,
        rows_by_record=rows_by_record,
        device=device,
        min_specialist_confidence=min_specialist_confidence,
    )
    gate = membership_gate_from_rows(record_rows, y_true, y_pred)
    view_dir = output_dir / name
    view_dir.mkdir(parents=True, exist_ok=True)
    _write_rows(view_dir / "record_predictions.csv", record_rows)
    np.savetxt(
        view_dir / "single_target_confusion_matrix.csv",
        confusion_matrix(active_labels_to_primary8_local_array(y_true), y_pred, labels=list(range(len(PRIMARY8_GATE_CLASSES)))),
        delimiter=",",
        fmt="%d",
    )
    report = {
        "view": name,
        "manifest_csv": str(manifest_csv),
        "records_evaluated": int(len(record_rows)),
        "windows_evaluated": int(len(dataset)),
        "target_fs_hz": 125,
        "input_shape": "12x1250",
        "membership_gate": gate,
    }
    (view_dir / "metrics.json").write_text(json.dumps(json_ready(report), indent=2), encoding="utf-8")
    return report


def evaluate_rhythm_external_multilabel_view(
    *,
    name: str,
    manifest_csv: str | Path,
    data_root: str | Path,
    base_model: nn.Module,
    specialist: nn.Module,
    thresholds: Sequence[float],
    logit_biases: Sequence[float] | None,
    device: torch.device,
    output_dir: Path,
    num_workers: int,
    morphology_dim: int,
) -> dict[str, object]:
    data_dirs, rows_by_record = _record_dirs_from_manifest(manifest_csv, data_root)
    membership_map = load_manifest_primary8_membership_labels(str(manifest_csv), data_root=str(data_root))
    dataset = build_manifest_dataset(manifest_csv, data_root=data_root, augment=False, morphology_dim=morphology_dim)
    loader = DataLoader(dataset, batch_size=32, shuffle=False, num_workers=num_workers, pin_memory=device.type == "cuda")
    record_rows, y_true, y_pred = aggregate_rhythm_records_with_multilabel_specialist(
        base_model=base_model,
        specialist=specialist,
        loader=loader,
        rows_by_record=rows_by_record,
        device=device,
        thresholds=thresholds,
        logit_biases=logit_biases,
        membership_map=membership_map,
    )
    gate = membership_gate_from_multilabel_rows(record_rows, y_true, y_pred)
    view_dir = output_dir / name
    view_dir.mkdir(parents=True, exist_ok=True)
    _write_rows(view_dir / "record_predictions.csv", record_rows)
    np.savetxt(
        view_dir / "single_target_confusion_matrix.csv",
        confusion_matrix(active_labels_to_primary8_local_array(y_true), y_pred, labels=list(range(len(PRIMARY8_GATE_CLASSES)))),
        delimiter=",",
        fmt="%d",
    )
    report = {
        "view": name,
        "manifest_csv": str(manifest_csv),
        "records_evaluated": int(len(record_rows)),
        "windows_evaluated": int(len(dataset)),
        "target_fs_hz": 125,
        "input_shape": "12x1250",
        "thresholds": [float(value) for value in thresholds],
        "logit_biases": [float(value) for value in logit_biases] if logit_biases is not None else None,
        "membership_gate": gate,
    }
    (view_dir / "metrics.json").write_text(json.dumps(json_ready(report), indent=2), encoding="utf-8")
    return report


def pathology_panel_prediction_rows(
    *,
    pathology_name: str,
    paths: Sequence[object],
    truth: np.ndarray,
    probability: np.ndarray,
    threshold: float,
    rows_by_record: Mapping[str, Mapping[str, str]],
) -> list[dict[str, object]]:
    class_index = PATHOLOGY4_GATE_CLASSES.index(pathology_name)
    grouped: dict[str, list[int]] = defaultdict(list)
    for row_index, path in enumerate(paths):
        grouped[_record_base_from_virtual_or_record_key(path)].append(int(row_index))

    rows: list[dict[str, object]] = []
    for record, indices in sorted(grouped.items()):
        panel_row = dict(rows_by_record.get(record, {}))
        target = int(np.max(truth[indices, class_index]).item())
        score = float(np.mean(probability[indices, class_index]).item())
        predicted = int(score >= float(threshold))
        rows.append(
            {
                "record_base": record,
                "record_id": panel_row.get("record_id", Path(record).name),
                "source": panel_row.get("source", ""),
                "dx_codes": panel_row.get("dx_codes", ""),
                "pathology": pathology_name,
                "target": target,
                "probability": score,
                "threshold": float(threshold),
                "predicted": predicted,
                "correct": bool(predicted == target),
                "window_count": len(indices),
            }
        )
    return rows


def evaluate_pathology_external(
    *,
    panel_index_json: str | Path,
    data_root: str | Path,
    base_model: nn.Module,
    specialist: nn.Module,
    thresholds: Sequence[float],
    device: torch.device,
    output_dir: Path,
    num_workers: int,
    morphology_dim: int,
) -> dict[str, object]:
    payload = json.loads(Path(panel_index_json).read_text(encoding="utf-8"))
    panels = payload.get("panels") or {}
    out: dict[str, dict[str, object]] = {}
    for pathology_name in PATHOLOGY4_GATE_CLASSES:
        panel_csv = panels[pathology_name]
        labels = load_gate_pathology_labels(panel_csv, data_root=str(data_root))
        _data_dirs, rows_by_record = _record_dirs_from_manifest(panel_csv, data_root)
        dataset = build_pathology_manifest_dataset(panel_csv, data_root=data_root, augment=False, morphology_dim=morphology_dim)
        if len(dataset) <= 0:
            raise ValueError(f"Pathology external panel produced zero windows: {pathology_name} {panel_csv}")
        loader = DataLoader(dataset, batch_size=32, shuffle=False, num_workers=num_workers, pin_memory=device.type == "cuda")
        y_true: list[np.ndarray] = []
        y_prob: list[np.ndarray] = []
        y_paths: list[object] = []
        with torch.no_grad():
            for batch in loader:
                features, _label, _base_p4, paths = specialist_input_from_base(base_model, batch, device)
                y_prob.append(torch.sigmoid(specialist(features).float()).detach().cpu().numpy())
                y_true.append(pathology_targets_for_paths(paths, labels))
                y_paths.extend(paths)
        truth = np.concatenate(y_true, axis=0)
        prob = np.concatenate(y_prob, axis=0)
        index = PATHOLOGY4_GATE_CLASSES.index(pathology_name)
        pred = apply_thresholds(prob, thresholds)[:, index].astype(bool)
        metrics = _binary_metrics(truth[:, index].astype(bool), pred)
        metrics["records"] = int(len(labels))
        metrics["windows"] = int(len(dataset))
        metrics["threshold"] = float(thresholds[index])
        metrics["manifest_csv"] = str(panel_csv)
        panel_dir = output_dir / "pathology4_panels" / pathology_name
        panel_dir.mkdir(parents=True, exist_ok=True)
        prediction_rows = pathology_panel_prediction_rows(
            pathology_name=pathology_name,
            paths=y_paths,
            truth=truth,
            probability=prob,
            threshold=float(thresholds[index]),
            rows_by_record=rows_by_record,
        )
        _write_rows(panel_dir / "record_predictions.csv", prediction_rows)
        metrics["record_predictions_csv"] = str(panel_dir / "record_predictions.csv")
        out[pathology_name] = metrics
    report = {
        "protocol": "TITAN_V45_V3D_EXTERNAL_PATHOLOGY4_SPECIALIST",
        "panels": out,
        "pathology4_macro_f1": float(np.mean([float(panel["f1"]) for panel in out.values()])),
        "pathology4_accuracy": float(np.mean([float(panel["accuracy"]) for panel in out.values()])),
        "pathology4_balanced_accuracy": float(np.mean([float(panel["balanced_accuracy"]) for panel in out.values()])),
    }
    (output_dir / "pathology4_v3d_specialist_panels.json").write_text(json.dumps(json_ready(report), indent=2), encoding="utf-8")
    return report


def run_finetune(args) -> int:
    if not PATHOLOGY4_USES_ACTIVE_HEAD:
        raise ValueError("finetune requires Pathology4 classes present in the active backbone head")
    seed_everything(int(args.seed))
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    rhythm_manifest_audit = validate_development_manifests(
        args.rhythm_train_manifest,
        args.rhythm_val_manifest,
        data_root=str(args.data_root),
    )
    (out / "rhythm_development_manifest_audit.json").write_text(
        json.dumps(json_ready(rhythm_manifest_audit), indent=2),
        encoding="utf-8",
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model, saved, morphology_dim = load_finetune_model(args.checkpoint, device)
    trainable_report = configure_v3f_trainable(model, unfreeze_transformer_layers=int(args.unfreeze_transformer_layers))

    rhythm_train = build_manifest_dataset(
        args.rhythm_train_manifest,
        data_root=args.data_root,
        augment=True,
        morphology_dim=morphology_dim,
    )
    rhythm_val = build_manifest_dataset(
        args.rhythm_val_manifest,
        data_root=args.data_root,
        augment=False,
        morphology_dim=morphology_dim,
    )
    rhythm_mode = "multilabel"
    rhythm_train_membership = None
    rhythm_val_membership = None
    sampler_weights = load_manifest_sampler_weights(args.rhythm_train_manifest, data_root=str(args.data_root))
    if rhythm_mode == "multilabel":
        rhythm_train_membership = load_manifest_primary8_membership_labels(args.rhythm_train_manifest, data_root=str(args.data_root))
        rhythm_val_membership = load_manifest_primary8_membership_labels(args.rhythm_val_manifest, data_root=str(args.data_root))
        rhythm_sampler, rhythm_counts, rhythm_sample_weights = primary8_membership_balanced_sampler_for_dataset(
            rhythm_train,
            rhythm_train_membership,
            sampler_weights=sampler_weights,
        )
    else:
        rhythm_sampler, rhythm_counts, rhythm_sample_weights = balanced_sampler_for_dataset(
            rhythm_train,
            sampler_weights=sampler_weights,
        )
    rhythm_train_loader = DataLoader(
        rhythm_train,
        batch_size=int(args.batch_size),
        sampler=rhythm_sampler,
        drop_last=True,
        num_workers=int(args.num_workers),
        pin_memory=device.type == "cuda",
    )
    rhythm_val_loader = DataLoader(
        rhythm_val,
        batch_size=int(args.batch_size),
        shuffle=False,
        num_workers=int(args.num_workers),
        pin_memory=device.type == "cuda",
    )
    pathology_train = build_pathology_manifest_dataset(
        args.pathology_train_manifest,
        data_root=args.data_root,
        augment=True,
        morphology_dim=morphology_dim,
    )
    pathology_val_rows = pathology_rows_from_panel_index(args.pathology_val_panel_index)
    pathology_val_manifest = out / "pathology4_internal_val_panels_combined.csv"
    write_temp_manifest(pathology_val_rows, pathology_val_manifest)
    pathology_manifest_audit = validate_development_manifests(
        args.pathology_train_manifest,
        pathology_val_manifest,
        data_root=str(args.data_root),
    )
    (out / "pathology_development_manifest_audit.json").write_text(
        json.dumps(json_ready(pathology_manifest_audit), indent=2),
        encoding="utf-8",
    )
    pathology_val = build_pathology_manifest_dataset(
        pathology_val_manifest,
        data_root=args.data_root,
        augment=False,
        morphology_dim=morphology_dim,
    )
    pathology_train_map = load_gate_pathology_labels(args.pathology_train_manifest, data_root=str(args.data_root))
    pathology_val_map = load_gate_pathology_labels(str(pathology_val_manifest), data_root=str(args.data_root))
    pathology_sampler, pathology_counts, pathology_sample_weights = pathology_balanced_sampler_for_dataset(
        pathology_train,
        pathology_train_map,
    )
    pathology_train_loader = DataLoader(
        pathology_train,
        batch_size=int(args.batch_size),
        sampler=pathology_sampler,
        drop_last=True,
        num_workers=int(args.num_workers),
        pin_memory=device.type == "cuda",
    )
    pathology_val_loader = DataLoader(
        pathology_val,
        batch_size=int(args.batch_size),
        shuffle=False,
        num_workers=int(args.num_workers),
        pin_memory=device.type == "cuda",
    )

    report = train_v3f_partial_finetune(
        model=model,
        rhythm_train_loader=rhythm_train_loader,
        rhythm_val_loader=rhythm_val_loader,
        rhythm_train_membership=rhythm_train_membership,
        rhythm_val_membership=rhythm_val_membership,
        pathology_train_loader=pathology_train_loader,
        pathology_val_loader=pathology_val_loader,
        pathology_train_map=pathology_train_map,
        pathology_val_map=pathology_val_map,
        device=device,
        epochs=int(args.epochs),
        lr=float(args.lr),
        output_dir=out,
    )

    checkpoint = {
        "protocol": "TITAN_V45_V3F_PARTIAL_BACKBONE_FINETUNE",
        "parent_checkpoint": str(args.checkpoint),
        "parent_protocol": saved.get("protocol"),
        "state_dict": model.state_dict(),
        "num_rhythm": NUM_RHYTHM_CLASSES,
        "num_pathology": NUM_PATHOLOGY_CLASSES,
        "morphology_dim": int(morphology_dim),
        "primary8_classes": list(PRIMARY8_GATE_CLASSES),
        "pathology4_classes": list(PATHOLOGY4_GATE_CLASSES),
        "trainable_report": trainable_report,
        "reports": report,
    }
    checkpoint_path = out / "titan_v4_v3f_finetuned_best.pt"
    torch.save(checkpoint, checkpoint_path)
    summary = {
        "protocol": "TITAN_V45_V3F_PARTIAL_BACKBONE_FINETUNE_RUN",
        "device": str(device),
        "checkpoint": str(checkpoint_path),
        "morphology_dim": int(morphology_dim),
        "trainable_report": trainable_report,
        "rhythm_train_windows": len(rhythm_train),
        "rhythm_val_windows": len(rhythm_val),
        "pathology_train_windows": len(pathology_train),
        "pathology_val_windows": len(pathology_val),
        "rhythm_label_counts": format_label_counts(rhythm_counts, PRIMARY8_GATE_CLASSES),
        "pathology_label_counts": format_label_counts(pathology_counts, PATHOLOGY4_GATE_CLASSES),
        "rhythm_sample_weight_max": float(np.max(rhythm_sample_weights)) if len(rhythm_sample_weights) else 0.0,
        "pathology_sample_weight_max": float(np.max(pathology_sample_weights)) if len(pathology_sample_weights) else 0.0,
        "reports": report,
    }
    (out / "v3f_finetune_summary.json").write_text(json.dumps(json_ready(summary), indent=2), encoding="utf-8")
    print(json.dumps(json_ready(summary), indent=2), flush=True)
    return 0


def run_train(args) -> int:
    seed_everything(int(args.seed))
    set_signal_event_feature_mode(bool(int(getattr(args, "signal_features", 0))))
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    rhythm_manifest_audit = validate_development_manifests(
        args.rhythm_train_manifest,
        args.rhythm_val_manifest,
        data_root=str(args.data_root),
    )
    (out / "rhythm_development_manifest_audit.json").write_text(
        json.dumps(json_ready(rhythm_manifest_audit), indent=2),
        encoding="utf-8",
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    base_model, saved, morphology_dim = load_base_model(args.checkpoint, device)

    rhythm_train = build_manifest_dataset(
        args.rhythm_train_manifest,
        data_root=args.data_root,
        augment=True,
        morphology_dim=morphology_dim,
    )
    rhythm_val = build_manifest_dataset(
        args.rhythm_val_manifest,
        data_root=args.data_root,
        augment=False,
        morphology_dim=morphology_dim,
    )
    rhythm_mode = "multilabel" if int(args.rhythm_multilabel) else "softmax"
    rhythm_train_membership = None
    rhythm_val_membership = None
    sampler_weights = load_manifest_sampler_weights(args.rhythm_train_manifest, data_root=str(args.data_root))
    if rhythm_mode == "multilabel":
        rhythm_train_membership = load_manifest_primary8_membership_labels(args.rhythm_train_manifest, data_root=str(args.data_root))
        rhythm_val_membership = load_manifest_primary8_membership_labels(args.rhythm_val_manifest, data_root=str(args.data_root))
        rhythm_sampler, rhythm_counts, rhythm_sample_weights = primary8_membership_balanced_sampler_for_dataset(
            rhythm_train,
            rhythm_train_membership,
            sampler_weights=sampler_weights,
        )
    else:
        rhythm_sampler, rhythm_counts, rhythm_sample_weights = balanced_sampler_for_dataset(
            rhythm_train,
            sampler_weights=sampler_weights,
        )
    rhythm_train_loader = DataLoader(
        rhythm_train,
        batch_size=int(args.batch_size),
        sampler=rhythm_sampler,
        drop_last=True,
        num_workers=int(args.num_workers),
        pin_memory=device.type == "cuda",
    )
    rhythm_val_loader = DataLoader(
        rhythm_val,
        batch_size=int(args.batch_size),
        shuffle=False,
        num_workers=int(args.num_workers),
        pin_memory=device.type == "cuda",
    )
    input_dim = infer_input_dim(base_model, rhythm_train_loader, device)
    if rhythm_mode == "multilabel":
        rhythm_specialist, rhythm_report = train_rhythm_multilabel_specialist(
            base_model=base_model,
            train_loader=rhythm_train_loader,
            val_loader=rhythm_val_loader,
            train_membership_map=rhythm_train_membership or {},
            val_membership_map=rhythm_val_membership or {},
            device=device,
            input_dim=input_dim,
            epochs=int(args.rhythm_epochs),
            lr=float(args.rhythm_lr),
            output_dir=out,
            classwise_heads=bool(int(args.classwise_rhythm_heads)),
            top1_loss_weight=float(getattr(args, "rhythm_top1_loss_weight", 0.0)),
        )
    else:
        rhythm_specialist, rhythm_report = train_rhythm_specialist(
            base_model=base_model,
            train_loader=rhythm_train_loader,
            val_loader=rhythm_val_loader,
            train_dataset=rhythm_train,
            device=device,
            input_dim=input_dim,
            epochs=int(args.rhythm_epochs),
            lr=float(args.rhythm_lr),
            output_dir=out,
            min_specialist_confidence=float(args.min_specialist_confidence),
        )

    def build_specialist_checkpoint(
        *,
        pathology_specialist: nn.Module,
        pathology_report: Mapping[str, object],
        pathology_thresholds: Sequence[float],
    ) -> dict[str, object]:
        return {
            "protocol": "TITAN_V45_V3E_MULTILABEL_SPECIALISTS" if rhythm_mode == "multilabel" else "TITAN_V45_V3D_SPECIALISTS",
            "base_checkpoint": str(args.checkpoint),
            "morphology_dim": int(morphology_dim),
            "input_dim": int(input_dim),
            "signal_event_features": bool(USE_SIGNAL_EVENT_FEATURES),
            "signal_event_feature_dim": int(SIGNAL_EVENT_FEATURE_DIM if USE_SIGNAL_EVENT_FEATURES else 0),
            "primary8_classes": list(PRIMARY8_GATE_CLASSES),
            "pathology4_classes": list(PATHOLOGY4_GATE_CLASSES),
            "specialist_rhythm_classes": list(EFFECTIVE_SPECIALIST_RHYTHM_CLASSES),
            "rhythm_mode": rhythm_mode,
            "classwise_rhythm_heads": bool(int(args.classwise_rhythm_heads)),
            "rhythm_hidden_dim": int(rhythm_report.get("hidden_dim", 384 if rhythm_mode == "multilabel" else 320)),
            "classwise_pathology_heads": bool(int(args.classwise_pathology_heads)),
            "pathology_hidden_dim": int(pathology_report.get("hidden_dim", 320)),
            "min_specialist_confidence": float(args.min_specialist_confidence),
            "rhythm_specialist_state_dict": rhythm_specialist.state_dict(),
            "rhythm_thresholds": rhythm_report.get("thresholds"),
            "pathology4_specialist_state_dict": pathology_specialist.state_dict(),
            "pathology4_thresholds": [float(value) for value in pathology_thresholds],
            "reports": {
                "rhythm": rhythm_report,
                "pathology4": pathology_report,
            },
        }

    pathology_train = build_pathology_manifest_dataset(
        args.pathology_train_manifest,
        data_root=args.data_root,
        augment=True,
        morphology_dim=morphology_dim,
    )
    pathology_val_rows = pathology_rows_from_panel_index(args.pathology_val_panel_index)
    pathology_val_manifest = out / "pathology4_internal_val_panels_combined.csv"
    write_temp_manifest(pathology_val_rows, pathology_val_manifest)
    pathology_manifest_audit = validate_development_manifests(
        args.pathology_train_manifest,
        pathology_val_manifest,
        data_root=str(args.data_root),
    )
    (out / "pathology_development_manifest_audit.json").write_text(
        json.dumps(json_ready(pathology_manifest_audit), indent=2),
        encoding="utf-8",
    )
    pathology_val = build_pathology_manifest_dataset(
        pathology_val_manifest,
        data_root=args.data_root,
        augment=False,
        morphology_dim=morphology_dim,
    )
    pathology_train_map = load_gate_pathology_labels(args.pathology_train_manifest, data_root=str(args.data_root))
    pathology_val_map = load_gate_pathology_labels(str(pathology_val_manifest), data_root=str(args.data_root))
    pathology_sampler, pathology_counts, pathology_sample_weights = pathology_balanced_sampler_for_dataset(
        pathology_train,
        pathology_train_map,
    )
    pathology_train_loader = DataLoader(
        pathology_train,
        batch_size=int(args.batch_size),
        sampler=pathology_sampler,
        drop_last=True,
        num_workers=int(args.num_workers),
        pin_memory=device.type == "cuda",
    )
    epoch_checkpoint_dir = out / "epoch_checkpoints"
    if int(args.save_epoch_checkpoints):
        epoch_checkpoint_dir.mkdir(parents=True, exist_ok=True)

    def save_pathology_epoch_checkpoint(
        epoch: int,
        row: Mapping[str, object],
        pathology_model: nn.Module,
        validation: Mapping[str, object],
    ) -> None:
        if not int(args.save_epoch_checkpoints):
            return
        partial_report = {
            "classes": list(PATHOLOGY4_GATE_CLASSES),
            "input_dim": input_dim,
            "architecture": "classwise_binary_mlp" if bool(int(args.classwise_pathology_heads)) else "shared_multilabel_mlp",
            "hidden_dim": 192 if bool(int(args.classwise_pathology_heads)) else 320,
            "epochs": int(epoch),
            "best_score": float(validation.get("macro_f1", 0.0)) + 0.25 * float(validation.get("mean_accuracy", 0.0)),
            "thresholds": row.get("thresholds", validation.get("thresholds", [0.5] * len(PATHOLOGY4_GATE_CLASSES))),
            "final_validation": validation,
            "log": [dict(row)],
            "checkpoint_scope": "pathology_epoch_current_state",
        }
        checkpoint = build_specialist_checkpoint(
            pathology_specialist=pathology_model,
            pathology_report=partial_report,
            pathology_thresholds=partial_report["thresholds"],
        )
        checkpoint["epoch_checkpoint"] = {
            "pathology_epoch": int(epoch),
            "rhythm_fixed_from_best_internal": True,
            "intended_external_validation": "evaluate this file directly; no top-k/oracle",
        }
        checkpoint_path = epoch_checkpoint_dir / f"v3d_specialists_pathology_epoch_{int(epoch):03d}.pt"
        temporary = checkpoint_path.with_suffix(".tmp")
        torch.save(checkpoint, temporary)
        temporary.replace(checkpoint_path)
        manifest_row = {
            "epoch": int(epoch),
            "checkpoint": str(checkpoint_path),
            "val_macro_f1": float(row.get("val_macro_f1", 0.0)),
            "val_mean_accuracy": float(row.get("val_mean_accuracy", 0.0)),
            "thresholds": row.get("thresholds"),
        }
        with (epoch_checkpoint_dir / "checkpoint_manifest.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(json_ready(manifest_row)) + "\n")
        print(json.dumps(json_ready({"epoch_checkpoint": manifest_row})), flush=True)

    pathology_val_loader = DataLoader(
        pathology_val,
        batch_size=int(args.batch_size),
        shuffle=False,
        num_workers=int(args.num_workers),
        pin_memory=device.type == "cuda",
    )
    pathology_specialist, pathology_report = train_pathology_specialist(
        base_model=base_model,
        train_loader=pathology_train_loader,
        val_loader=pathology_val_loader,
        train_pathology_map=pathology_train_map,
        val_pathology_map=pathology_val_map,
        device=device,
        input_dim=input_dim,
        epochs=int(args.pathology_epochs),
        lr=float(args.pathology_lr),
        output_dir=out,
        classwise_heads=bool(int(args.classwise_pathology_heads)),
        epoch_callback=save_pathology_epoch_checkpoint,
    )

    checkpoint = build_specialist_checkpoint(
        pathology_specialist=pathology_specialist,
        pathology_report=pathology_report,
        pathology_thresholds=pathology_report["thresholds"],
    )
    torch.save(checkpoint, out / "v3d_specialists.pt")
    summary = {
        "protocol": "TITAN_V45_V3D_SPECIALIST_TRAINING_RUN",
        "device": str(device),
        "base_checkpoint_protocol": saved.get("protocol"),
        "morphology_dim": int(morphology_dim),
        "input_dim": int(input_dim),
        "signal_event_features": bool(USE_SIGNAL_EVENT_FEATURES),
        "signal_event_feature_dim": int(SIGNAL_EVENT_FEATURE_DIM if USE_SIGNAL_EVENT_FEATURES else 0),
        "rhythm_train_windows": len(rhythm_train),
        "rhythm_val_windows": len(rhythm_val),
        "pathology_train_windows": len(pathology_train),
        "pathology_val_windows": len(pathology_val),
        "rhythm_label_counts": format_label_counts(rhythm_counts, PRIMARY8_GATE_CLASSES),
        "pathology_label_counts": format_label_counts(pathology_counts, PATHOLOGY4_GATE_CLASSES),
        "rhythm_sample_weight_max": float(np.max(rhythm_sample_weights)) if len(rhythm_sample_weights) else 0.0,
        "pathology_sample_weight_max": float(np.max(pathology_sample_weights)) if len(pathology_sample_weights) else 0.0,
        "checkpoint": str(out / "v3d_specialists.pt"),
        "reports": checkpoint["reports"],
    }
    (out / "v3d_specialist_training_summary.json").write_text(json.dumps(json_ready(summary), indent=2), encoding="utf-8")
    print(json.dumps(json_ready(summary), indent=2), flush=True)
    return 0


def run_train_rhythm_only(args) -> int:
    seed_everything(int(args.seed))
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    rhythm_manifest_audit = validate_development_manifests(
        args.rhythm_train_manifest,
        args.rhythm_val_manifest,
        data_root=str(args.data_root),
    )
    (out / "rhythm_development_manifest_audit.json").write_text(
        json.dumps(json_ready(rhythm_manifest_audit), indent=2),
        encoding="utf-8",
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    base_model, saved, morphology_dim = load_base_model(args.checkpoint, device)
    specialist_saved = torch.load(args.v3d_specialists_checkpoint, map_location=device)
    apply_saved_specialist_feature_layout(specialist_saved)
    set_signal_event_feature_mode(
        bool(int(getattr(args, "signal_features", 0))),
        feature_dim=CURRENT_SIGNAL_EVENT_FEATURE_DIM,
    )

    rhythm_train = build_manifest_dataset(
        args.rhythm_train_manifest,
        data_root=args.data_root,
        augment=True,
        morphology_dim=morphology_dim,
    )
    rhythm_val = build_manifest_dataset(
        args.rhythm_val_manifest,
        data_root=args.data_root,
        augment=False,
        morphology_dim=morphology_dim,
    )
    rhythm_mode = "multilabel" if int(args.rhythm_multilabel) else "softmax"
    if rhythm_mode != "multilabel":
        raise ValueError("train-rhythm currently requires --rhythm_multilabel 1 for clean Primary8 binary panels")
    sampler_weights = load_manifest_sampler_weights(args.rhythm_train_manifest, data_root=str(args.data_root))
    rhythm_train_membership = load_manifest_primary8_membership_labels(args.rhythm_train_manifest, data_root=str(args.data_root))
    rhythm_val_membership = load_manifest_primary8_membership_labels(args.rhythm_val_manifest, data_root=str(args.data_root))
    rhythm_sampler, rhythm_counts, rhythm_sample_weights = primary8_membership_balanced_sampler_for_dataset(
        rhythm_train,
        rhythm_train_membership,
        sampler_weights=sampler_weights,
    )
    rhythm_train_loader = DataLoader(
        rhythm_train,
        batch_size=int(args.batch_size),
        sampler=rhythm_sampler,
        drop_last=True,
        num_workers=int(args.num_workers),
        pin_memory=device.type == "cuda",
    )
    rhythm_val_loader = DataLoader(
        rhythm_val,
        batch_size=int(args.batch_size),
        shuffle=False,
        num_workers=int(args.num_workers),
        pin_memory=device.type == "cuda",
    )
    rhythm_monitor_loader = None
    rhythm_monitor_membership = None
    if getattr(args, "rhythm_monitor_manifest", None):
        monitor_train_audit = validate_development_manifests(
            args.rhythm_train_manifest,
            args.rhythm_monitor_manifest,
            data_root=str(args.data_root),
        )
        monitor_val_audit = validate_development_manifests(
            args.rhythm_val_manifest,
            args.rhythm_monitor_manifest,
            data_root=str(args.data_root),
        )
        (out / "rhythm_external_dev_monitor_audit.json").write_text(
            json.dumps(
                json_ready({"train_vs_monitor": monitor_train_audit, "validation_vs_monitor": monitor_val_audit}),
                indent=2,
            ),
            encoding="utf-8",
        )
        rhythm_monitor = build_manifest_dataset(
            args.rhythm_monitor_manifest,
            data_root=args.data_root,
            augment=False,
            morphology_dim=morphology_dim,
        )
        rhythm_monitor_membership = load_manifest_primary8_membership_labels(
            args.rhythm_monitor_manifest,
            data_root=str(args.data_root),
        )
        rhythm_monitor_loader = DataLoader(
            rhythm_monitor,
            batch_size=int(args.batch_size),
            shuffle=False,
            num_workers=int(args.num_workers),
            pin_memory=device.type == "cuda",
        )
    input_dim = infer_input_dim(base_model, rhythm_train_loader, device)
    classwise_rhythm_heads = bool(int(args.classwise_rhythm_heads))
    rhythm_hidden_dim = 512 if classwise_rhythm_heads else 384
    preserved_pathology_report = specialist_saved.get("reports", {}).get("pathology4", {})
    preserved_pathology_thresholds = specialist_saved.get("pathology4_thresholds", [0.5] * len(PATHOLOGY4_GATE_CLASSES))

    epoch_checkpoint_dir = out / "epoch_checkpoints"
    if int(args.save_epoch_checkpoints):
        epoch_checkpoint_dir.mkdir(parents=True, exist_ok=True)

    def build_rhythm_checkpoint(
        *,
        rhythm_specialist: nn.Module,
        rhythm_report: Mapping[str, object],
        rhythm_thresholds: Sequence[float],
    ) -> dict[str, object]:
        return {
            "protocol": "TITAN_V45_V3O_RHYTHM_ONLY_SPECIALISTS",
            "base_checkpoint": str(args.checkpoint),
            "morphology_dim": int(morphology_dim),
            "input_dim": int(input_dim),
            "signal_event_features": bool(USE_SIGNAL_EVENT_FEATURES),
            "signal_event_feature_dim": int(SIGNAL_EVENT_FEATURE_DIM if USE_SIGNAL_EVENT_FEATURES else 0),
            "primary8_classes": list(PRIMARY8_GATE_CLASSES),
            "pathology4_classes": list(PATHOLOGY4_GATE_CLASSES),
            "specialist_rhythm_classes": list(EFFECTIVE_SPECIALIST_RHYTHM_CLASSES),
            "rhythm_mode": rhythm_mode,
            "classwise_rhythm_heads": classwise_rhythm_heads,
            "rhythm_hidden_dim": int(rhythm_report.get("hidden_dim", rhythm_hidden_dim)),
            "classwise_pathology_heads": bool(specialist_saved.get("classwise_pathology_heads", False)),
            "pathology_hidden_dim": int(specialist_saved.get("pathology_hidden_dim", 320) or 320),
            "min_specialist_confidence": float(specialist_saved.get("min_specialist_confidence", args.min_specialist_confidence)),
            "rhythm_specialist_state_dict": rhythm_specialist.state_dict(),
            "rhythm_thresholds": [float(value) for value in rhythm_thresholds],
            "pathology4_specialist_state_dict": specialist_saved["pathology4_specialist_state_dict"],
            "pathology4_thresholds": [float(value) for value in preserved_pathology_thresholds],
            "reports": {
                "rhythm": rhythm_report,
                "pathology4": preserved_pathology_report,
            },
            "rhythm_only_training": {
                "parent_v3d_specialists_checkpoint": str(args.v3d_specialists_checkpoint),
                "rhythm_train_manifest": str(args.rhythm_train_manifest),
                "rhythm_val_manifest": str(args.rhythm_val_manifest),
            },
        }

    def save_rhythm_epoch_checkpoint(
        epoch: int,
        row: Mapping[str, object],
        rhythm_model: nn.Module,
        validation: Mapping[str, object],
    ) -> None:
        if not int(args.save_epoch_checkpoints):
            return
        partial_report = {
            "classes": list(PRIMARY8_GATE_CLASSES),
            "input_dim": input_dim,
            "architecture": "classwise_binary_mlp" if classwise_rhythm_heads else "shared_multilabel_mlp",
            "hidden_dim": rhythm_hidden_dim,
            "epochs": int(epoch),
            "best_score": float(validation.get("macro_f1", 0.0))
            + 0.20 * float(validation.get("top1_accuracy", 0.0))
            + 0.10 * float(validation.get("mean_accuracy", 0.0)),
            "thresholds": row.get("thresholds", validation.get("thresholds", [0.5] * len(PRIMARY8_GATE_CLASSES))),
            "final_validation": validation,
            "log": [dict(row)],
            "checkpoint_scope": "rhythm_epoch_current_state",
        }
        checkpoint = build_rhythm_checkpoint(
            rhythm_specialist=rhythm_model,
            rhythm_report=partial_report,
            rhythm_thresholds=partial_report["thresholds"],
        )
        checkpoint["epoch_checkpoint"] = {
            "rhythm_epoch": int(epoch),
            "pathology_preserved_from_parent": True,
            "intended_external_validation": "evaluate this file directly; no top-k/oracle",
        }
        checkpoint_path = epoch_checkpoint_dir / f"v3o_rhythm_specialist_epoch_{int(epoch):03d}.pt"
        temporary = checkpoint_path.with_suffix(".tmp")
        torch.save(checkpoint, temporary)
        temporary.replace(checkpoint_path)
        manifest_row = {
            "epoch": int(epoch),
            "checkpoint": str(checkpoint_path),
            "val_macro_f1": float(row.get("val_macro_f1", 0.0)),
            "val_mean_accuracy": float(row.get("val_mean_accuracy", 0.0)),
            "val_top1_accuracy": float(row.get("val_top1_accuracy", 0.0)),
        }
        append_csv_row(epoch_checkpoint_dir / "v3o_rhythm_epoch_checkpoints.csv", manifest_row)

    def save_and_monitor_rhythm_epoch(
        epoch: int,
        row: Mapping[str, object],
        rhythm_model: nn.Module,
        validation: Mapping[str, object],
    ) -> None:
        save_rhythm_epoch_checkpoint(epoch, row, rhythm_model, validation)
        if rhythm_monitor_loader is None or rhythm_monitor_membership is None:
            return
        monitor = evaluate_rhythm_multilabel_specialist(
            base_model,
            rhythm_model,
            rhythm_monitor_loader,
            rhythm_monitor_membership,
            device,
            thresholds=validation.get("thresholds"),
        )
        monitor_row = {
            "epoch": int(epoch),
            "external_dev_macro_f1": float(monitor["macro_f1"]),
            "external_dev_mean_accuracy": float(monitor["mean_accuracy"]),
            "external_dev_balanced_accuracy": float(monitor["mean_balanced_accuracy"]),
            "external_dev_top1_accuracy": float(monitor["top1_accuracy"]),
            "samples": int(monitor["samples"]),
        }
        append_csv_row(out / "rhythm_external_dev_epoch_metrics.csv", monitor_row)
        print(json.dumps(json_ready({"rhythm_external_dev_monitor": monitor_row})), flush=True)

    rhythm_specialist, rhythm_report = train_rhythm_multilabel_specialist(
        base_model=base_model,
        train_loader=rhythm_train_loader,
        val_loader=rhythm_val_loader,
        train_membership_map=rhythm_train_membership,
        val_membership_map=rhythm_val_membership,
        device=device,
        input_dim=input_dim,
        epochs=int(args.rhythm_epochs),
        lr=float(args.rhythm_lr),
        output_dir=out,
        classwise_heads=classwise_rhythm_heads,
        top1_loss_weight=float(getattr(args, "rhythm_top1_loss_weight", 0.0)),
        epoch_callback=save_and_monitor_rhythm_epoch,
    )
    checkpoint = build_rhythm_checkpoint(
        rhythm_specialist=rhythm_specialist,
        rhythm_report=rhythm_report,
        rhythm_thresholds=rhythm_report["thresholds"],
    )
    torch.save(checkpoint, out / "v3d_specialists.pt")
    summary = {
        "protocol": "TITAN_V45_V3O_RHYTHM_ONLY_TRAINING_RUN",
        "device": str(device),
        "base_checkpoint_protocol": saved.get("protocol"),
        "morphology_dim": int(morphology_dim),
        "input_dim": int(input_dim),
        "signal_event_features": bool(USE_SIGNAL_EVENT_FEATURES),
        "signal_event_feature_dim": int(SIGNAL_EVENT_FEATURE_DIM if USE_SIGNAL_EVENT_FEATURES else 0),
        "rhythm_train_windows": len(rhythm_train),
        "rhythm_val_windows": len(rhythm_val),
        "rhythm_label_counts": format_label_counts(rhythm_counts, PRIMARY8_GATE_CLASSES),
        "rhythm_sample_weight_max": float(np.max(rhythm_sample_weights)) if len(rhythm_sample_weights) else 0.0,
        "checkpoint": str(out / "v3d_specialists.pt"),
        "rhythm_external_dev_monitor_manifest": str(getattr(args, "rhythm_monitor_manifest", "") or ""),
        "reports": checkpoint["reports"],
    }
    (out / "v3o_rhythm_only_training_summary.json").write_text(json.dumps(json_ready(summary), indent=2), encoding="utf-8")
    print(json.dumps(json_ready(summary), indent=2), flush=True)
    return 0


def run_train_p4_only(args) -> int:
    seed_everything(int(args.seed))
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    base_model, saved, morphology_dim = load_base_model(args.checkpoint, device)
    specialist_saved = torch.load(args.v3d_specialists_checkpoint, map_location=device)
    parent_input_dim = int(specialist_saved["input_dim"])
    reset_current_specialist_feature_layout(
        signal_features=bool(int(getattr(args, "signal_features", 0))),
        feature_dim=CURRENT_SIGNAL_EVENT_FEATURE_DIM,
    )

    pathology_train = build_pathology_manifest_dataset(
        args.pathology_train_manifest,
        data_root=args.data_root,
        augment=True,
        morphology_dim=morphology_dim,
    )
    pathology_val_rows = pathology_rows_from_panel_index(args.pathology_val_panel_index)
    pathology_val_manifest = out / "pathology4_internal_val_panels_combined.csv"
    write_temp_manifest(pathology_val_rows, pathology_val_manifest)
    pathology_manifest_audit = validate_development_manifests(
        args.pathology_train_manifest,
        pathology_val_manifest,
        data_root=str(args.data_root),
    )
    (out / "pathology_development_manifest_audit.json").write_text(
        json.dumps(json_ready(pathology_manifest_audit), indent=2),
        encoding="utf-8",
    )
    pathology_val = build_pathology_manifest_dataset(
        pathology_val_manifest,
        data_root=args.data_root,
        augment=False,
        morphology_dim=morphology_dim,
    )
    pathology_train_map = load_gate_pathology_labels(args.pathology_train_manifest, data_root=str(args.data_root))
    pathology_val_map = load_gate_pathology_labels(str(pathology_val_manifest), data_root=str(args.data_root))
    pathology_sampler, pathology_counts, pathology_sample_weights = pathology_balanced_sampler_for_dataset(
        pathology_train,
        pathology_train_map,
    )
    pathology_train_loader = DataLoader(
        pathology_train,
        batch_size=int(args.batch_size),
        sampler=pathology_sampler,
        drop_last=True,
        num_workers=int(args.num_workers),
        pin_memory=device.type == "cuda",
    )
    pathology_val_loader = DataLoader(
        pathology_val,
        batch_size=int(args.batch_size),
        shuffle=False,
        num_workers=int(args.num_workers),
        pin_memory=device.type == "cuda",
    )
    input_dim = infer_input_dim(base_model, pathology_train_loader, device)

    classwise_pathology_heads = bool(int(args.classwise_pathology_heads))
    epoch_checkpoint_dir = out / "epoch_checkpoints"
    if int(args.save_epoch_checkpoints):
        epoch_checkpoint_dir.mkdir(parents=True, exist_ok=True)

    def build_p4_checkpoint(
        *,
        pathology_specialist: nn.Module,
        pathology_report: Mapping[str, object],
        pathology_thresholds: Sequence[float],
    ) -> dict[str, object]:
        return {
            "protocol": specialist_saved.get("protocol", "TITAN_V45_V3E_MULTILABEL_SPECIALISTS"),
            "base_checkpoint": str(args.checkpoint),
            "morphology_dim": int(morphology_dim),
            "input_dim": int(input_dim),
            "signal_event_features": bool(USE_SIGNAL_EVENT_FEATURES),
            "signal_event_feature_dim": int(SIGNAL_EVENT_FEATURE_DIM if USE_SIGNAL_EVENT_FEATURES else 0),
            "primary8_classes": list(PRIMARY8_GATE_CLASSES),
            "pathology4_classes": list(PATHOLOGY4_GATE_CLASSES),
            "specialist_rhythm_classes": list(EFFECTIVE_SPECIALIST_RHYTHM_CLASSES),
            "rhythm_mode": str(specialist_saved.get("rhythm_mode", "multilabel")),
            "classwise_rhythm_heads": bool(specialist_saved.get("classwise_rhythm_heads", False)),
            "rhythm_hidden_dim": int(specialist_saved.get("rhythm_hidden_dim", 384) or 384),
            "classwise_pathology_heads": classwise_pathology_heads,
            "pathology_hidden_dim": int(pathology_report.get("hidden_dim", 192 if classwise_pathology_heads else 320)),
            "min_specialist_confidence": float(specialist_saved.get("min_specialist_confidence", args.min_specialist_confidence)),
            "rhythm_specialist_state_dict": specialist_saved["rhythm_specialist_state_dict"],
            "rhythm_thresholds": specialist_saved.get("rhythm_thresholds"),
            "pathology4_specialist_state_dict": pathology_specialist.state_dict(),
            "pathology4_thresholds": [float(value) for value in pathology_thresholds],
            "reports": {
                "rhythm": specialist_saved.get("reports", {}).get("rhythm", {}),
                "pathology4": pathology_report,
            },
            "p4_only_training": {
                "parent_v3d_specialists_checkpoint": str(args.v3d_specialists_checkpoint),
                "parent_input_dim": int(parent_input_dim),
                "feature_layout_source": "current_primary8_not_parent_specialist",
                "pathology_train_manifest": str(args.pathology_train_manifest),
                "pathology_val_panel_index": str(args.pathology_val_panel_index),
            },
        }

    def save_pathology_epoch_checkpoint(
        epoch: int,
        row: Mapping[str, object],
        pathology_model: nn.Module,
        validation: Mapping[str, object],
    ) -> None:
        if not int(args.save_epoch_checkpoints):
            return
        partial_report = {
            "classes": list(PATHOLOGY4_GATE_CLASSES),
            "input_dim": input_dim,
            "architecture": "classwise_binary_mlp" if classwise_pathology_heads else "shared_multilabel_mlp",
            "hidden_dim": int(validation.get("hidden_dim", 512 if classwise_pathology_heads else 384)),
            "epochs": int(epoch),
            "best_score": float(validation.get("macro_f1", 0.0)) + 0.25 * float(validation.get("mean_accuracy", 0.0)),
            "thresholds": row.get("thresholds", validation.get("thresholds", [0.5] * len(PATHOLOGY4_GATE_CLASSES))),
            "final_validation": validation,
            "log": [dict(row)],
            "checkpoint_scope": "p4_only_pathology_epoch_current_state",
        }
        checkpoint = build_p4_checkpoint(
            pathology_specialist=pathology_model,
            pathology_report=partial_report,
            pathology_thresholds=partial_report["thresholds"],
        )
        checkpoint["epoch_checkpoint"] = {
            "pathology_epoch": int(epoch),
            "rhythm_fixed_from": str(args.v3d_specialists_checkpoint),
            "intended_external_validation": "evaluate this file directly; no top-k/oracle",
        }
        checkpoint_path = epoch_checkpoint_dir / f"v3m_p4_specialist_epoch_{int(epoch):03d}.pt"
        temporary = checkpoint_path.with_suffix(".tmp")
        torch.save(checkpoint, temporary)
        temporary.replace(checkpoint_path)
        manifest_row = {
            "epoch": int(epoch),
            "checkpoint": str(checkpoint_path),
            "val_macro_f1": float(row.get("val_macro_f1", 0.0)),
            "val_mean_accuracy": float(row.get("val_mean_accuracy", 0.0)),
            "thresholds": row.get("thresholds"),
        }
        with (epoch_checkpoint_dir / "checkpoint_manifest.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(json_ready(manifest_row)) + "\n")
        print(json.dumps(json_ready({"epoch_checkpoint": manifest_row})), flush=True)

    pathology_specialist, pathology_report = train_pathology_specialist(
        base_model=base_model,
        train_loader=pathology_train_loader,
        val_loader=pathology_val_loader,
        train_pathology_map=pathology_train_map,
        val_pathology_map=pathology_val_map,
        device=device,
        input_dim=input_dim,
        epochs=int(args.pathology_epochs),
        lr=float(args.pathology_lr),
        output_dir=out,
        classwise_heads=classwise_pathology_heads,
        epoch_callback=save_pathology_epoch_checkpoint,
    )
    checkpoint = build_p4_checkpoint(
        pathology_specialist=pathology_specialist,
        pathology_report=pathology_report,
        pathology_thresholds=pathology_report["thresholds"],
    )
    checkpoint_path = out / "v3d_specialists.pt"
    torch.save(checkpoint, checkpoint_path)
    summary = {
        "protocol": "TITAN_V45_V3M_P4_ONLY_SPECIALIST_TRAINING_RUN",
        "device": str(device),
        "base_checkpoint_protocol": saved.get("protocol"),
        "parent_v3d_specialists_checkpoint": str(args.v3d_specialists_checkpoint),
        "parent_input_dim": int(parent_input_dim),
        "morphology_dim": int(morphology_dim),
        "input_dim": int(input_dim),
        "signal_event_features": bool(USE_SIGNAL_EVENT_FEATURES),
        "signal_event_feature_dim": int(SIGNAL_EVENT_FEATURE_DIM if USE_SIGNAL_EVENT_FEATURES else 0),
        "feature_layout_source": "current_primary8_not_parent_specialist",
        "pathology_train_windows": len(pathology_train),
        "pathology_val_windows": len(pathology_val),
        "pathology_label_counts": format_label_counts(pathology_counts, PATHOLOGY4_GATE_CLASSES),
        "pathology_sample_weight_max": float(np.max(pathology_sample_weights)) if len(pathology_sample_weights) else 0.0,
        "checkpoint": str(checkpoint_path),
        "reports": checkpoint["reports"],
    }
    (out / "v3m_p4_only_training_summary.json").write_text(json.dumps(json_ready(summary), indent=2), encoding="utf-8")
    print(json.dumps(json_ready(summary), indent=2), flush=True)
    return 0


def run_evaluate(args) -> int:
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    base_model, _saved, morphology_dim = load_base_model(args.checkpoint, device)
    specialist_saved = torch.load(args.v3d_specialists_checkpoint, map_location=device)
    apply_saved_specialist_feature_layout(specialist_saved)
    checkpoint_input_dim = int(specialist_saved["input_dim"])
    checkpoint_uses_signal = bool(specialist_saved.get("signal_event_features", False))
    checkpoint_signal_dim = int(specialist_saved.get("signal_event_feature_dim", 0) or 0)
    rhythm_state = specialist_saved["rhythm_specialist_state_dict"]
    pathology_state = specialist_saved["pathology4_specialist_state_dict"]
    rhythm_input_dim = infer_specialist_input_dim(rhythm_state, checkpoint_input_dim)
    pathology_input_dim = infer_specialist_input_dim(pathology_state, checkpoint_input_dim)
    rhythm_uses_signal, rhythm_signal_dim = signal_event_layout_for_input_dim(
        target_input_dim=rhythm_input_dim,
        checkpoint_input_dim=checkpoint_input_dim,
        checkpoint_signal_dim=checkpoint_signal_dim,
        checkpoint_uses_signal=checkpoint_uses_signal,
    )
    pathology_uses_signal, pathology_signal_dim = signal_event_layout_for_input_dim(
        target_input_dim=pathology_input_dim,
        checkpoint_input_dim=checkpoint_input_dim,
        checkpoint_signal_dim=checkpoint_signal_dim,
        checkpoint_uses_signal=checkpoint_uses_signal,
    )
    rhythm_mode = str(specialist_saved.get("rhythm_mode", "softmax"))
    rhythm_output_dim = len(PRIMARY8_GATE_CLASSES) if rhythm_mode == "multilabel" else len(EFFECTIVE_SPECIALIST_RHYTHM_CLASSES)
    rhythm_hidden_dim = infer_specialist_hidden_dim(
        rhythm_state,
        int(specialist_saved.get("rhythm_hidden_dim", 384 if rhythm_mode == "multilabel" else 320)),
    )
    if rhythm_mode == "multilabel" and bool(specialist_saved.get("classwise_rhythm_heads", False)):
        rhythm_specialist = ClassWiseBinaryMLP(rhythm_input_dim, rhythm_output_dim, hidden_dim=rhythm_hidden_dim, dropout=0.30).to(device)
    else:
        rhythm_specialist = SpecialistMLP(rhythm_input_dim, rhythm_output_dim, hidden_dim=rhythm_hidden_dim, dropout=0.30).to(device)
    rhythm_specialist.load_state_dict(rhythm_state)
    rhythm_specialist.eval()
    pathology_hidden_dim = infer_specialist_hidden_dim(
        pathology_state,
        int(specialist_saved.get("pathology_hidden_dim", 320)),
    )
    if bool(specialist_saved.get("classwise_pathology_heads", False)):
        pathology_specialist = ClassWiseBinaryMLP(
            pathology_input_dim,
            len(PATHOLOGY4_GATE_CLASSES),
            hidden_dim=pathology_hidden_dim,
            dropout=0.25,
        ).to(device)
    else:
        pathology_specialist = SpecialistMLP(
            pathology_input_dim,
            len(PATHOLOGY4_GATE_CLASSES),
            hidden_dim=pathology_hidden_dim,
            dropout=0.25,
        ).to(device)
    pathology_specialist.load_state_dict(pathology_state)
    pathology_specialist.eval()
    manifest_index = json.loads(Path(args.manifest_index_json).read_text(encoding="utf-8"))
    rhythm_views = {
        "primary8_multilabel_accepted_balanced": manifest_index["primary8_multilabel_accepted_balanced"],
        "primary8_model_ready_balanced": manifest_index["primary8_model_ready_balanced"],
        "primary8_strict_balanced": manifest_index["primary8_strict_balanced"],
    }
    if rhythm_mode == "multilabel":
        rhythm_thresholds = [float(value) for value in specialist_saved.get("rhythm_thresholds", [0.5] * len(PRIMARY8_GATE_CLASSES))]
        raw_biases = specialist_saved.get("rhythm_logit_biases")
        rhythm_logit_biases = (
            [float(value) for value in raw_biases]
            if raw_biases is not None
            else [0.0] * len(PRIMARY8_GATE_CLASSES)
        )
        set_signal_event_feature_mode(rhythm_uses_signal, feature_dim=rhythm_signal_dim)
        rhythm_reports = {
            name: evaluate_rhythm_external_multilabel_view(
                name=name,
                manifest_csv=manifest,
                data_root=args.data_root,
                base_model=base_model,
                specialist=rhythm_specialist,
                thresholds=rhythm_thresholds,
                logit_biases=rhythm_logit_biases,
                device=device,
                output_dir=out,
                num_workers=int(args.num_workers),
                morphology_dim=morphology_dim,
            )
            for name, manifest in rhythm_views.items()
        }
    else:
        set_signal_event_feature_mode(rhythm_uses_signal, feature_dim=rhythm_signal_dim)
        rhythm_reports = {
            name: evaluate_rhythm_external_view(
                name=name,
                manifest_csv=manifest,
                data_root=args.data_root,
                base_model=base_model,
                specialist=rhythm_specialist,
                device=device,
                output_dir=out,
                num_workers=int(args.num_workers),
                morphology_dim=morphology_dim,
                min_specialist_confidence=float(specialist_saved.get("min_specialist_confidence", args.min_specialist_confidence)),
            )
            for name, manifest in rhythm_views.items()
        }
    set_signal_event_feature_mode(pathology_uses_signal, feature_dim=pathology_signal_dim)
    pathology_report = evaluate_pathology_external(
        panel_index_json=manifest_index["pathology4_panel_index"],
        data_root=args.data_root,
        base_model=base_model,
        specialist=pathology_specialist,
        thresholds=[float(value) for value in specialist_saved["pathology4_thresholds"]],
        device=device,
        output_dir=out,
        num_workers=int(args.num_workers),
        morphology_dim=morphology_dim,
    )
    main_view = rhythm_reports["primary8_multilabel_accepted_balanced"]["membership_gate"]
    gate = {
        "rhythm_accuracy_required": 0.97,
        "rhythm_macro_f1_required": 0.80,
        "pathology_accuracy_required": 0.90,
        "pathology_macro_f1_required": 0.70,
        "rhythm_accuracy": main_view["top1_accepted_accuracy"],
        "rhythm_macro_f1": main_view["binary_panel_macro_f1"],
        "pathology_accuracy": pathology_report["pathology4_accuracy"],
        "pathology_macro_f1": pathology_report["pathology4_macro_f1"],
    }
    gate["passed"] = bool(
        gate["rhythm_accuracy"] >= gate["rhythm_accuracy_required"]
        and gate["rhythm_macro_f1"] >= gate["rhythm_macro_f1_required"]
        and gate["pathology_accuracy"] >= gate["pathology_accuracy_required"]
        and gate["pathology_macro_f1"] >= gate["pathology_macro_f1_required"]
    )
    report = {
        "protocol": "TITAN_V45_V3D_EXTERNAL_EVALUATION",
        "checkpoint": str(args.checkpoint),
        "v3d_specialists_checkpoint": str(args.v3d_specialists_checkpoint),
        "manifest_index_json": str(args.manifest_index_json),
        "device": str(device),
        "morphology_dim": int(morphology_dim),
        "rhythm_mode": rhythm_mode,
        "checkpoint_input_dim": int(checkpoint_input_dim),
        "rhythm_input_dim": int(rhythm_input_dim),
        "pathology_input_dim": int(pathology_input_dim),
        "rhythm_signal_event_features": bool(rhythm_uses_signal),
        "pathology_signal_event_features": bool(pathology_uses_signal),
        "rhythm_logit_biases": (
            [float(value) for value in specialist_saved.get("rhythm_logit_biases", [0.0] * len(PRIMARY8_GATE_CLASSES))]
            if rhythm_mode == "multilabel"
            else None
        ),
        "primary_gate_view": "primary8_multilabel_accepted_balanced",
        "gate": gate,
        "rhythm": rhythm_reports,
        "pathology4": pathology_report,
    }
    (out / "external_v3d_specialist_report.json").write_text(json.dumps(json_ready(report), indent=2), encoding="utf-8")
    print(json.dumps(json_ready(gate), indent=2), flush=True)
    return 0


def run_evaluate_p4_only(args) -> int:
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    base_model, _saved, morphology_dim = load_base_model(args.checkpoint, device)
    specialist_saved = torch.load(args.v3d_specialists_checkpoint, map_location=device)
    apply_saved_specialist_feature_layout(specialist_saved)
    checkpoint_input_dim = int(specialist_saved["input_dim"])
    checkpoint_uses_signal = bool(specialist_saved.get("signal_event_features", False))
    checkpoint_signal_dim = int(specialist_saved.get("signal_event_feature_dim", 0) or 0)
    pathology_state = specialist_saved["pathology4_specialist_state_dict"]
    pathology_input_dim = infer_specialist_input_dim(pathology_state, checkpoint_input_dim)
    pathology_uses_signal, pathology_signal_dim = signal_event_layout_for_input_dim(
        target_input_dim=pathology_input_dim,
        checkpoint_input_dim=checkpoint_input_dim,
        checkpoint_signal_dim=checkpoint_signal_dim,
        checkpoint_uses_signal=checkpoint_uses_signal,
    )
    pathology_hidden_dim = infer_specialist_hidden_dim(
        pathology_state,
        int(specialist_saved.get("pathology_hidden_dim", 320)),
    )
    if bool(specialist_saved.get("classwise_pathology_heads", False)):
        specialist = ClassWiseBinaryMLP(
            pathology_input_dim,
            len(PATHOLOGY4_GATE_CLASSES),
            hidden_dim=pathology_hidden_dim,
            dropout=0.25,
        ).to(device)
    else:
        specialist = SpecialistMLP(
            pathology_input_dim,
            len(PATHOLOGY4_GATE_CLASSES),
            hidden_dim=pathology_hidden_dim,
            dropout=0.25,
        ).to(device)
    specialist.load_state_dict(pathology_state)
    specialist.eval()
    set_signal_event_feature_mode(pathology_uses_signal, feature_dim=pathology_signal_dim)
    manifest_index = json.loads(Path(args.manifest_index_json).read_text(encoding="utf-8"))
    pathology_report = evaluate_pathology_external(
        panel_index_json=manifest_index["pathology4_panel_index"],
        data_root=args.data_root,
        base_model=base_model,
        specialist=specialist,
        thresholds=[float(value) for value in specialist_saved["pathology4_thresholds"]],
        device=device,
        output_dir=out,
        num_workers=int(args.num_workers),
        morphology_dim=morphology_dim,
    )
    report = {
        "protocol": "TITAN_V45_V3AG_PATHOLOGY4_ONLY_EXTERNAL_DEV",
        "coverage": 1.0,
        "pathology4_classes": list(PATHOLOGY4_GATE_CLASSES),
        "pathology4_macro_f1": float(pathology_report["pathology4_macro_f1"]),
        "pathology4_accuracy": float(pathology_report["pathology4_accuracy"]),
        "gate_required": {"accuracy": 0.95, "macro_f1_strictly_greater_than": 0.75},
        "gate_passed": bool(
            float(pathology_report["pathology4_accuracy"]) >= 0.95
            and float(pathology_report["pathology4_macro_f1"]) > 0.75
        ),
        "pathology4": pathology_report,
    }
    (out / "pathology4_only_external_dev_report.json").write_text(
        json.dumps(json_ready(report), indent=2),
        encoding="utf-8",
    )
    print(json.dumps(json_ready(report), indent=2), flush=True)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)

    finetune = sub.add_parser("finetune", help="partial V3F fine-tune of V3C backbone and heads")
    finetune.add_argument("--data_root", required=True)
    finetune.add_argument("--checkpoint", required=True)
    finetune.add_argument("--rhythm_train_manifest", required=True)
    finetune.add_argument("--rhythm_val_manifest", required=True)
    finetune.add_argument("--pathology_train_manifest", required=True)
    finetune.add_argument("--pathology_val_panel_index", required=True)
    finetune.add_argument("--output_dir", required=True)
    finetune.add_argument("--seed", type=int, default=197802)
    finetune.add_argument("--batch_size", type=int, default=16)
    finetune.add_argument("--num_workers", type=int, default=2)
    finetune.add_argument("--epochs", type=int, default=8)
    finetune.add_argument("--lr", type=float, default=8e-5)
    finetune.add_argument("--unfreeze_transformer_layers", type=int, default=2)
    finetune.set_defaults(func=run_finetune)

    train = sub.add_parser("train", help="train V3D specialists")
    train.add_argument("--data_root", required=True)
    train.add_argument("--checkpoint", required=True)
    train.add_argument("--rhythm_train_manifest", required=True)
    train.add_argument("--rhythm_val_manifest", required=True)
    train.add_argument("--pathology_train_manifest", required=True)
    train.add_argument("--pathology_val_panel_index", required=True)
    train.add_argument("--output_dir", required=True)
    train.add_argument("--seed", type=int, default=197802)
    train.add_argument("--batch_size", type=int, default=32)
    train.add_argument("--num_workers", type=int, default=2)
    train.add_argument("--rhythm_epochs", type=int, default=10)
    train.add_argument("--pathology_epochs", type=int, default=10)
    train.add_argument("--rhythm_lr", type=float, default=4e-4)
    train.add_argument("--pathology_lr", type=float, default=3e-4)
    train.add_argument("--min_specialist_confidence", type=float, default=0.66)
    train.add_argument("--rhythm_multilabel", type=int, default=0)
    train.add_argument("--classwise_rhythm_heads", type=int, default=0)
    train.add_argument("--classwise_pathology_heads", type=int, default=0)
    train.add_argument("--rhythm_top1_loss_weight", type=float, default=0.0)
    train.add_argument("--save_epoch_checkpoints", type=int, default=0)
    train.add_argument("--signal_features", type=int, default=0)
    train.set_defaults(func=run_train)

    train_rhythm = sub.add_parser("train-rhythm", help="train only Primary8 rhythm specialists while preserving previous P4 specialists")
    train_rhythm.add_argument("--data_root", required=True)
    train_rhythm.add_argument("--checkpoint", required=True)
    train_rhythm.add_argument("--v3d_specialists_checkpoint", required=True)
    train_rhythm.add_argument("--rhythm_train_manifest", required=True)
    train_rhythm.add_argument("--rhythm_val_manifest", required=True)
    train_rhythm.add_argument("--rhythm_monitor_manifest")
    train_rhythm.add_argument("--output_dir", required=True)
    train_rhythm.add_argument("--seed", type=int, default=197802)
    train_rhythm.add_argument("--batch_size", type=int, default=32)
    train_rhythm.add_argument("--num_workers", type=int, default=2)
    train_rhythm.add_argument("--rhythm_epochs", type=int, default=12)
    train_rhythm.add_argument("--rhythm_lr", type=float, default=3e-4)
    train_rhythm.add_argument("--min_specialist_confidence", type=float, default=0.66)
    train_rhythm.add_argument("--rhythm_multilabel", type=int, default=1)
    train_rhythm.add_argument("--classwise_rhythm_heads", type=int, default=0)
    train_rhythm.add_argument("--rhythm_top1_loss_weight", type=float, default=0.0)
    train_rhythm.add_argument("--save_epoch_checkpoints", type=int, default=0)
    train_rhythm.add_argument("--signal_features", type=int, default=0)
    train_rhythm.set_defaults(func=run_train_rhythm_only)

    train_p4 = sub.add_parser("train-p4", help="train only P4 specialists while preserving a previous rhythm specialist")
    train_p4.add_argument("--data_root", required=True)
    train_p4.add_argument("--checkpoint", required=True)
    train_p4.add_argument("--v3d_specialists_checkpoint", required=True)
    train_p4.add_argument("--pathology_train_manifest", required=True)
    train_p4.add_argument("--pathology_val_panel_index", required=True)
    train_p4.add_argument("--output_dir", required=True)
    train_p4.add_argument("--seed", type=int, default=197802)
    train_p4.add_argument("--batch_size", type=int, default=32)
    train_p4.add_argument("--num_workers", type=int, default=2)
    train_p4.add_argument("--pathology_epochs", type=int, default=14)
    train_p4.add_argument("--pathology_lr", type=float, default=3e-4)
    train_p4.add_argument("--min_specialist_confidence", type=float, default=0.66)
    train_p4.add_argument("--classwise_pathology_heads", type=int, default=0)
    train_p4.add_argument("--save_epoch_checkpoints", type=int, default=0)
    train_p4.add_argument("--signal_features", type=int, default=0)
    train_p4.set_defaults(func=run_train_p4_only)

    evaluate = sub.add_parser("evaluate", help="evaluate V3D specialists on adapted external manifests")
    evaluate.add_argument("--data_root", required=True)
    evaluate.add_argument("--checkpoint", required=True)
    evaluate.add_argument("--v3d_specialists_checkpoint", required=True)
    evaluate.add_argument("--manifest_index_json", required=True)
    evaluate.add_argument("--output_dir", required=True)
    evaluate.add_argument("--num_workers", type=int, default=2)
    evaluate.add_argument("--min_specialist_confidence", type=float, default=0.66)
    evaluate.set_defaults(func=run_evaluate)

    evaluate_p4 = sub.add_parser("evaluate-p4", help="evaluate only P4 specialists on external-dev panels")
    evaluate_p4.add_argument("--data_root", required=True)
    evaluate_p4.add_argument("--checkpoint", required=True)
    evaluate_p4.add_argument("--v3d_specialists_checkpoint", required=True)
    evaluate_p4.add_argument("--manifest_index_json", required=True)
    evaluate_p4.add_argument("--output_dir", required=True)
    evaluate_p4.add_argument("--num_workers", type=int, default=1)
    evaluate_p4.set_defaults(func=run_evaluate_p4_only)
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
